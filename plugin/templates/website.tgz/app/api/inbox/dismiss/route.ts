import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs/promises";
import path from "node:path";
import YAML from "yaml";
import { STATE_DIR } from "@/lib/paths";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { id } = body as { id?: string };

    if (!id || typeof id !== "string") {
      return NextResponse.json({ error: "id is required" }, { status: 400 });
    }

    const indexPath = path.join(STATE_DIR, "documents", "index.yaml");

    let raw: string;
    try {
      raw = await fs.readFile(indexPath, "utf8");
    } catch {
      return NextResponse.json({ error: "documents/index.yaml not found" }, { status: 404 });
    }

    const index = YAML.parse(raw) as { entries?: Array<Record<string, any>> };
    if (!index?.entries) {
      return NextResponse.json({ error: "No entries in index" }, { status: 404 });
    }

    const entry = index.entries.find((e) => e.id === id);
    if (!entry) {
      return NextResponse.json({ error: `Document ${id} not found` }, { status: 404 });
    }

    // Warn but proceed if already in imprint
    const wasImprint = entry.use_designation === "imprint";
    entry.triage_state = "dismissed";

    await fs.writeFile(indexPath, YAML.stringify(index), "utf8");

    // Log to activity
    await appendActivityLog({
      event: "inbox.document.dismissed",
      doc_id: id,
      was_imprint: wasImprint,
      timestamp: new Date().toISOString(),
    });

    return NextResponse.json({
      ok: true,
      id,
      warning: wasImprint
        ? "This document was flagged as imprint. The copy in references/imprint/ has not been removed."
        : null,
    });
  } catch (err) {
    console.error("[inbox/dismiss]", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

async function appendActivityLog(entry: Record<string, any>) {
  try {
    const logPath = path.join(STATE_DIR, "logs", "activity.ndjson");
    const line = JSON.stringify(entry) + "\n";
    await fs.appendFile(logPath, line, "utf8");
  } catch {
    // Non-fatal
  }
}
