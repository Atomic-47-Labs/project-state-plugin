import { listInboxDocuments, getInboxOrientation } from "@/lib/inbox";
import InboxClient from "@/components/inbox-client";
import PageHeader from "@/components/page-header";

export const revalidate = 300;

export default async function InboxPage() {
  const [documents, orientation] = await Promise.all([
    listInboxDocuments(),
    getInboxOrientation(),
  ]);

  const unprocessed = documents.filter(
    (d) => !d.triage_state || d.triage_state === "unprocessed"
  ).length;

  const imprint = documents.filter((d) => d.use_designation === "imprint").length;

  return (
    <div className="space-y-8">
      <PageHeader
        kicker="Smart Inbox"
        title="Document Inbox"
        description="Intelligent triage for incoming project documents. Files dropped into documents/inbox/ are classified by type, designated for use, scored for relevance, and flagged for onboarding pre-fill."
        meta={
          <span>
            {documents.length} document{documents.length !== 1 ? "s" : ""}
            {unprocessed > 0 && (
              <> · <span className="text-amber-700 font-medium">{unprocessed} unprocessed</span></>
            )}
            {imprint > 0 && (
              <> · <span className="text-orange-700 font-medium">{imprint} imprint</span></>
            )}
            {orientation && (
              <> · <span className="text-emerald-700 font-medium">orientation ready</span></>
            )}
          </span>
        }
      />

      <InboxClient documents={documents} orientation={orientation} />
    </div>
  );
}
