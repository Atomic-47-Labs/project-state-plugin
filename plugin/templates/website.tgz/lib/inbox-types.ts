// Types and colour helpers for the Smart Inbox.
// This file has NO server-side imports — safe to use in both server and client components.

// ─── Types ────────────────────────────────────────────────────────────────────

export type TriageState = "processed" | "unprocessed" | "dismissed";
export type UseDesignation = "imprint" | "for-use" | "example" | "output" | "unknown";
export type TriageConfidence = "high" | "medium" | "low";

export type ActionFlag =
  | "seed-manifest"
  | "seed-milestones"
  | "seed-risks"
  | "seed-people"
  | "seed-budget"
  | "example-output"
  | "reference-material";

export type InboxDocument = {
  // Core fields (always present)
  id: string;
  path: string;
  kind?: string;
  status?: string;
  source_of_truth?: boolean;
  // Smart inbox fields (added by project-inbox skill)
  triage_state?: TriageState;
  use_designation?: UseDesignation;
  relevance_score?: number;
  action_flags?: ActionFlag[];
  extraction_summary?: string;
  triage_timestamp?: string;
  triage_confidence?: TriageConfidence;
  // Extra fields from rich entries
  title?: string;
  description?: string;
  phase?: string;
};

export type InboxOrientationChapter = {
  confidence: "high" | "medium" | "low";
  fields: string[];
};

export type InboxOrientationGap = {
  field: string;
  affects_chapters: number[];
};

export type InboxOrientationSource = {
  doc_id: string;
  path: string;
  kind: string;
  contribution: string;
};

export type InboxOrientation = {
  generated_at?: string;
  document_count?: number;
  confidence?: "high" | "medium" | "low";
  project_identity?: {
    short_name_hint?: string | null;
    long_name_hint?: string | null;
    funder_hint?: string | null;
    program_hint?: string | null;
    start_date_hint?: string | null;
    end_date_hint?: string | null;
    budget_hint_cad?: number | null;
    governing_document_id?: string | null;
  };
  stakeholder_hints?: Array<{
    name?: string;
    organization?: string;
    role_hint?: string;
    source_doc?: string;
  }>;
  milestone_hints?: Array<{
    title_hint?: string;
    owner_hint?: string;
    end_date_hint?: string;
    source_doc?: string;
  }>;
  pre_filled_chapters?: Record<string, InboxOrientationChapter>;
  gaps?: InboxOrientationGap[];
  imprint_sources?: InboxOrientationSource[];
};

// ─── Colour helpers ───────────────────────────────────────────────────────────

export function designationColor(designation: UseDesignation | undefined): string {
  switch (designation) {
    case "imprint":  return "bg-orange-100 text-orange-900 ring-orange-300";
    case "for-use":  return "bg-blue-100 text-blue-900 ring-blue-300";
    case "example":  return "bg-emerald-100 text-emerald-900 ring-emerald-300";
    case "output":   return "bg-slate-100 text-slate-700 ring-slate-300";
    default:         return "bg-slate-50 text-slate-500 ring-slate-200";
  }
}

export function confidenceColor(confidence: TriageConfidence | undefined): string {
  switch (confidence) {
    case "high":   return "text-emerald-700";
    case "medium": return "text-amber-700";
    case "low":    return "text-red-600";
    default:       return "text-slate-400";
  }
}

export function relevanceBar(score: number | undefined): string {
  const s = score ?? 0;
  if (s >= 75) return "bg-emerald-500";
  if (s >= 50) return "bg-amber-400";
  if (s >= 25) return "bg-sky-400";
  return "bg-slate-300";
}

export function kindLabel(kind: string | undefined): string {
  if (!kind) return "unknown";
  return kind.replace(/-/g, " ");
}
