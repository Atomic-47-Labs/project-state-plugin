"use client";

import { useState, useMemo, useTransition } from "react";
import type {
  InboxDocument,
  InboxOrientation,
  UseDesignation,
  TriageState,
  ActionFlag,
} from "@/lib/inbox-types";
import { designationColor, confidenceColor, relevanceBar, kindLabel } from "@/lib/inbox-types";

// ─── Types ────────────────────────────────────────────────────────────────────

type SortKey = "relevance" | "date" | "designation" | "name";

const DESIGNATIONS: Array<{ value: UseDesignation | "all"; label: string }> = [
  { value: "all",     label: "All" },
  { value: "imprint", label: "Imprint" },
  { value: "for-use", label: "For Use" },
  { value: "example", label: "Example" },
  { value: "output",  label: "Output" },
  { value: "unknown", label: "Unknown" },
];

const TRIAGE_STATES: Array<{ value: TriageState | "all"; label: string }> = [
  { value: "all",         label: "All" },
  { value: "unprocessed", label: "Unprocessed" },
  { value: "processed",   label: "Processed" },
  { value: "dismissed",   label: "Dismissed" },
];

const SORT_OPTIONS: Array<{ value: SortKey; label: string }> = [
  { value: "relevance",   label: "Relevance" },
  { value: "date",        label: "Date added" },
  { value: "designation", label: "Designation" },
  { value: "name",        label: "Name" },
];

// ─── Main component ───────────────────────────────────────────────────────────

export default function InboxClient({
  documents,
  orientation,
}: {
  documents: InboxDocument[];
  orientation: InboxOrientation | null;
}) {
  const [query, setQuery] = useState("");
  const [designationFilter, setDesignationFilter] = useState<UseDesignation | "all">("all");
  const [triageFilter, setTriageFilter] = useState<TriageState | "all">("all");
  const [sortKey, setSortKey] = useState<SortKey>("relevance");
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [showOrientation, setShowOrientation] = useState(!!orientation);
  const [isPending, startTransition] = useTransition();

  // Counts for summary bar
  const counts = useMemo(() => ({
    total:       documents.length,
    imprint:     documents.filter((d) => d.use_designation === "imprint").length,
    forUse:      documents.filter((d) => d.use_designation === "for-use").length,
    example:     documents.filter((d) => d.use_designation === "example").length,
    output:      documents.filter((d) => d.use_designation === "output").length,
    unprocessed: documents.filter((d) => !d.triage_state || d.triage_state === "unprocessed").length,
    processed:   documents.filter((d) => d.triage_state === "processed").length,
  }), [documents]);

  // Filter + sort
  const filtered = useMemo(() => {
    let docs = [...documents];

    if (designationFilter !== "all") {
      docs = docs.filter((d) => d.use_designation === designationFilter);
    }
    if (triageFilter !== "all") {
      docs = docs.filter((d) =>
        triageFilter === "unprocessed"
          ? !d.triage_state || d.triage_state === "unprocessed"
          : d.triage_state === triageFilter
      );
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      docs = docs.filter(
        (d) =>
          d.id.toLowerCase().includes(q) ||
          (d.title ?? "").toLowerCase().includes(q) ||
          (d.path ?? "").toLowerCase().includes(q) ||
          (d.kind ?? "").toLowerCase().includes(q) ||
          (d.extraction_summary ?? "").toLowerCase().includes(q) ||
          (d.action_flags ?? []).some((f) => f.toLowerCase().includes(q))
      );
    }

    docs.sort((a, b) => {
      switch (sortKey) {
        case "relevance":
          return (b.relevance_score ?? 0) - (a.relevance_score ?? 0);
        case "date":
          return (b.triage_timestamp ?? "").localeCompare(a.triage_timestamp ?? "");
        case "designation": {
          const order: Record<string, number> = { imprint: 0, "for-use": 1, example: 2, output: 3, unknown: 4 };
          return (order[a.use_designation ?? "unknown"] ?? 4) - (order[b.use_designation ?? "unknown"] ?? 4);
        }
        case "name":
          return a.id.localeCompare(b.id);
        default:
          return 0;
      }
    });

    return docs;
  }, [documents, designationFilter, triageFilter, query, sortKey]);

  function toggleExpand(id: string) {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  async function handleFlag(docId: string, designation: UseDesignation) {
    startTransition(async () => {
      await fetch("/api/inbox/flag", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: docId, designation }),
      });
      // Reload to reflect changes
      window.location.reload();
    });
  }

  async function handleDismiss(docId: string) {
    startTransition(async () => {
      await fetch("/api/inbox/dismiss", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: docId }),
      });
      window.location.reload();
    });
  }

  return (
    <div className="space-y-6">
      {/* Summary bar */}
      <div className="bg-white border border-[var(--border)] rounded-xl px-5 py-4 flex flex-wrap gap-x-6 gap-y-3 items-center text-sm">
        <div className="flex flex-wrap gap-x-5 gap-y-1 text-sm flex-1 min-w-0">
          <span className="text-slate-700 font-medium">{counts.total} documents</span>
          {counts.unprocessed > 0 && (
            <span className="text-amber-700 font-medium">{counts.unprocessed} unprocessed</span>
          )}
          {counts.imprint > 0 && (
            <span className="text-orange-700">{counts.imprint} imprint</span>
          )}
          {counts.forUse > 0 && (
            <span className="text-blue-700">{counts.forUse} for-use</span>
          )}
          {counts.example > 0 && (
            <span className="text-emerald-700">{counts.example} example</span>
          )}
          {counts.processed > 0 && (
            <span className="text-slate-500">{counts.processed} processed</span>
          )}
        </div>
        {counts.unprocessed > 0 && (
          <div className="text-xs text-[var(--muted)] bg-amber-50 border border-amber-200 rounded-lg px-3 py-1.5">
            Run{" "}
            <code className="font-mono text-amber-800 font-semibold">/project-inbox triage</code>{" "}
            to classify {counts.unprocessed} document{counts.unprocessed !== 1 ? "s" : ""}
          </div>
        )}
      </div>

      {/* Orientation panel */}
      {orientation && (
        <div className="bg-orange-50 border border-orange-200 rounded-xl overflow-hidden">
          <button
            onClick={() => setShowOrientation((v) => !v)}
            className="w-full px-5 py-3 flex items-center gap-2 text-left hover:bg-orange-100 transition"
          >
            <span className="text-orange-600 font-semibold text-sm">
              Inbox Orientation
            </span>
            <span className="text-xs text-orange-500 font-mono ml-1">
              {orientation.document_count} imprint doc{orientation.document_count !== 1 ? "s" : ""} ·{" "}
              confidence: {orientation.confidence}
            </span>
            <svg
              className={`ml-auto w-4 h-4 text-orange-500 transition-transform ${showOrientation ? "rotate-180" : ""}`}
              viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
            >
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>

          {showOrientation && (
            <div className="px-5 pb-5 pt-1 border-t border-orange-200 space-y-4">
              {orientation.project_identity && (
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-orange-600 font-bold mb-2">
                    Project Identity Hints
                  </div>
                  <dl className="grid grid-cols-2 gap-x-6 gap-y-1.5 text-xs">
                    {orientation.project_identity.short_name_hint && (
                      <>
                        <dt className="text-[var(--muted)]">Short name</dt>
                        <dd className="text-slate-800 font-medium">{orientation.project_identity.short_name_hint}</dd>
                      </>
                    )}
                    {orientation.project_identity.funder_hint && (
                      <>
                        <dt className="text-[var(--muted)]">Funder</dt>
                        <dd className="text-slate-800 font-medium">{orientation.project_identity.funder_hint}</dd>
                      </>
                    )}
                    {orientation.project_identity.start_date_hint && (
                      <>
                        <dt className="text-[var(--muted)]">Start</dt>
                        <dd className="text-slate-800 font-mono">{orientation.project_identity.start_date_hint}</dd>
                      </>
                    )}
                    {orientation.project_identity.end_date_hint && (
                      <>
                        <dt className="text-[var(--muted)]">End</dt>
                        <dd className="text-slate-800 font-mono">{orientation.project_identity.end_date_hint}</dd>
                      </>
                    )}
                    {orientation.project_identity.budget_hint_cad != null && (
                      <>
                        <dt className="text-[var(--muted)]">Budget</dt>
                        <dd className="text-slate-800 font-medium">
                          ${orientation.project_identity.budget_hint_cad.toLocaleString("en-CA")} CAD
                        </dd>
                      </>
                    )}
                  </dl>
                </div>
              )}

              {orientation.milestone_hints && orientation.milestone_hints.length > 0 && (
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-orange-600 font-bold mb-2">
                    Milestone Hints ({orientation.milestone_hints.length})
                  </div>
                  <ul className="space-y-1">
                    {orientation.milestone_hints.map((m, i) => (
                      <li key={i} className="text-xs flex gap-3">
                        <span className="text-slate-600 font-medium flex-1">{m.title_hint}</span>
                        {m.owner_hint && <span className="text-slate-400">{m.owner_hint}</span>}
                        {m.end_date_hint && <span className="text-slate-400 font-mono">{m.end_date_hint}</span>}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {orientation.gaps && orientation.gaps.length > 0 && (
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-orange-600 font-bold mb-2">
                    Gaps (still need input)
                  </div>
                  <ul className="space-y-1">
                    {orientation.gaps.map((g, i) => (
                      <li key={i} className="text-xs text-slate-600 font-mono">{g.field}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="text-xs text-orange-700 bg-orange-100 rounded-lg px-3 py-2">
                Run{" "}
                <code className="font-mono font-semibold">/project-onboarding</code>{" "}
                — Chapter 0 will use this orientation to pre-fill context and skip questions you've already answered.
              </div>
            </div>
          )}
        </div>
      )}

      {/* Controls */}
      <div className="flex flex-wrap gap-3 items-center">
        {/* Search */}
        <div className="relative flex-1 min-w-[180px]">
          <svg
            className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"
            viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
          >
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search documents…"
            className="w-full pl-9 pr-4 py-2 text-sm border border-[var(--border)] rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[var(--accent)] placeholder:text-slate-400"
          />
        </div>

        {/* Sort */}
        <select
          value={sortKey}
          onChange={(e) => setSortKey(e.target.value as SortKey)}
          className="text-sm border border-[var(--border)] rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[var(--accent)] text-slate-700"
        >
          {SORT_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>
              Sort: {o.label}
            </option>
          ))}
        </select>
      </div>

      {/* Filter chips */}
      <div className="flex flex-wrap gap-2 items-center">
        <span className="text-[10px] uppercase tracking-widest text-[var(--muted)] font-semibold self-center">
          Designation
        </span>
        {DESIGNATIONS.map((d) => (
          <button
            key={d.value}
            onClick={() => setDesignationFilter(d.value as UseDesignation | "all")}
            className={`px-3 py-1 rounded-full text-xs font-medium transition ${
              designationFilter === d.value
                ? "bg-[var(--accent)] text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            {d.label}
          </button>
        ))}
        <span className="ml-3 text-[10px] uppercase tracking-widest text-[var(--muted)] font-semibold self-center">
          Status
        </span>
        {TRIAGE_STATES.map((t) => (
          <button
            key={t.value}
            onClick={() => setTriageFilter(t.value as TriageState | "all")}
            className={`px-3 py-1 rounded-full text-xs font-medium transition ${
              triageFilter === t.value
                ? "bg-[var(--accent)] text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            {t.label}
          </button>
        ))}
        {(designationFilter !== "all" || triageFilter !== "all" || query) && (
          <button
            onClick={() => { setDesignationFilter("all"); setTriageFilter("all"); setQuery(""); }}
            className="ml-2 px-2 py-1 text-xs text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded transition"
          >
            Clear
          </button>
        )}
      </div>

      {/* Results count */}
      {filtered.length !== documents.length && (
        <div className="text-xs text-[var(--muted)]">
          Showing {filtered.length} of {documents.length} documents
        </div>
      )}

      {/* Document cards */}
      <div className="space-y-3">
        {filtered.map((doc) => (
          <DocCard
            key={doc.id}
            doc={doc}
            expanded={expandedIds.has(doc.id)}
            onToggle={() => toggleExpand(doc.id)}
            onFlag={handleFlag}
            onDismiss={handleDismiss}
            isPending={isPending}
          />
        ))}

        {filtered.length === 0 && (
          <div className="bg-white border border-[var(--border)] rounded-xl p-10 text-center text-sm text-[var(--muted)]">
            {documents.length === 0
              ? <>
                  No documents in inbox yet. Drop files into{" "}
                  <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">
                    project-state/documents/inbox/
                  </code>
                  {" "}and run{" "}
                  <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">
                    /project-inbox triage
                  </code>
                </>
              : "No documents match the current filters."}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── DocCard ─────────────────────────────────────────────────────────────────

function DocCard({
  doc,
  expanded,
  onToggle,
  onFlag,
  onDismiss,
  isPending,
}: {
  doc: InboxDocument;
  expanded: boolean;
  onToggle: () => void;
  onFlag: (id: string, d: UseDesignation) => void;
  onDismiss: (id: string) => void;
  isPending: boolean;
}) {
  const [showFlagMenu, setShowFlagMenu] = useState(false);
  const designation = doc.use_designation ?? "unknown";
  const isUnprocessed = !doc.triage_state || doc.triage_state === "unprocessed";
  const score = doc.relevance_score ?? 0;
  const filename = doc.path?.split("/").pop() ?? doc.id;

  return (
    <div
      className={`bg-white border rounded-xl overflow-hidden shadow-sm transition ${
        designation === "imprint"
          ? "border-orange-200"
          : isUnprocessed
          ? "border-amber-200"
          : "border-[var(--border)]"
      }`}
    >
      <div className="px-5 pt-4 pb-3 flex flex-wrap items-start gap-x-3 gap-y-2">
        {/* ID + filename */}
        <div className="flex-1 min-w-0">
          <span className="font-mono text-xs text-slate-400 block mb-0.5">{doc.id}</span>
          <h3 className="text-sm font-semibold text-slate-900 leading-snug truncate">
            {doc.title ?? filename}
          </h3>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-1.5 shrink-0 items-center">
          {/* Kind */}
          {doc.kind && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ring-1 bg-slate-100 text-slate-700 ring-slate-300">
              {kindLabel(doc.kind)}
            </span>
          )}
          {/* Designation */}
          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ring-1 ${designationColor(doc.use_designation)}`}>
            {designation}
          </span>
          {/* Triage state */}
          {isUnprocessed && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ring-1 bg-amber-100 text-amber-800 ring-amber-300">
              unprocessed
            </span>
          )}
          {doc.triage_state === "dismissed" && (
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ring-1 bg-slate-100 text-slate-500 ring-slate-200">
              dismissed
            </span>
          )}
        </div>
      </div>

      {/* Relevance bar + score */}
      {doc.relevance_score != null && (
        <div className="px-5 pb-2">
          <div className="flex items-center gap-2">
            <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${relevanceBar(score)}`}
                style={{ width: `${score}%` }}
              />
            </div>
            <span className="text-[11px] font-mono text-slate-500 w-8 text-right">{score}</span>
            {doc.triage_confidence && (
              <span className={`text-[10px] font-semibold ${confidenceColor(doc.triage_confidence)}`}>
                {doc.triage_confidence}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Extraction summary (collapsed by default) */}
      {doc.extraction_summary && (
        <div className="px-5 pb-3">
          <button
            onClick={onToggle}
            className="text-xs text-[var(--accent)] hover:underline flex items-center gap-1"
          >
            <svg
              className={`w-3 h-3 transition-transform ${expanded ? "rotate-90" : ""}`}
              viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"
            >
              <polyline points="9 18 15 12 9 6" />
            </svg>
            {expanded ? "Hide summary" : "Show summary"}
          </button>
          {expanded && (
            <p className="mt-1.5 text-xs text-slate-600 leading-relaxed">
              {doc.extraction_summary}
            </p>
          )}
        </div>
      )}

      {/* Action flags */}
      {doc.action_flags && doc.action_flags.length > 0 && (
        <div className="px-5 pb-3 flex flex-wrap gap-1.5">
          {doc.action_flags.map((f) => (
            <span
              key={f}
              className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-slate-100 text-slate-600 ring-1 ring-slate-200"
            >
              {f}
            </span>
          ))}
        </div>
      )}

      {/* Actions */}
      <div className="px-5 pb-4 flex flex-wrap gap-2 border-t border-[var(--border)] pt-3">
        {/* Flag button + dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowFlagMenu((v) => !v)}
            disabled={isPending}
            className="text-xs px-3 py-1.5 rounded-lg border border-[var(--border)] text-slate-700 hover:bg-slate-50 transition disabled:opacity-50"
          >
            Flag ▾
          </button>
          {showFlagMenu && (
            <div className="absolute top-full left-0 mt-1 z-10 bg-white border border-[var(--border)] rounded-lg shadow-lg py-1 min-w-[130px]">
              {(["imprint", "for-use", "example", "output", "unknown"] as UseDesignation[]).map((d) => (
                <button
                  key={d}
                  onClick={() => { onFlag(doc.id, d); setShowFlagMenu(false); }}
                  className={`block w-full text-left px-4 py-1.5 text-xs hover:bg-slate-50 transition ${
                    doc.use_designation === d ? "font-semibold text-[var(--accent)]" : "text-slate-700"
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* View */}
        {doc.path && (
          <span className="text-xs px-3 py-1.5 rounded-lg border border-[var(--border)] text-slate-500 font-mono truncate max-w-[240px]">
            {doc.path}
          </span>
        )}

        {/* Dismiss */}
        {doc.triage_state !== "dismissed" && (
          <button
            onClick={() => onDismiss(doc.id)}
            disabled={isPending}
            className="text-xs px-3 py-1.5 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-600 hover:border-slate-300 transition ml-auto disabled:opacity-50"
          >
            Dismiss
          </button>
        )}
      </div>
    </div>
  );
}
