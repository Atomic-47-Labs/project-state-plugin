'use client'

import { useEffect, useState, useCallback, useRef, DragEvent } from 'react'
import { clsx } from 'clsx'
import { Nav } from '@/components/nav'
import { MarkdownViewerOverlay } from '@/components/markdown-viewer'

interface InboxFile { name: string; size: number; mtime: string; ext: string }

function fmtSize(b: number) {
  if (b < 1024) return `${b} B`
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(0)} KB`
  return `${(b / 1024 / 1024).toFixed(1)} MB`
}
function fmtDate(iso: string) {
  return new Date(iso).toLocaleString('en-CA', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}
const VIEWABLE = new Set(['.md', '.txt', '.json', '.yaml', '.yml', '.csv', '.log'])

export function InboxApp() {
  const [files, setFiles] = useState<InboxFile[] | null>(null)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [dragging, setDragging] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [viewing, setViewing] = useState<{ name: string; content: string | null } | null>(null)
  const fileInput = useRef<HTMLInputElement>(null)

  const load = useCallback(() => {
    fetch('/api/inbox').then(r => r.json()).then(d => {
      if (d.error) setError(d.error); else { setFiles(d.files); setSelected(new Set()) }
    }).catch(e => setError(String(e)))
  }, [])
  useEffect(() => { load() }, [load])

  async function upload(fileList: FileList | File[]) {
    const fd = new FormData()
    Array.from(fileList).forEach(f => fd.append('files', f))
    setBusy(true)
    await fetch('/api/inbox', { method: 'POST', body: fd })
    setBusy(false)
    load()
  }

  function onDrop(e: DragEvent) {
    e.preventDefault(); setDragging(false)
    if (e.dataTransfer.files?.length) upload(e.dataTransfer.files)
  }

  async function action(kind: 'ingest' | 'delete') {
    const names = [...selected]
    if (names.length === 0) return
    if (kind === 'delete' && !confirm(`Delete ${names.length} file(s)? This cannot be undone.`)) return
    setBusy(true)
    await fetch('/api/inbox/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: kind, files: names }) })
    setBusy(false)
    load()
  }

  function download() {
    for (const name of selected) window.open(`/api/inbox/file?name=${encodeURIComponent(name)}&download=1`, '_blank')
  }

  async function view() {
    const name = [...selected][0]
    if (!name) return
    setViewing({ name, content: null })
    const txt = await fetch(`/api/inbox/file?name=${encodeURIComponent(name)}`).then(r => r.text())
    setViewing({ name, content: txt })
  }

  function toggle(name: string) {
    setSelected(s => { const n = new Set(s); n.has(name) ? n.delete(name) : n.add(name); return n })
  }
  function toggleAll() {
    setSelected(s => s.size === files?.length ? new Set() : new Set(files?.map(f => f.name)))
  }

  const selCount = selected.size
  const onlyOne = selCount === 1
  const canView = onlyOne && VIEWABLE.has([...selected][0].slice([...selected][0].lastIndexOf('.')).toLowerCase())

  return (
    <div className="flex flex-col min-h-screen" style={{ background: '#f5f0e8' }}>
      <Nav />
      {viewing && (
        <MarkdownViewerOverlay
          title={viewing.name} badge="FILE" content={viewing.content} loading={viewing.content === null}
          onClose={() => setViewing(null)}
        />
      )}

      <main className="flex-1 p-5 max-w-4xl mx-auto w-full">
        <div className="mb-5">
          <h1 className="text-xl font-bold text-stone-800">Inbox — files not yet in the project</h1>
          <p className="text-sm text-stone-500 mt-1 max-w-2xl">
            A staging area for raw files. Anything here is sitting in <code>documents/inbox/</code> and is
            <b> not yet part of the project</b>. Harvested intel (Slack, Gmail, GDocs) lands here too.
          </p>
          <p className="text-xs text-stone-400 mt-1.5 max-w-2xl">
            <b>Drag &amp; drop</b> files anywhere below to add them · <b>tick</b> one or more, then
            <b> Ingest</b> (moves them into the project&rsquo;s Documents), <b>View</b>, <b>Download</b>,
            or <b>Delete</b>. Ingesting is how a file becomes a tracked project document.
          </p>
        </div>

        {error && <div className="bg-red-50 border border-red-200 p-3 mb-4 text-sm text-red-700">{error}</div>}

        {/* Action bar */}
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <button onClick={() => fileInput.current?.click()} disabled={busy}
            className="text-xs px-2.5 py-1 font-medium text-white bg-amber-700 hover:bg-amber-800 disabled:opacity-50">+ Add files</button>
          <input ref={fileInput} type="file" multiple hidden onChange={e => e.target.files && upload(e.target.files)} />
          <span className="w-px h-5 bg-stone-300 mx-1" />
          <button onClick={() => action('ingest')} disabled={busy || selCount === 0}
            className="text-xs px-2.5 py-1 font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-40">Ingest{selCount > 0 && ` (${selCount})`}</button>
          <button onClick={view} disabled={!canView}
            className="text-xs px-2.5 py-1 font-medium border border-stone-300 text-stone-600 hover:bg-stone-100 disabled:opacity-40">View</button>
          <button onClick={download} disabled={selCount === 0}
            className="text-xs px-2.5 py-1 font-medium border border-stone-300 text-stone-600 hover:bg-stone-100 disabled:opacity-40">Download</button>
          <button onClick={() => action('delete')} disabled={busy || selCount === 0}
            className="text-xs px-2.5 py-1 font-medium border border-red-300 text-red-700 hover:bg-red-50 disabled:opacity-40">Delete</button>
        </div>

        {/* Drop zone + list */}
        <div
          onDragOver={e => { e.preventDefault(); setDragging(true) }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          className={clsx('border-2 border-dashed transition-colors', dragging ? 'border-amber-500 bg-amber-50' : 'border-stone-300 bg-white')}
        >
          {!files && <div className="p-8 text-center text-sm text-stone-400 animate-pulse">Loading…</div>}

          {files && files.length === 0 && (
            <div className="p-10 text-center text-sm text-stone-400">
              {dragging ? 'Drop to add files' : 'Inbox is empty. Drag files here or use “+ Add files”.'}
            </div>
          )}

          {files && files.length > 0 && (
            <table className="w-full text-xs">
              <thead>
                <tr className="text-[10px] font-bold uppercase tracking-wide text-stone-400 border-b border-stone-200">
                  <th className="w-8 p-2"><input type="checkbox" checked={selCount === files.length} onChange={toggleAll} /></th>
                  <th className="text-left p-2">File</th>
                  <th className="text-right p-2 w-24">Size</th>
                  <th className="text-right p-2 w-36">Added</th>
                </tr>
              </thead>
              <tbody>
                {files.map(f => (
                  <tr key={f.name} className={clsx('border-b border-stone-50 hover:bg-stone-50 cursor-pointer', selected.has(f.name) && 'bg-amber-50/60')}
                    onClick={() => toggle(f.name)}>
                    <td className="p-2 text-center" onClick={e => e.stopPropagation()}>
                      <input type="checkbox" checked={selected.has(f.name)} onChange={() => toggle(f.name)} />
                    </td>
                    <td className="p-2 text-stone-700 font-medium">{f.name}</td>
                    <td className="p-2 text-right text-stone-400">{fmtSize(f.size)}</td>
                    <td className="p-2 text-right text-stone-400">{fmtDate(f.mtime)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </div>
  )
}
