'use client'

import { useEffect, useState, useCallback, useRef } from 'react'
import { clsx } from 'clsx'

interface GenDef { id: string; label: string; generator: string }
interface Job { id: string; label: string; status: string; started_at: string; finished_at?: string }

function fmtTime(iso?: string | null) {
  if (!iso) return '—'
  return new Date(iso).toLocaleString('en-CA', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}

/**
 * Self-contained "generate a report now" panel — preset generators + custom prompt,
 * with a live jobs list. Shared by the Schedule and Reports tabs.
 * - onActivity: called when a running job finishes (so the host can refresh its data).
 * - reloadKey: bump from the host to force a jobs refetch (e.g. after a row-level run).
 */
export function GeneratePanel({ onActivity, reloadKey }: { onActivity?: () => void; reloadKey?: number }) {
  const [generators, setGenerators] = useState<GenDef[]>([])
  const [jobs, setJobs] = useState<Job[]>([])
  const [selectedGen, setSelectedGen] = useState('')
  const [genMode, setGenMode] = useState<'preset' | 'custom'>('preset')
  const [customPrompt, setCustomPrompt] = useState('')
  const [busy, setBusy] = useState(false)
  const prevRunning = useRef(0)

  const loadJobs = useCallback(() => {
    fetch('/api/jobs').then(r => r.json()).then(d => {
      setJobs(d.jobs ?? [])
      setGenerators(d.generators ?? [])
      setSelectedGen(s => s || (d.generators?.[0]?.id ?? ''))
      const running = (d.jobs ?? []).filter((j: Job) => j.status === 'running').length
      if (prevRunning.current > 0 && running < prevRunning.current) onActivity?.()
      prevRunning.current = running
    }).catch(() => {})
  }, [onActivity])

  useEffect(() => { loadJobs() }, [loadJobs])
  useEffect(() => { if (reloadKey !== undefined) loadJobs() }, [reloadKey, loadJobs])
  useEffect(() => {
    if (!jobs.some(j => j.status === 'running')) return
    const t = setInterval(loadJobs, 4000)
    return () => clearInterval(t)
  }, [jobs, loadJobs])

  async function generate() {
    const body = genMode === 'custom' ? { prompt: customPrompt.trim() } : { generator_id: selectedGen }
    if (genMode === 'custom' ? !body.prompt : !selectedGen) return
    setBusy(true)
    await fetch('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    if (genMode === 'custom') setCustomPrompt('')
    setBusy(false)
    loadJobs()
  }

  const running = jobs.filter(j => j.status === 'running')

  return (
    <div className="bg-white border border-stone-200 shadow-sm mb-4 p-4">
      <h2 className="text-xs font-bold uppercase tracking-wide text-stone-500 mb-2">Generate a report now</h2>
      <p className="text-xs text-stone-500 mb-3">Runs the generator immediately; the draft appears in the Queue when done.</p>

      <div className="inline-flex mb-3 border border-stone-300">
        {(['preset', 'custom'] as const).map(m => (
          <button key={m} onClick={() => setGenMode(m)}
            className={clsx('text-xs px-3 py-1 font-medium', genMode === m ? 'bg-amber-700 text-white' : 'text-stone-500 hover:bg-stone-100')}>
            {m === 'preset' ? 'Preset report' : 'Custom prompt'}
          </button>
        ))}
      </div>

      {genMode === 'preset' ? (
        <div className="flex items-center gap-2 flex-wrap">
          <select value={selectedGen} onChange={e => setSelectedGen(e.target.value)}
            className="text-xs border border-stone-300 px-2 py-1 bg-white min-w-[16rem]">
            {generators.map(g => <option key={g.id} value={g.id}>{g.label}</option>)}
          </select>
          <button disabled={busy || !selectedGen} onClick={generate}
            className="text-xs px-2.5 py-1 font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50">Generate now</button>
          {running.length > 0 && <span className="text-xs text-amber-700 animate-pulse">{running.length} running…</span>}
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          <textarea
            value={customPrompt}
            onChange={e => setCustomPrompt(e.target.value)}
            maxLength={2000}
            rows={3}
            placeholder="Describe the report to draft, e.g. &quot;Compare M02 and M10 timelines for the board, one page.&quot;"
            className="text-xs border border-stone-300 px-2 py-1.5 bg-white resize-y focus:outline-none focus:border-amber-400"
          />
          <div className="flex items-center gap-2">
            <button disabled={busy || !customPrompt.trim()} onClick={generate}
              className="text-xs px-2.5 py-1 font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50">Draft it</button>
            <span className="text-[10px] text-stone-400">{customPrompt.length}/2000 · runs read-only + draft-only · result lands in Queue for review</span>
            {running.length > 0 && <span className="text-xs text-amber-700 animate-pulse">{running.length} running…</span>}
          </div>
        </div>
      )}

      {jobs.length > 0 && (
        <div className="mt-3 border-t border-stone-100 pt-2 flex flex-col gap-1">
          {jobs.slice(0, 5).map(j => (
            <div key={j.id} className="flex items-center justify-between text-[11px]">
              <span className="text-stone-600 truncate">{j.label}</span>
              <span className="flex items-center gap-2 shrink-0">
                <span className="text-stone-400">{fmtTime(j.finished_at ?? j.started_at)}</span>
                <span className={clsx('font-bold px-1.5 py-0.5',
                  j.status === 'running' ? 'bg-amber-100 text-amber-700' : j.status === 'done' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700')}>
                  {j.status}
                </span>
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
