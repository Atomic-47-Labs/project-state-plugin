'use client'

import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { clsx } from 'clsx'
import type { Components } from 'react-markdown'
import type { ReactNode } from 'react'

// ─── Custom renderers ─────────────────────────────────────────────────────────
// Large, well-spaced, warm-stone typography — no prose class dependency.

export const mdComponents: Components = {
  h1: ({ children }) => (
    <h1 className="text-2xl font-bold text-stone-900 mt-0 mb-5 pb-3 border-b border-stone-200 leading-tight">
      {children}
    </h1>
  ),
  h2: ({ children }) => (
    <h2 className="text-lg font-bold text-stone-800 mt-8 mb-3 pb-1.5 border-b border-stone-100 leading-tight">
      {children}
    </h2>
  ),
  h3: ({ children }) => (
    <h3 className="text-base font-semibold text-stone-700 mt-6 mb-2 leading-tight">
      {children}
    </h3>
  ),
  h4: ({ children }) => (
    <h4 className="text-sm font-semibold text-stone-600 mt-5 mb-1.5 uppercase tracking-wider">
      {children}
    </h4>
  ),
  p: ({ children }) => (
    <p className="text-sm text-stone-700 leading-7 mb-4">{children}</p>
  ),
  ul: ({ children }) => (
    <ul className="list-disc pl-6 mb-4 space-y-1.5">{children}</ul>
  ),
  ol: ({ children }) => (
    <ol className="list-decimal pl-6 mb-4 space-y-1.5">{children}</ol>
  ),
  li: ({ children }) => (
    <li className="text-sm text-stone-700 leading-6">{children}</li>
  ),
  table: ({ children }) => (
    <div className="overflow-x-auto mb-6">
      <table className="w-full border-collapse text-sm">{children}</table>
    </div>
  ),
  thead: ({ children }) => (
    <thead style={{ background: '#ede8df' }}>{children}</thead>
  ),
  th: ({ children }) => (
    <th className="border border-stone-300 px-4 py-2.5 text-left text-xs font-bold text-stone-600 uppercase tracking-wider whitespace-nowrap">
      {children}
    </th>
  ),
  td: ({ children }) => (
    <td className="border border-stone-200 px-4 py-2.5 text-sm text-stone-700 leading-5">
      {children}
    </td>
  ),
  tr: ({ children }) => (
    <tr className="even:bg-stone-50/50 hover:bg-amber-50/30 transition-colors">
      {children}
    </tr>
  ),
  code: ({ children, className }) => {
    const isBlock = className?.startsWith('language-')
    return isBlock ? (
      <code className="block bg-stone-900 text-stone-100 px-5 py-4 text-xs font-mono leading-5 overflow-x-auto rounded-none mb-4 whitespace-pre">
        {children}
      </code>
    ) : (
      <code className="bg-stone-100 text-amber-800 px-1.5 py-0.5 text-xs font-mono rounded">
        {children}
      </code>
    )
  },
  pre: ({ children }) => (
    <pre className="mb-4 overflow-hidden">{children}</pre>
  ),
  blockquote: ({ children }) => (
    <blockquote className="border-l-4 border-amber-400 pl-5 py-1 my-5 bg-amber-50/50 text-stone-600 italic">
      {children}
    </blockquote>
  ),
  hr: () => <hr className="border-stone-200 my-8" />,
  strong: ({ children }) => (
    <strong className="font-semibold text-stone-900">{children}</strong>
  ),
  em: ({ children }) => (
    <em className="italic text-stone-600">{children}</em>
  ),
  a: ({ href, children }) => (
    <a
      href={href}
      className="text-amber-700 hover:text-amber-900 underline underline-offset-2"
      target="_blank"
      rel="noreferrer"
    >
      {children}
    </a>
  ),
}

// ─── Shared markdown renderer ─────────────────────────────────────────────────

export function MarkdownContent({ content }: { content: string }) {
  return (
    <ReactMarkdown remarkPlugins={[remarkGfm]} components={mdComponents}>
      {content}
    </ReactMarkdown>
  )
}

// ─── Full-screen overlay viewer ───────────────────────────────────────────────

export interface ViewerFile {
  name: string
  ext?: string
  mtime?: string
  downloadPath?: string
}

export function MarkdownViewerOverlay({
  title,
  subtitle,
  badge,
  content,
  loading,
  downloadPath,
  headerActions,
  onClose,
}: {
  title: string
  subtitle?: string
  badge?: string
  content: string | null
  loading?: boolean
  downloadPath?: string
  headerActions?: ReactNode
  onClose: () => void
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex flex-col"
      style={{ background: 'rgba(15,10,5,0.6)' }}
    >
      <div className="m-5 flex-1 bg-white flex flex-col overflow-hidden shadow-2xl max-h-[calc(100vh-2.5rem)]">

        {/* Header */}
        <div
          className="flex items-center justify-between px-6 py-3.5 border-b border-stone-200 shrink-0"
          style={{ background: '#ede8df' }}
        >
          <div className="flex items-center gap-3 min-w-0">
            {badge && (
              <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 border bg-amber-50 text-amber-700 border-amber-200 shrink-0">
                {badge}
              </span>
            )}
            <span className="text-sm font-bold text-stone-800 truncate">{title}</span>
            {subtitle && (
              <span className="text-xs text-stone-400 shrink-0">{subtitle}</span>
            )}
          </div>
          <div className="flex items-center gap-2 shrink-0 ml-4">
            {headerActions}
            {downloadPath && (
              <a
                href={`/api/reports/download/${downloadPath}`}
                download
                className="text-xs px-2.5 py-1 bg-amber-700 text-white hover:bg-amber-800 transition-colors font-medium"
              >
                ↓ Download
              </a>
            )}
            <button
              onClick={onClose}
              className="text-xs px-2.5 py-1 text-stone-500 hover:text-stone-800 hover:bg-stone-200 transition-colors font-medium"
            >
              ✕ Close
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto px-10 py-8">
            {loading ? (
              <div className="text-sm text-stone-400 animate-pulse mt-8">Loading…</div>
            ) : (
              <MarkdownContent content={content ?? ''} />
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
