'use client'

import { useEffect, useState, useCallback } from 'react'
import { clsx } from 'clsx'
import { Nav } from '@/components/nav'
import { MarkdownViewerOverlay } from '@/components/markdown-viewer'
import { GeneratePanel } from '@/components/generate-panel'

// ─── Types ────────────────────────────────────────────────────────────────────

interface ReportFile {
  name: string
  size: number
  mtime: string
  ext: string
  downloadPath: string
}

interface Bundle {
  name: string
  date: string
  files: ReportFile[]
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmtSize(bytes: number) {
  if (bytes < 1024)        return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

function fmtDate(iso: string) {
  return new Date(iso).toLocaleDateString('en-CA', { year: 'numeric', month: 'short', day: 'numeric' })
}

const EXT_COLOR: Record<string, string> = {
  '.docx': 'bg-blue-50 text-blue-700 border-blue-200',
  '.xlsx': 'bg-emerald-50 text-emerald-700 border-emerald-200',
  '.pdf':  'bg-red-50 text-red-700 border-red-200',
  '.md':   'bg-amber-50 text-amber-700 border-amber-200',
}

function ExtBadge({ ext }: { ext: string }) {
  return (
    <span className={clsx(
      'text-[10px] font-bold uppercase px-1.5 py-0.5 border shrink-0',
      EXT_COLOR[ext] ?? 'bg-stone-100 text-stone-500 border-stone-200'
    )}>
      {ext.replace('.', '')}
    </span>
  )
}

function DownloadButton({ path, small }: { path: string; small?: boolean }) {
  return (
    <a
      href={`/api/reports/download/${path}`}
      download
      className={clsx(
        'font-medium text-white bg-amber-700 hover:bg-amber-800 transition-colors shrink-0',
        small ? 'text-[10px] px-1.5 py-0.5' : 'text-xs px-2 py-1'
      )}
    >
      ↓ Download
    </a>
  )
}

// ─── Markdown viewer panel ────────────────────────────────────────────────────

function MarkdownViewer({ file, onClose }: { file: ReportFile; onClose: () => void }) {
  const [content, setContent] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch(`/api/reports/download/${file.downloadPath}`)
      .then(r => r.text())
      .then(text => { setContent(text); setLoading(false) })
      .catch(() => { setContent('Failed to load file.'); setLoading(false) })
  }, [file.downloadPath])

  return (
    <MarkdownViewerOverlay
      title={file.name.replace('.md', '')}
      subtitle={fmtDate(file.mtime)}
      badge="MD"
      content={content}
      loading={loading}
      downloadPath={file.downloadPath}
      onClose={onClose}
    />
  )
}

// ─── Bundle card ──────────────────────────────────────────────────────────────

function BundleCard({ bundle, onView }: { bundle: Bundle; onView: (f: ReportFile) => void }) {
  const [open, setOpen] = useState(true)
  const docxCount = bundle.files.filter(f => f.ext === '.docx').length
  const xlsxCount = bundle.files.filter(f => f.ext === '.xlsx').length

  return (
    <div className="bg-white border border-stone-200 shadow-sm">
      {/* Header */}
      <button
        className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-stone-50 transition-colors"
        onClick={() => setOpen(o => !o)}
      >
        <div>
          <div className="text-sm font-bold text-stone-800">{bundle.name}</div>
          <div className="text-xs text-stone-400 mt-0.5">
            {docxCount} Word docs · {xlsxCount} Excel sheets · {bundle.files.length} files total
          </div>
        </div>
        <span className="text-stone-400 text-xs">{open ? '▲' : '▼'}</span>
      </button>

      {/* File list */}
      {open && (
        <div className="border-t border-stone-100 divide-y divide-stone-50">
          {bundle.files.map(file => (
            <div key={file.name} className="flex items-center justify-between px-4 py-2.5 hover:bg-stone-50">
              <div className="flex items-center gap-2 min-w-0">
                <ExtBadge ext={file.ext} />
                <span className="text-xs text-stone-700 font-medium truncate">{file.name}</span>
              </div>
              <div className="flex items-center gap-2 shrink-0 ml-2">
                <span className="text-[10px] text-stone-400">{fmtSize(file.size)}</span>
                {file.ext === '.md' && (
                  <button
                    onClick={() => onView(file)}
                    className="text-[10px] px-1.5 py-0.5 border border-amber-300 text-amber-700 hover:bg-amber-50 font-medium"
                  >
                    View
                  </button>
                )}
                <DownloadButton path={file.downloadPath} small />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Report row ───────────────────────────────────────────────────────────────

function ReportRow({ file, onView }: { file: ReportFile; onView: (f: ReportFile) => void }) {
  const isMarkdown = file.ext === '.md'

  return (
    <div className="flex items-center justify-between px-4 py-3 bg-white border border-stone-200 hover:bg-stone-50">
      <div className="flex items-center gap-2 min-w-0">
        <ExtBadge ext={file.ext} />
        <div className="min-w-0">
          <div className="text-xs text-stone-700 font-semibold truncate">{file.name.replace('.md', '')}</div>
          <div className="text-[10px] text-stone-400 mt-0.5">{fmtDate(file.mtime)} · {fmtSize(file.size)}</div>
        </div>
      </div>
      <div className="flex items-center gap-2 shrink-0 ml-3">
        {isMarkdown && (
          <button
            onClick={() => onView(file)}
            className="text-xs px-2 py-1 border border-amber-300 text-amber-700 hover:bg-amber-50 transition-colors font-medium"
          >
            View
          </button>
        )}
        <DownloadButton path={file.downloadPath} small />
      </div>
    </div>
  )
}

// ─── Tabs ─────────────────────────────────────────────────────────────────────

type Tab = 'bundles' | 'weekly' | 'adhoc'

// ─── Main app ─────────────────────────────────────────────────────────────────

export function ReportsApp({ embedded }: { embedded?: boolean } = {}) {
  const [bundles,   setBundles]   = useState<Bundle[]>([])
  const [weeklies,  setWeeklies]  = useState<ReportFile[]>([])
  const [adhocs,    setAdhocs]    = useState<ReportFile[]>([])
  const [loading,   setLoading]   = useState(true)
  const [error,     setError]     = useState<string | null>(null)
  const [tab,       setTab]       = useState<Tab>('bundles')
  const [viewing,   setViewing]   = useState<ReportFile | null>(null)
  const [projectName, setProjectName] = useState<string>()

  const loadReports = useCallback(() => {
    fetch('/api/reports').then(r => r.json()).then(rData => {
      setBundles(rData.bundles  ?? [])
      setWeeklies(rData.weeklies ?? [])
      setAdhocs(rData.adhocs   ?? [])
      setLoading(false)
    }).catch(e => { setError(String(e)); setLoading(false) })
  }, [])

  useEffect(() => {
    loadReports()
    fetch('/api/dashboard').then(r => r.json()).then(d => setProjectName(d?.project?.name)).catch(() => {})
  }, [loadReports])

  const TABS: { id: Tab; label: string; count: number }[] = [
    { id: 'bundles', label: 'Baseline Bundles', count: bundles.length },
    { id: 'weekly',  label: 'Weekly Reports',   count: weeklies.length },
    { id: 'adhoc',   label: 'Ad-hoc',           count: adhocs.length },
  ]

  return (
    <div className={embedded ? '' : 'flex flex-col min-h-screen'} style={embedded ? undefined : { background: '#f5f0e8' }}>
      {!embedded && <Nav projectName={projectName} />}

      {/* Markdown viewer overlay */}
      {viewing && <MarkdownViewer file={viewing} onClose={() => setViewing(null)} />}

      <main className="flex-1 p-5 max-w-4xl mx-auto w-full">
        {/* Page header */}
        <div className="mb-5">
          <h1 className="text-xl font-bold text-stone-800">Reports — generated outputs, archived</h1>
          <p className="text-sm text-stone-500 mt-1 max-w-2xl">
            The library of reports the project has produced: baseline bundles, weekly reports, and ad-hoc pieces.
          </p>
          <p className="text-xs text-stone-400 mt-1.5 max-w-2xl">
            <b>View</b> markdown reports inline · <b>Download</b> Word/Excel files · or <b>generate a new
            report</b> below — pick a preset or write a custom prompt. Drafts arrive in the Queue for review first.
          </p>
        </div>

        {/* Generate a report (preset or custom prompt) */}
        <GeneratePanel onActivity={loadReports} />

        {/* Tabs */}
        <div
          className="flex items-end gap-0 mb-4 border-b border-stone-200"
          style={{ background: '#ede8df' }}
        >
          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={clsx(
                'px-4 py-2 text-xs font-semibold transition-colors border-b-2 -mb-px',
                tab === t.id
                  ? 'border-amber-600 text-amber-800 bg-white'
                  : 'border-transparent text-stone-500 hover:text-stone-700'
              )}
            >
              {t.label}
              <span className={clsx(
                'ml-1.5 px-1.5 py-0.5 text-[10px] font-bold',
                tab === t.id ? 'bg-amber-100 text-amber-700' : 'bg-stone-200 text-stone-500'
              )}>
                {t.count}
              </span>
            </button>
          ))}
        </div>

        {loading && (
          <div className="flex items-center justify-center h-48">
            <span className="text-sm text-stone-400 animate-pulse">Loading reports…</span>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 p-4 text-sm text-red-700">{error}</div>
        )}

        {!loading && !error && (
          <>
            {tab === 'bundles' && (
              <div className="flex flex-col gap-3">
                <p className="text-xs text-stone-400 italic">
                  Word and Excel files are download-only. Open in Microsoft Office or compatible application.
                </p>
                {bundles.length === 0 && (
                  <p className="text-sm text-stone-400 italic">No baseline bundles found.</p>
                )}
                {bundles.map(b => (
                  <BundleCard key={b.name} bundle={b} onView={setViewing} />
                ))}
              </div>
            )}

            {tab === 'weekly' && (
              <div className="flex flex-col gap-2">
                {weeklies.length === 0 && (
                  <p className="text-sm text-stone-400 italic">No weekly reports found.</p>
                )}
                {weeklies.map(f => (
                  <ReportRow key={f.name} file={f} onView={setViewing} />
                ))}
              </div>
            )}

            {tab === 'adhoc' && (
              <div className="flex flex-col gap-2">
                {adhocs.length === 0 && (
                  <p className="text-sm text-stone-400 italic">No ad-hoc reports found.</p>
                )}
                {adhocs.map(f => (
                  <ReportRow key={f.name} file={f} onView={setViewing} />
                ))}
              </div>
            )}
          </>
        )}
      </main>
    </div>
  )
}
