'use client'

import { useEffect, useState } from 'react'
import { clsx } from 'clsx'
import { Nav } from '@/components/nav'
import { ScheduleApp } from '@/components/schedule-app'
import { QueueApp } from '@/components/queue-app'
import { ReportsApp } from '@/components/reports-app'

type Tab = 'schedule' | 'queue' | 'reports'

function daysUntil(iso?: string | null): number | null {
  if (!iso) return null
  return Math.ceil((new Date(iso).getTime() - Date.now()) / 86_400_000)
}

export function ReportingApp() {
  const [tab, setTab] = useState<Tab>('queue')
  const [counts, setCounts] = useState<{ schedule: number; queue: number; reports: number }>({ schedule: 0, queue: 0, reports: 0 })
  const [projectName, setProjectName] = useState<string>()

  function loadCounts() {
    fetch('/api/outbox').then(r => r.json())
      .then(d => setCounts(c => ({ ...c, queue: Array.isArray(d?.queued) ? d.queued.length : 0 })))
      .catch(() => {})
    fetch('/api/schedule').then(r => r.json())
      .then(d => {
        // "new items" on Schedule = entries due now (next_due today or overdue).
        const due = (d?.entries ?? []).filter((e: { next_due?: string | null; event_driven?: boolean }) => {
          const n = daysUntil(e.next_due); return !e.event_driven && n !== null && n <= 0
        }).length
        setCounts(c => ({ ...c, schedule: due }))
      }).catch(() => {})
    fetch('/api/reports').then(r => r.json())
      .then(d => setCounts(c => ({ ...c, reports: (d?.weeklies?.length ?? 0) + (d?.adhocs?.length ?? 0) + (d?.bundles?.length ?? 0) })))
      .catch(() => {})
  }

  useEffect(() => {
    loadCounts()
    fetch('/api/dashboard').then(r => r.json()).then(d => setProjectName(d?.project?.name)).catch(() => {})
    const t = setInterval(loadCounts, 8000)
    return () => clearInterval(t)
  }, [])

  const TABS: { id: Tab; label: string; count: number }[] = [
    { id: 'schedule', label: 'Schedule', count: counts.schedule },
    { id: 'queue',    label: 'Queue',    count: counts.queue },
    { id: 'reports',  label: 'Reports',  count: counts.reports },
  ]

  return (
    <div className="flex flex-col min-h-screen" style={{ background: '#f5f0e8' }}>
      <Nav projectName={projectName} />

      {/* Tab bar */}
      <div className="flex items-center gap-0 px-4 border-b border-stone-200 shrink-0" style={{ background: '#ede8df' }}>
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={clsx(
              'px-4 py-2.5 text-xs font-semibold border-b-2 -mb-px transition-colors inline-flex items-center gap-2',
              tab === t.id ? 'border-amber-600 text-amber-800 bg-white' : 'border-transparent text-stone-500 hover:text-stone-800'
            )}
          >
            {t.label}
            {t.count > 0 && (
              <span className={clsx(
                'text-[10px] font-bold px-1.5 py-0.5 rounded-full leading-none',
                tab === t.id ? 'bg-amber-100 text-amber-700' : 'bg-amber-600 text-white'
              )}>
                {t.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Active tab body (embedded — no inner Nav) */}
      <div className="flex-1">
        {tab === 'schedule' && <ScheduleApp embedded />}
        {tab === 'queue' && <QueueApp embedded />}
        {tab === 'reports' && <ReportsApp embedded />}
      </div>
    </div>
  )
}
