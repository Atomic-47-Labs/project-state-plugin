'use client'

import { useEffect, useState } from 'react'
import { clsx } from 'clsx'
import { Nav } from '@/components/nav'
import { fmtDate, fmtDateShort, statusColor, riskScoreColor } from '@/lib/utils'

// ─── Types ────────────────────────────────────────────────────────────────────

interface DashboardData {
  project:   { name: string; long_name: string; one_liner: string; phase: string; start_date: string | null; end_date: string | null; packs_loaded: string[] }
  milestones: { total: number; complete: number; in_progress: number; at_risk: number; planned: number; overall_pct: number }
  risks:      { total: number; open: number; high: number; med: number }
  decisions:  { total: number; material: number }
  activity:   ActivityEntry[]
  top_risks:  Risk[]
  recent_decisions: Decision[]
}

interface ActivityEntry { ts: string; actor: string; event: string; detail?: string; id?: string; title?: string }
interface Risk { id: string; title: string; score: number; likelihood: string; impact: string; owner: string; status: string; mitigation: string }
interface Decision { date: string; title: string; decision: string; material_change: boolean }

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatCard({ label, value, sub, color, accent }: { label: string; value: string | number; sub?: string; color?: string; accent?: boolean }) {
  return (
    <div className={clsx(
      'border p-4 shadow-sm flex flex-col gap-1',
      accent ? 'bg-amber-50 border-amber-200' : 'bg-white border-stone-200'
    )}>
      <div className={clsx('text-xs font-semibold uppercase tracking-wider', accent ? 'text-amber-600' : 'text-stone-400')}>{label}</div>
      <div className="text-3xl font-bold tabular-nums" style={{ color: color ?? (accent ? '#b45309' : '#1c1412') }}>{value}</div>
      {sub && <div className={clsx('text-xs', accent ? 'text-amber-600/70' : 'text-stone-400')}>{sub}</div>}
    </div>
  )
}

function Section({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="bg-white border border-stone-200 shadow-sm overflow-hidden">
      <div className="px-5 py-3.5 border-b border-stone-100">
        <h2 className="text-sm font-bold text-stone-700">{title}</h2>
        {subtitle && <p className="text-xs text-stone-400 mt-0.5">{subtitle}</p>}
      </div>
      <div className="p-5">{children}</div>
    </div>
  )
}

function MilestoneBar({ pct, status }: { pct: number; status: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 bg-stone-100 overflow-hidden">
        <div className="h-full" style={{ width: `${pct}%`, backgroundColor: statusColor(status) }} />
      </div>
      <span className="text-xs font-mono w-8 text-right" style={{ color: statusColor(status) }}>{pct}%</span>
    </div>
  )
}

function ActivityFeed({ entries }: { entries: ActivityEntry[] }) {
  if (!entries.length) return <div className="text-xs text-stone-300 italic">No activity yet.</div>
  return (
    <div className="space-y-2">
      {entries.map((e, i) => (
        <div key={i} className="flex items-start gap-3 text-xs">
          <span className="text-stone-300 shrink-0 font-mono mt-0.5">
            {e.ts ? fmtDateShort(e.ts.split('T')[0]) : '—'}
          </span>
          <div className="flex-1 min-w-0">
            <span className="font-mono text-stone-500">{e.event}</span>
            {e.detail && <span className="text-stone-400"> — {e.detail}</span>}
            {e.title && <span className="text-stone-500"> · {e.title}</span>}
          </div>
        </div>
      ))}
    </div>
  )
}

function RiskRow({ risk }: { risk: Risk }) {
  const color = riskScoreColor(risk.score || 0)
  return (
    <div className="flex items-center gap-3 py-2 border-b border-stone-50 last:border-0">
      <span
        className="text-xs font-bold font-mono w-6 h-6 flex items-center justify-center shrink-0"
        style={{ backgroundColor: color + '20', color }}
      >
        {risk.score}
      </span>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-semibold text-stone-700 truncate">{risk.title}</div>
        <div className="text-xs text-stone-400">{risk.owner || '—'}</div>
      </div>
    </div>
  )
}

// ─── Main ─────────────────────────────────────────────────────────────────────

export function DashboardApp() {
  const [data, setData]       = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError]     = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/dashboard')
      .then(r => r.json())
      .then(d => { if (d.error) setError(d.error); else setData(d); setLoading(false) })
      .catch(e => { setError(String(e)); setLoading(false) })
  }, [])

  return (
    <div className="flex flex-col min-h-screen" style={{ background: '#f5f0e8' }}>
      <Nav projectName={data?.project.name} />

      <main className="flex-1 p-5 max-w-[1400px] mx-auto w-full space-y-5">
        {loading && (
          <div className="flex items-center justify-center h-64">
            <span className="text-sm text-stone-400 animate-pulse">Loading dashboard…</span>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 p-4 text-sm text-red-700">{error}</div>
        )}

        {!loading && data && (
          <>
            {/* Project header */}
            <div>
              <div className="text-xs text-stone-400 font-mono mb-1">
                Phase: <span className="text-sky-600 font-bold">{data.project.phase}</span>
                {data.project.packs_loaded?.length > 0 && (
                  <> · Packs: {data.project.packs_loaded.join(', ')}</>
                )}
              </div>
              <h1 className="text-xl font-bold text-stone-800">{data.project.long_name || data.project.name}</h1>
              {data.project.one_liner && (
                <p className="text-sm text-stone-500 mt-1">{data.project.one_liner}</p>
              )}
              <p className="text-xs text-stone-400 mt-1.5 max-w-2xl">
                Dashboard — the at-a-glance health view: phase, milestone progress, risk heatmap, and the
                recent activity timeline. Read-only · use Kanban to change milestones, Schedule to generate reports.
              </p>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <StatCard
                label="Overall progress"
                value={`${data.milestones.overall_pct}%`}
                sub={`${data.milestones.complete}/${data.milestones.total} milestones complete`}
                accent
              />
              <StatCard
                label="In progress"
                value={data.milestones.in_progress}
                sub={`${data.milestones.at_risk} at risk`}
                color={data.milestones.at_risk > 0 ? '#f59e0b' : '#0ea5e9'}
              />
              <StatCard
                label="Open risks"
                value={data.risks.open}
                sub={`${data.risks.high} high · ${data.risks.med} med`}
                color={data.risks.high > 0 ? '#ef4444' : data.risks.med > 0 ? '#f59e0b' : '#22c55e'}
              />
              <StatCard
                label="Decisions"
                value={data.decisions.total}
                sub={`${data.decisions.material} material changes`}
                color="#6366f1"
              />
            </div>

            {/* Middle row: milestone overview + top risks */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              <div className="lg:col-span-2">
                <Section title="Milestone Status" subtitle="overall completion by status group">
                  <div className="space-y-3">
                    {[
                      { label: 'Complete',    count: data.milestones.complete,    status: 'complete',    pct: data.milestones.total > 0 ? Math.round(data.milestones.complete / data.milestones.total * 100) : 0 },
                      { label: 'In Progress', count: data.milestones.in_progress, status: 'in_progress', pct: data.milestones.total > 0 ? Math.round(data.milestones.in_progress / data.milestones.total * 100) : 0 },
                      { label: 'At Risk',     count: data.milestones.at_risk,     status: 'at_risk',     pct: data.milestones.total > 0 ? Math.round(data.milestones.at_risk / data.milestones.total * 100) : 0 },
                      { label: 'Planned',     count: data.milestones.planned,     status: 'planned',     pct: data.milestones.total > 0 ? Math.round(data.milestones.planned / data.milestones.total * 100) : 0 },
                    ].map(row => (
                      <div key={row.status}>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-stone-600 font-medium">{row.label}</span>
                          <span className="text-stone-400 tabular-nums">{row.count}</span>
                        </div>
                        <MilestoneBar pct={row.pct} status={row.status} />
                      </div>
                    ))}
                  </div>
                </Section>
              </div>

              <Section title="Top Risks" subtitle="by score · open only">
                {data.top_risks.length === 0
                  ? <div className="text-xs text-stone-300 italic">No open risks.</div>
                  : data.top_risks.map(r => <RiskRow key={r.id} risk={r} />)
                }
              </Section>
            </div>

            {/* Activity + decisions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <Section title="Activity Log" subtitle="recent project-state events">
                <ActivityFeed entries={data.activity} />
              </Section>

              <Section title="Recent Decisions" subtitle="latest logged decisions">
                {data.recent_decisions.length === 0
                  ? <div className="text-xs text-stone-300 italic">No decisions logged yet.</div>
                  : (
                    <div className="space-y-3">
                      {data.recent_decisions.map((d, i) => (
                        <div key={i} className="border-b border-stone-50 pb-3 last:border-0 last:pb-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <span className="text-xs font-semibold text-stone-700">{d.title}</span>
                            {d.material_change && (
                              <span className="text-xs bg-amber-50 text-amber-700 border border-amber-200 px-1.5 py-0.5 shrink-0">material</span>
                            )}
                          </div>
                          <div className="text-xs text-stone-500 leading-relaxed line-clamp-2">{d.decision}</div>
                          <div className="text-xs text-stone-300 mt-1">{fmtDate(d.date)}</div>
                        </div>
                      ))}
                    </div>
                  )
                }
              </Section>
            </div>
          </>
        )}
      </main>
    </div>
  )
}
