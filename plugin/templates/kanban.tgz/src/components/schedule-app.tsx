'use client'

import { useEffect, useState, useCallback } from 'react'
import { clsx } from 'clsx'
import { Nav } from '@/components/nav'
import { GeneratePanel } from '@/components/generate-panel'

interface Entry {
  id: string
  report: string
  stakeholder_group?: string
  generator?: string
  profile?: string
  surface?: string
  format?: string
  cadence_label: string
  event_driven: boolean
  next_due: string | null
  last_run: string | null
  enabled: boolean
  runnable: boolean
}

interface CronStatus { registered: boolean; paused: boolean; schedule: string | null }
interface GenDef { id: string; label: string; generator: string }
interface Job { id: string; label: string; generator: string; status: string; started_at: string; finished_at?: string; error?: string }

const SCHEDULE_PRESETS = [
  { label: 'Weekdays 07:00', expr: '0 7 * * 1-5' },
  { label: 'Daily 07:00', expr: '0 7 * * *' },
  { label: 'Mondays 07:00', expr: '0 7 * * 1' },
  { label: 'Hourly (testing)', expr: '0 * * * *' },
]

function fmtDate(iso?: string | null) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString('en-CA', { year: 'numeric', month: 'short', day: 'numeric' })
}
function fmtTime(iso?: string | null) {
  if (!iso) return '—'
  return new Date(iso).toLocaleString('en-CA', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}
function daysUntil(iso?: string | null): number | null {
  if (!iso) return null
  return Math.ceil((new Date(iso).getTime() - Date.now()) / 86_400_000)
}

function DueBadge({ next_due, event_driven }: { next_due: string | null; event_driven: boolean }) {
  if (event_driven) return <span className="text-[10px] font-bold px-1.5 py-0.5 bg-stone-100 text-stone-500">event-driven</span>
  const d = daysUntil(next_due)
  if (d === null) return <span className="text-[10px] text-stone-400">—</span>
  const tone = d <= 0 ? 'bg-red-100 text-red-700' : d <= 3 ? 'bg-amber-100 text-amber-700' : 'bg-emerald-50 text-emerald-700'
  return <span className={clsx('text-[10px] font-bold px-1.5 py-0.5', tone)}>{d <= 0 ? 'due today' : `in ${d}d`}</span>
}

function Btn({ children, onClick, tone = 'neutral', disabled }: { children: React.ReactNode; onClick: () => void; tone?: 'go' | 'warn' | 'neutral'; disabled?: boolean }) {
  const tones = {
    go: 'text-white bg-emerald-700 hover:bg-emerald-800',
    warn: 'text-white bg-red-700 hover:bg-red-800',
    neutral: 'text-stone-600 border border-stone-300 hover:bg-stone-100',
  }
  return <button disabled={disabled} onClick={onClick} className={clsx('text-xs px-2.5 py-1 font-medium disabled:opacity-50', tones[tone])}>{children}</button>
}

export function ScheduleApp({ embedded }: { embedded?: boolean } = {}) {
  const [entries, setEntries] = useState<Entry[] | null>(null)
  const [lastTick, setLastTick] = useState<string | null>(null)
  const [cron, setCron] = useState<CronStatus | null>(null)
  const [selectedSched, setSelectedSched] = useState(SCHEDULE_PRESETS[0].expr)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [genReloadKey, setGenReloadKey] = useState(0)
  const [projectName, setProjectName] = useState<string>()

  const loadSchedule = useCallback(() => {
    fetch('/api/schedule').then(r => r.json()).then(s => {
      if (s.error) { setError(s.error); return }
      setEntries(s.entries ?? []); setLastTick(s.last_tick ?? null)
    }).catch(e => setError(String(e)))
  }, [])

  useEffect(() => {
    loadSchedule()
    fetch('/api/schedule/cron').then(r => r.json()).then(setCron).catch(() => {})
    fetch('/api/dashboard').then(r => r.json()).then(d => setProjectName(d?.project?.name)).catch(() => {})
  }, [loadSchedule])

  async function cronAction(action: string, schedule?: string) {
    setBusy(true)
    const r = await fetch('/api/schedule/cron', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, schedule }) }).then(r => r.json())
    if (r.error) setError(r.error); else setCron(r)
    setBusy(false)
  }

  async function generateEntry(matrix_entry_id: string) {
    setBusy(true)
    await fetch('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ matrix_entry_id }) })
    setBusy(false)
    setGenReloadKey(k => k + 1) // surface the new job in the GeneratePanel
  }

  async function toggleEntry(id: string, enabled: boolean) {
    await fetch('/api/schedule', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, enabled }) })
    loadSchedule()
  }

  return (
    <div className={embedded ? '' : 'flex flex-col min-h-screen'} style={embedded ? undefined : { background: '#f5f0e8' }}>
      {!embedded && <Nav projectName={projectName} />}
      <main className="flex-1 p-5 max-w-4xl mx-auto w-full">
        <div className="mb-5">
          <h1 className="text-xl font-bold text-stone-800">Schedule — what gets drafted, and when</h1>
          <p className="text-sm text-stone-500 mt-1 max-w-2xl">
            This is the control room for automated reporting. Set reports to draft on a recurring
            schedule, or generate any of them right now. Whatever runs produces a <b>draft</b> in the
            Queue for you to review — it never sends anything.
          </p>
          <p className="text-xs text-stone-400 mt-1.5 max-w-2xl">
            <b>Automation</b> registers a cron that drafts whatever is due · <b>Generate now</b> runs a
            report on demand · the table&rsquo;s <b>toggles</b> turn each report on or off and
            <b> Generate ▸</b> runs one immediately. Last automated run: {fmtDate(lastTick)}.
          </p>
        </div>

        {error && <div className="bg-red-50 border border-red-200 p-3 mb-4 text-sm text-red-700">{error}</div>}

        {/* ── Automation (cron) ─────────────────────────────────────────── */}
        <div className="bg-white border border-stone-200 shadow-sm mb-4 p-4">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-xs font-bold uppercase tracking-wide text-stone-500">Automation</h2>
            {cron && (
              <span className={clsx('text-[10px] font-bold px-2 py-0.5',
                !cron.registered ? 'bg-stone-100 text-stone-500' : cron.paused ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700')}>
                {!cron.registered ? 'not scheduled' : cron.paused ? 'paused' : 'active'}
              </span>
            )}
          </div>
          <p className="text-xs text-stone-500 mb-3">
            Registers a cron on this machine that runs <code className="text-stone-600">project-orchestrator tick</code>,
            which drafts whatever is due. {cron?.schedule && <>Current: <code className="text-stone-600">{cron.schedule}</code>.</>}
          </p>
          <div className="flex items-center gap-2 flex-wrap">
            <select value={selectedSched} onChange={e => setSelectedSched(e.target.value)}
              className="text-xs border border-stone-300 px-2 py-1 bg-white">
              {SCHEDULE_PRESETS.map(p => <option key={p.expr} value={p.expr}>{p.label} ({p.expr})</option>)}
            </select>
            <Btn tone="go" disabled={busy} onClick={() => cronAction('register', selectedSched)}>
              {cron?.registered ? 'Update schedule' : 'Register cron'}
            </Btn>
            {cron?.registered && !cron.paused && <Btn disabled={busy} onClick={() => cronAction('pause')}>Pause</Btn>}
            {cron?.registered && cron.paused && <Btn tone="go" disabled={busy} onClick={() => cronAction('resume')}>Resume</Btn>}
            {cron?.registered && <Btn tone="warn" disabled={busy} onClick={() => cronAction('remove')}>Remove</Btn>}
          </div>
        </div>

        {/* ── Generate now (shared panel) ───────────────────────────────── */}
        <GeneratePanel onActivity={loadSchedule} reloadKey={genReloadKey} />

        {/* ── Matrix table ──────────────────────────────────────────────── */}
        {!entries && !error && <div className="flex items-center justify-center h-32"><span className="text-sm text-stone-400 animate-pulse">Loading…</span></div>}
        {entries && entries.length === 0 && <p className="text-sm text-stone-400 italic">No reporting-matrix entries found.</p>}
        {entries && entries.length > 0 && (
          <div className="bg-white border border-stone-200 shadow-sm divide-y divide-stone-100">
            <div className="grid grid-cols-12 gap-2 px-4 py-2 text-[10px] font-bold uppercase tracking-wide text-stone-400 bg-stone-50">
              <div className="col-span-1">On</div>
              <div className="col-span-4">Report</div>
              <div className="col-span-2">Cadence</div>
              <div className="col-span-1 text-center">Next</div>
              <div className="col-span-2 text-right">Last run</div>
              <div className="col-span-2 text-right">Action</div>
            </div>
            {entries.map(e => (
              <div key={e.id} className={clsx('grid grid-cols-12 gap-2 px-4 py-3 items-center hover:bg-stone-50', !e.enabled && 'opacity-50')}>
                <div className="col-span-1">
                  <button
                    onClick={() => toggleEntry(e.id, !e.enabled)}
                    className={clsx('w-9 h-5 rounded-full transition-colors relative', e.enabled ? 'bg-emerald-600' : 'bg-stone-300')}
                    title={e.enabled ? 'Enabled — click to disable' : 'Disabled — click to enable'}
                  >
                    <span className={clsx('absolute top-0.5 w-4 h-4 bg-white rounded-full transition-all', e.enabled ? 'left-[1.15rem]' : 'left-0.5')} />
                  </button>
                </div>
                <div className="col-span-4 min-w-0">
                  <div className="text-xs font-semibold text-stone-800 truncate">{e.report}</div>
                  <div className="text-[10px] text-stone-400 font-mono truncate">{e.generator ?? '—'}</div>
                </div>
                <div className="col-span-2 text-[11px] text-stone-500">{e.cadence_label}</div>
                <div className="col-span-1 text-center"><DueBadge next_due={e.next_due} event_driven={e.event_driven} /></div>
                <div className="col-span-2 text-right text-[11px] text-stone-500">{fmtDate(e.last_run)}</div>
                <div className="col-span-2 flex justify-end">
                  {e.runnable ? (
                    <button
                      onClick={() => generateEntry(e.id)}
                      disabled={busy}
                      className="text-[11px] px-2 py-1 font-medium text-amber-700 border border-amber-300 hover:bg-amber-50 disabled:opacity-50"
                      title={`Run ${e.generator} now — drafts into the Queue`}
                    >
                      Generate ▸
                    </button>
                  ) : (
                    <span className="text-[10px] text-stone-300 italic" title="No runnable generator for this entry">—</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
