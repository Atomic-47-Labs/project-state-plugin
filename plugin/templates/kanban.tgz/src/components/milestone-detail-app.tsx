'use client'

import { useEffect, useMemo, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { clsx } from 'clsx'
import { fmtDate, daysUntil, statusColor, riskScoreColor } from '@/lib/utils'

// ─── Types ────────────────────────────────────────────────────────────────────

interface Deliverable {
  id?: string
  title: string
  status: string
  description?: string
  due_date?: string
  owner?: string
}

interface Milestone {
  id: string
  title: string
  status: string
  percent_complete: number
  planned_start?: string
  planned_end?: string
  owner_person?: string
  owner_org?: string
  description?: string
  technical_progress?: string
  deliverables?: Deliverable[]
  tags?: string[]
  last_modified?: string
}

interface ActivityEntry {
  ts: string
  actor: string
  event: string
  id?: string
  detail?: string
  summary?: string
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60_000)
  if (mins < 1)  return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24)  return `${hrs}h ago`
  const days = Math.floor(hrs / 24)
  if (days < 30) return `${days}d ago`
  return `${Math.floor(days / 30)}mo ago`
}

function formatDateTime(iso: string): string {
  const d = new Date(iso)
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    + ' · '
    + d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

// ─── Tooltip ──────────────────────────────────────────────────────────────────

function Tooltip({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <span className="relative group inline-flex">
      {children}
      <span className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-50 bg-stone-900 text-stone-100 text-xs px-2.5 py-1.5 shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-150">
        {label}
        <span className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-stone-900" />
      </span>
    </span>
  )
}

// ─── StatCard ─────────────────────────────────────────────────────────────────

function StatCard({ label, value, sub, accent = false }: { label: string; value: string | number; sub?: string; accent?: boolean }) {
  return (
    <div className={clsx('border p-4 flex flex-col gap-1', accent ? 'bg-amber-50 border-amber-200' : 'bg-white border-stone-200')}>
      <div className={clsx('text-2xl font-bold tabular-nums leading-none', accent ? 'text-amber-700' : 'text-stone-800')}>
        {value}
      </div>
      <div className="text-xs text-stone-500">{label}</div>
      {sub && <div className="text-xs text-stone-400 mt-0.5">{sub}</div>}
    </div>
  )
}

// ─── BreakdownBar ─────────────────────────────────────────────────────────────

function BreakdownBar({ label, count, max, colorClass, sub }: { label: string; count: number; max: number; colorClass: string; sub?: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-stone-500 w-20 shrink-0 truncate">{label}</span>
      <div className="flex-1 bg-stone-100 h-2 overflow-hidden">
        <div className={clsx('h-full transition-all', colorClass)} style={{ width: max > 0 ? `${(count / max) * 100}%` : '0%' }} />
      </div>
      <span className="text-xs text-stone-500 w-6 text-right tabular-nums shrink-0">{count}</span>
      {sub && <span className="text-xs text-stone-400 shrink-0">{sub}</span>}
    </div>
  )
}

// ─── ActivityHeatmap ──────────────────────────────────────────────────────────

function ActivityHeatmap({ activity }: { activity: ActivityEntry[] }) {
  const cells = useMemo(() => {
    const map: Record<string, number> = {}
    for (const e of activity) {
      const d = e.ts?.split('T')[0]
      if (d) map[d] = (map[d] || 0) + 1
    }
    const result: { date: string; count: number }[] = []
    const now = new Date()
    for (let i = 89; i >= 0; i--) {
      const d = new Date(now)
      d.setDate(d.getDate() - i)
      const key = d.toISOString().split('T')[0]
      result.push({ date: key, count: map[key] || 0 })
    }
    return result
  }, [activity])

  const max = Math.max(...cells.map(c => c.count), 1)
  const intensity = (n: number) => {
    if (n === 0) return 'bg-stone-100'
    const p = n / max
    if (p < 0.25) return 'bg-amber-200'
    if (p < 0.5)  return 'bg-amber-300'
    if (p < 0.75) return 'bg-amber-400'
    return 'bg-amber-500'
  }

  return (
    <div className="flex gap-px flex-wrap">
      {cells.map(({ date, count }) => (
        <Tooltip key={date} label={`${date}: ${count} update${count !== 1 ? 's' : ''}`}>
          <div className={clsx('w-3 h-3 cursor-default transition-colors', intensity(count))} />
        </Tooltip>
      ))}
    </div>
  )
}

// ─── Deliverable status colors ────────────────────────────────────────────────

const DEL_STATUS: Record<string, { bar: string; badge: string }> = {
  complete:    { bar: 'bg-emerald-400', badge: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  in_progress: { bar: 'bg-sky-400',     badge: 'bg-sky-50 text-sky-700 border-sky-200' },
  at_risk:     { bar: 'bg-amber-400',   badge: 'bg-amber-50 text-amber-700 border-amber-200' },
  planned:     { bar: 'bg-stone-300',   badge: 'bg-stone-50 text-stone-500 border-stone-200' },
  blocked:     { bar: 'bg-red-400',     badge: 'bg-red-50 text-red-700 border-red-200' },
}

// ─── Main ─────────────────────────────────────────────────────────────────────

export function MilestoneDetailApp() {
  const params  = useParams()
  const router  = useRouter()
  const id      = typeof params.id === 'string' ? params.id : ''

  const [milestone, setMilestone] = useState<Milestone | null>(null)
  const [activity, setActivity]   = useState<ActivityEntry[]>([])
  const [loading, setLoading]     = useState(true)
  const [error, setError]         = useState<string | null>(null)
  const [search, setSearch]       = useState('')

  useEffect(() => {
    fetch(`/api/milestones/${id}`)
      .then(r => r.json())
      .then(d => {
        if (d.error) { setError(d.error); setLoading(false); return }
        setMilestone(d.milestone)
        setActivity(d.activity || [])
        setLoading(false)
      })
      .catch(e => { setError(String(e)); setLoading(false) })
  }, [id])

  const filteredActivity = useMemo(() => {
    if (!search.trim()) return activity
    const q = search.trim().toLowerCase()
    return activity.filter(e =>
      (e.summary || e.detail || e.event || '').toLowerCase().includes(q) ||
      (e.actor || '').toLowerCase().includes(q)
    )
  }, [activity, search])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full" style={{ background: '#f5f0e8' }}>
        <span className="text-sm text-stone-400 animate-pulse">Loading milestone…</span>
      </div>
    )
  }

  if (error || !milestone) {
    return (
      <div className="flex items-center justify-center h-full" style={{ background: '#f5f0e8' }}>
        <div className="bg-red-50 border border-red-200 p-5 max-w-md">
          <p className="text-sm text-red-600 font-semibold mb-1">Milestone not found</p>
          <p className="text-xs text-red-400 font-mono">{error}</p>
          <button onClick={() => router.push('/kanban')} className="mt-3 text-xs text-stone-500 hover:text-stone-800 underline">← Back to Kanban</button>
        </div>
      </div>
    )
  }

  const deliverables = milestone.deliverables || []
  const doneCount    = deliverables.filter(d => d.status === 'complete').length
  const daysLeft     = daysUntil(milestone.planned_end)
  const color        = statusColor(milestone.status)

  // Deliverable breakdown by status
  const delByStatus = ['complete', 'in_progress', 'at_risk', 'planned', 'blocked'].map(s => ({
    status: s,
    count: deliverables.filter(d => d.status === s).length,
  })).filter(x => x.count > 0)
  const delMax = Math.max(...delByStatus.map(x => x.count), 1)

  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ background: '#f5f0e8' }}>

      {/* ── Header ── */}
      <div className="shrink-0 border-b border-stone-300 px-5 py-3 flex items-center gap-4" style={{ background: '#ede8df' }}>
        <button
          onClick={() => router.back()}
          className="text-xs text-stone-500 hover:text-stone-800 hover:bg-stone-200/60 px-2 py-1 transition-colors shrink-0"
        >
          ← Back
        </button>

        <div className="h-4 w-px bg-stone-300" />

        <div className="flex items-center gap-2 flex-wrap flex-1 min-w-0">
          <span className="text-xs font-mono font-bold text-stone-400">{milestone.id}</span>
          <span className="text-sm font-bold text-stone-800 truncate">{milestone.title}</span>
          <div className="h-3 w-px bg-stone-300" />
          <span className="text-xs px-2 py-px font-semibold text-white" style={{ backgroundColor: color }}>
            {milestone.status.replace('_', ' ')}
          </span>
          {daysLeft !== null && milestone.status !== 'complete' && (
            <span className={clsx('text-xs px-2 py-px font-semibold border',
              daysLeft < 0  ? 'bg-red-50 text-red-700 border-red-200' :
              daysLeft < 14 ? 'bg-amber-50 text-amber-700 border-amber-200' :
              'bg-stone-50 text-stone-500 border-stone-200'
            )}>
              {daysLeft < 0 ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d left`}
            </span>
          )}
          {milestone.tags?.map(t => (
            <span key={t} className="text-xs bg-stone-100 text-stone-500 border border-stone-200 px-1.5 py-px">#{t}</span>
          ))}
        </div>
      </div>

      {/* ── Scrollable body ── */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-5 space-y-5 max-w-screen-2xl mx-auto">

          {/* ── Stats row ── */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <StatCard
              label="progress"
              value={`${milestone.percent_complete || 0}%`}
              sub={deliverables.length > 0 ? `${doneCount}/${deliverables.length} deliverables` : undefined}
              accent
            />
            <StatCard
              label="deliverables complete"
              value={`${doneCount} / ${deliverables.length || '—'}`}
              sub={deliverables.length > 0 ? `${deliverables.length - doneCount} remaining` : 'none defined'}
            />
            <StatCard
              label={daysLeft !== null && daysLeft < 0 ? 'overdue by' : 'days until due'}
              value={daysLeft !== null ? `${Math.abs(daysLeft)}d` : '—'}
              sub={fmtDate(milestone.planned_end)}
            />
            <StatCard
              label="owner"
              value={milestone.owner_person || milestone.owner_org || '—'}
              sub={milestone.owner_org && milestone.owner_person ? milestone.owner_org : undefined}
            />
          </div>

          {/* ── Activity heatmap ── */}
          {activity.length > 0 && (
            <div className="bg-white border border-stone-200 p-4">
              <h2 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-3">
                Activity — last 90 days
                <span className="normal-case font-normal text-stone-300 ml-2">1 cell = 1 day</span>
              </h2>
              <ActivityHeatmap activity={activity} />
            </div>
          )}

          {/* ── Two-column body ── */}
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-5 items-start">

            {/* ── Left: info panels ── */}
            <div className="lg:col-span-2 space-y-4">

              {/* Progress bar */}
              <div className="bg-white border border-stone-200 p-4">
                <h2 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-3">Progress</h2>
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex-1 h-3 bg-stone-100 overflow-hidden">
                    <div className="h-full transition-all" style={{ width: `${milestone.percent_complete || 0}%`, backgroundColor: color }} />
                  </div>
                  <span className="text-sm font-bold font-mono tabular-nums" style={{ color }}>{milestone.percent_complete || 0}%</span>
                </div>

                {/* Deliverable breakdown */}
                {delByStatus.length > 0 && (
                  <div className="space-y-2">
                    {delByStatus.map(({ status, count }) => {
                      const s = DEL_STATUS[status] ?? { bar: 'bg-stone-300', badge: '' }
                      return (
                        <BreakdownBar
                          key={status}
                          label={status.replace('_', ' ')}
                          count={count}
                          max={delMax}
                          colorClass={s.bar}
                        />
                      )
                    })}
                  </div>
                )}
              </div>

              {/* Dates */}
              <div className="bg-white border border-stone-200 p-4 space-y-3">
                <h2 className="text-xs font-bold text-stone-400 uppercase tracking-widest">Dates</h2>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <div className="text-stone-400 mb-0.5">Start</div>
                    <div className="font-medium text-stone-700">{fmtDate(milestone.planned_start)}</div>
                  </div>
                  <div>
                    <div className="text-stone-400 mb-0.5">Due</div>
                    <div className={clsx('font-medium', daysLeft !== null && daysLeft < 0 ? 'text-red-600' : 'text-stone-700')}>
                      {fmtDate(milestone.planned_end)}
                    </div>
                  </div>
                  {milestone.last_modified && (
                    <div className="col-span-2">
                      <div className="text-stone-400 mb-0.5">Last modified</div>
                      <div className="text-stone-500">{timeAgo(milestone.last_modified)}</div>
                    </div>
                  )}
                </div>
              </div>

              {/* Description */}
              {milestone.description && (
                <div className="bg-white border border-stone-200 p-4">
                  <h2 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-2">Description</h2>
                  <p className="text-xs text-stone-600 leading-relaxed whitespace-pre-line">{milestone.description}</p>
                </div>
              )}

              {/* Technical progress */}
              {milestone.technical_progress && (
                <div className="bg-white border border-stone-200 p-4">
                  <h2 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-2">Technical Progress</h2>
                  <p className="text-xs text-stone-600 leading-relaxed whitespace-pre-line">{milestone.technical_progress}</p>
                </div>
              )}

              {/* Deliverables list */}
              {deliverables.length > 0 && (
                <div className="bg-white border border-stone-200 p-4">
                  <h2 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-3">
                    Deliverables
                    <span className="normal-case font-normal text-stone-300 ml-2">{doneCount}/{deliverables.length} complete</span>
                  </h2>
                  <div className="space-y-2">
                    {deliverables.map((d, i) => {
                      const s = DEL_STATUS[d.status] ?? DEL_STATUS.planned
                      return (
                        <div key={d.id ?? i} className="flex items-start gap-2 py-1.5 border-b border-stone-50 last:border-0">
                          <span className={clsx('text-xs px-1.5 py-px font-semibold border shrink-0 mt-px', s.badge)}>
                            {d.status.replace('_', ' ')}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-medium text-stone-700">{d.title}</div>
                            {d.description && <div className="text-xs text-stone-400 mt-0.5 line-clamp-2">{d.description}</div>}
                            {(d.due_date || d.owner) && (
                              <div className="text-xs text-stone-300 mt-0.5">
                                {d.due_date && fmtDate(d.due_date)}
                                {d.due_date && d.owner && ' · '}
                                {d.owner}
                              </div>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* ── Right: activity timeline ── */}
            <div className="lg:col-span-3 bg-white border border-stone-200 flex flex-col" style={{ minHeight: '520px' }}>

              <div className="px-4 pt-4 pb-3 border-b border-stone-100 space-y-2 shrink-0">
                <div className="flex items-center justify-between gap-2">
                  <h2 className="text-xs font-bold text-stone-400 uppercase tracking-widest">
                    Activity log
                    <span className="normal-case font-normal text-stone-300 ml-2">
                      {filteredActivity.length}{activity.length !== filteredActivity.length ? ` / ${activity.length}` : ''} entries
                    </span>
                  </h2>
                  {search && (
                    <button onClick={() => setSearch('')} className="text-xs text-stone-400 hover:text-stone-700 underline">Clear</button>
                  )}
                </div>
                <div className="relative">
                  <input
                    type="text"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    placeholder="Search activity…"
                    className="w-full text-xs bg-stone-50 border border-stone-200 px-3 py-1.5 text-stone-700 placeholder-stone-300 focus:outline-none focus:border-amber-400"
                  />
                  {search && (
                    <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-sm">×</button>
                  )}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto">
                {filteredActivity.length === 0 ? (
                  <div className="flex items-center justify-center py-16 text-xs text-stone-300">
                    {activity.length === 0 ? 'No activity logged for this milestone' : 'No entries match your search'}
                  </div>
                ) : (
                  <div className="divide-y divide-stone-50">
                    {filteredActivity.map((entry, i) => (
                      <div key={i} className="px-4 py-3 hover:bg-stone-50/70 transition-colors">
                        <div className="flex items-start gap-3">
                          <div className="shrink-0 pt-1">
                            <div className="w-2 h-2 bg-amber-400" />
                          </div>
                          <div className="flex-1 min-w-0 space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs text-stone-400 tabular-nums">{formatDateTime(entry.ts)}</span>
                              <span className="text-xs bg-stone-50 border border-stone-200 text-stone-500 px-1.5 py-px font-mono">
                                {entry.event}
                              </span>
                              {timeAgo(entry.ts) !== 'just now' && (
                                <span className="text-xs text-stone-300">{timeAgo(entry.ts)}</span>
                              )}
                            </div>
                            {(entry.summary || entry.detail) && (
                              <p className="text-xs text-stone-700 leading-snug">
                                {entry.summary || entry.detail}
                              </p>
                            )}
                            <p className="text-xs text-stone-400">{entry.actor}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
