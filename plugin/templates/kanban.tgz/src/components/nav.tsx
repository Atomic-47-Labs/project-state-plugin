'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { clsx } from 'clsx'
import { useEffect, useState } from 'react'

export function Nav({ projectName }: { projectName?: string }) {
  const path = usePathname()
  const [queuedCount, setQueuedCount] = useState<number | null>(null)
  const [inboxCount, setInboxCount] = useState<number | null>(null)

  useEffect(() => {
    fetch('/api/outbox').then(r => r.json())
      .then(d => setQueuedCount(Array.isArray(d?.queued) ? d.queued.length : null))
      .catch(() => setQueuedCount(null))
    fetch('/api/inbox').then(r => r.json())
      .then(d => setInboxCount(Array.isArray(d?.files) ? d.files.length : null))
      .catch(() => setInboxCount(null))
  }, [path])

  const badgeFor = (href: string): number | null =>
    href === '/reporting' ? queuedCount : href === '/inbox' ? inboxCount : null

  return (
    <nav
      className="h-10 flex items-center gap-3 px-4 border-b border-stone-300 shrink-0"
      style={{ background: '#e4ddd2' }}
    >
      <span className="text-xs font-bold text-stone-600 tracking-wide uppercase shrink-0">
        {projectName ? <span className="text-sky-700">{projectName}</span> : 'project-state'}
      </span>

      <span className="w-px h-5 bg-stone-300 shrink-0" />

      <div className="flex items-center gap-1">
        {[
          { href: '/dashboard',  label: 'Dashboard' },
          { href: '/inbox',      label: 'Inbox' },
          { href: '/kanban',     label: 'Kanban' },
          { href: '/milestones', label: 'Milestones' },
          { href: '/risks',      label: 'Risks' },
          { href: '/decisions',  label: 'Decisions' },
          { href: '/documents',  label: 'Documents' },
          { href: '/reporting',  label: 'Reporting' },
          { href: '/about',      label: 'About' },
        ].map(({ href, label }) => {
          const active = path === href
          const badge = badgeFor(href)
          const showBadge = !!badge
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                'text-xs px-3 py-1 font-medium transition-colors inline-flex items-center gap-1.5',
                active
                  ? 'bg-amber-700 text-white'
                  : 'text-stone-500 hover:text-stone-800 hover:bg-stone-200/60'
              )}
            >
              {label}
              {showBadge && (
                <span className={clsx(
                  'text-[10px] font-bold px-1.5 py-0.5 rounded-full leading-none',
                  active ? 'bg-white text-amber-700' : 'bg-amber-600 text-white'
                )}>
                  {badge}
                </span>
              )}
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
