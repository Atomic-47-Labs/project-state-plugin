'use client'

import React, { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import { clsx } from 'clsx'
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  useDroppable,
  useDraggable,
  closestCorners,
  DragStartEvent,
  DragEndEvent,
} from '@dnd-kit/core'
import { Nav } from '@/components/nav'
import { MarkdownContent } from '@/components/markdown-viewer'

// ─── Mode config ──────────────────────────────────────────────────────────────

type KanbanMode = 'milestones' | 'queue' | 'risks' | 'decisions' | 'schedule' | 'reports'

const MODES: { id: KanbanMode; label: string }[] = [
  { id: 'milestones', label: 'Milestones' },
  { id: 'queue',      label: 'Queue' },
  { id: 'risks',      label: 'Risks' },
  { id: 'decisions',  label: 'Decisions' },
  { id: 'schedule',   label: 'Schedule' },
  { id: 'reports',    label: 'Reports' },
]

// ─── Detail panel types ───────────────────────────────────────────────────────

type DetailItem =
  | { type: 'queue';    item: QueueItem }
  | { type: 'risk';     item: RiskItem }
  | { type: 'decision'; item: DecisionItem }
  | { type: 'schedule'; item: ScheduleEntry }
  | { type: 'report';   item: ReportItem }

// ─── Queue types ──────────────────────────────────────────────────────────────

interface QueueItem {
  id: string
  kind: string
  title: string
  produced_by?: string
  produced_at?: string
  status: 'queued' | 'approved' | 'dismissed' | 'sent'
  surface?: string
  action_required?: string
  deep_link?: string
}

// ─── Risk types ───────────────────────────────────────────────────────────────

interface RiskItem {
  id: string
  title: string
  status?: string
  score?: number
  likelihood?: number
  impact?: number
  description?: string
  mitigation?: string
  owner?: string
  date_identified?: string
  review_date?: string
  notes?: string
}

// ─── Decision types ───────────────────────────────────────────────────────────

interface DecisionItem {
  id?: string
  title: string
  decision?: string
  date?: string
  material?: boolean
  context?: string
  alternatives?: string
  made_by?: string
  rationale?: string
}

// ─── Schedule types ───────────────────────────────────────────────────────────

interface ScheduleEntry {
  id: string
  report: string
  cadence_label: string
  event_driven: boolean
  next_due: string | null
  last_run: string | null
  enabled: boolean
  runnable: boolean
  generator?: string
  stakeholder_group?: string
  profile?: string
  surface?: string
  format?: string
}

// ─── Report types ─────────────────────────────────────────────────────────────

interface ReportItem {
  name: string
  size: number
  mtime: string
  ext: string
  downloadPath: string
  category: 'bundle' | 'weekly' | 'adhoc'
  bundleName?: string
}

// ─── Milestone types ──────────────────────────────────────────────────────────

interface Deliverable { id: string; title: string; status: string }

interface ActivityMeta {
  count: number
  last_ts: string | null
  last_event: string | null
  chip_counts: Record<string, number>
}

interface HarvestMeta {
  count: number
  surface_counts: Record<string, number>
  last_ts: string | null
  cursors: Record<string, string>
}

interface Milestone {
  id: string
  title: string
  status: string
  percent_complete: number
  planned_start?: string
  planned_end?: string
  actual_start?: string
  actual_end?: string
  owner_person?: string
  owner_org?: string
  deliverables?: Deliverable[]
  description?: string
  technical_progress?: string
  _file?: string
  _activity?: ActivityMeta
  _harvest?: HarvestMeta
}

// ─── Milestone column config ──────────────────────────────────────────────────

const COLUMNS = [
  { id: 'planned',     label: 'Planned',     color: '#94a3b8', accent: '#f1f5f9' },
  { id: 'in_progress', label: 'In Progress', color: '#d97706', accent: '#fffbeb' },
  { id: 'at_risk',     label: 'At Risk',     color: '#ef4444', accent: '#fef2f2' },
  { id: 'complete',    label: 'Complete',    color: '#22c55e', accent: '#f0fdf4' },
]

// ─── Chip style maps ──────────────────────────────────────────────────────────

const ACTIVITY_CHIP_STYLE: Record<string, string> = {
  M:  'bg-amber-100 text-amber-800 border-amber-200',
  R:  'bg-sky-100 text-sky-700 border-sky-200',
  D:  'bg-purple-100 text-purple-700 border-purple-200',
  X:  'bg-red-100 text-red-600 border-red-200',
  P:  'bg-emerald-100 text-emerald-700 border-emerald-200',
  W:  'bg-cyan-100 text-cyan-700 border-cyan-200',
  B:  'bg-pink-100 text-pink-700 border-pink-200',
  H:  'bg-stone-100 text-stone-600 border-stone-200',
  PJ: 'bg-stone-100 text-stone-500 border-stone-200',
}

const SURFACE_CHIP_STYLE: Record<string, string> = {
  SL: 'bg-teal-100 text-teal-700 border-teal-300',
  GM: 'bg-red-100 text-red-600 border-red-200',
  GD: 'bg-blue-100 text-blue-600 border-blue-200',
  SC: 'bg-purple-100 text-purple-700 border-purple-200',
}

const KIND_BADGE: Record<string, string> = {
  report:       'bg-amber-100 text-amber-700 border-amber-200',
  weekly:       'bg-amber-100 text-amber-700 border-amber-200',
  draft:        'bg-blue-100 text-blue-700 border-blue-200',
  claim:        'bg-emerald-100 text-emerald-700 border-emerald-200',
  blog:         'bg-pink-100 text-pink-700 border-pink-200',
  notification: 'bg-teal-100 text-teal-700 border-teal-200',
  sc_pack:      'bg-purple-100 text-purple-700 border-purple-200',
}

// ─── Utilities ────────────────────────────────────────────────────────────────

function daysUntil(date?: string | null): number | null {
  if (!date) return null
  return Math.round((new Date(date).getTime() - Date.now()) / 86_400_000)
}

function timeAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 60_000)
  if (diff < 60)   return `${diff}m ago`
  if (diff < 1440) return `${Math.floor(diff / 60)}h ago`
  return `${Math.floor(diff / 1440)}d ago`
}

function statusColor(status: string) {
  return status === 'complete'    ? '#22c55e'
       : status === 'in_progress' ? '#d97706'
       : status === 'at_risk'     ? '#ef4444'
       : '#94a3b8'
}

function fmtDateShort(d: string) {
  return new Date(d).toLocaleDateString('en-CA', { month: 'short', day: 'numeric' })
}

function fmtDate(iso?: string | null) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString('en-CA', { year: 'numeric', month: 'short', day: 'numeric' })
}

function scoreColor(score?: number) {
  if (!score) return '#94a3b8'
  if (score >= 15) return '#dc2626'
  if (score >= 8)  return '#ea580c'
  if (score >= 4)  return '#d97706'
  return '#22c55e'
}

// ─── Shared UI atoms ──────────────────────────────────────────────────────────

function EventChip({ label, count }: { label: string; count: number }) {
  return (
    <span className={clsx(
      'inline-flex items-center gap-0.5 px-1 py-0.5 text-[10px] font-bold border',
      ACTIVITY_CHIP_STYLE[label] ?? 'bg-stone-100 text-stone-500 border-stone-200'
    )}>
      {label} {count}
    </span>
  )
}

function SurfaceChip({ label, count }: { label: string; count: number }) {
  return (
    <span className={clsx(
      'inline-flex items-center gap-0.5 px-1 py-0.5 text-[10px] font-black border',
      SURFACE_CHIP_STYLE[label] ?? 'bg-stone-100 text-stone-500 border-stone-200'
    )}>
      ■ {label} {count}
    </span>
  )
}

/** Consistent "Detail →" chip used on every card footer */
function DetailChip({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="text-[10px] font-semibold px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 transition-colors shrink-0"
    >
      Detail →
    </button>
  )
}

// ─── Generic card column ──────────────────────────────────────────────────────

function CardCol({
  label, color, accent, count, children,
}: {
  label: string; color: string; accent: string; count: number; children?: React.ReactNode
}) {
  return (
    <div className="flex flex-col min-w-[280px] w-[280px] shrink-0">
      <div className="px-3 py-2.5 mb-2 border-t-2" style={{ borderTopColor: color, background: accent }}>
        <div className="flex items-center justify-between">
          <span className="text-xs font-black uppercase tracking-widest" style={{ color }}>
            {label}
          </span>
          <span
            className="text-xs font-mono font-bold px-1.5 py-0.5 border"
            style={{ color, borderColor: color + '40', background: 'white' }}
          >
            {count}
          </span>
        </div>
      </div>
      <div className="flex-1 flex flex-col gap-2.5 min-h-[120px] p-2 bg-stone-100/40">
        {count === 0
          ? <div className="flex-1 flex items-center justify-center text-xs text-stone-300 italic min-h-[80px]">Empty</div>
          : children
        }
      </div>
    </div>
  )
}

// ─── Detail panel ─────────────────────────────────────────────────────────────

function DetailField({ label, value }: { label: string; value?: string | null }) {
  if (!value) return null
  return (
    <>
      <dt className="text-[10px] font-bold uppercase tracking-wide text-stone-400">{label}</dt>
      <dd className="text-xs text-stone-700 mb-3">{value}</dd>
    </>
  )
}

function QueueDetailContent({
  item, onAction,
}: {
  item: QueueItem
  onAction: () => void
}) {
  const [content, setContent] = useState<string | null>(null)
  const [loadingContent, setLoadingContent] = useState(true)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    setLoadingContent(true)
    fetch(`/api/outbox/${item.id}`)
      .then(r => r.json())
      .then(d => { setContent(d.content ?? null); setLoadingContent(false) })
      .catch(() => { setContent(null); setLoadingContent(false) })
  }, [item.id])

  async function act(action: string) {
    setBusy(true)
    await fetch(`/api/outbox/${item.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action }),
    })
    setBusy(false)
    onAction()
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Badges */}
      <div className="flex flex-wrap gap-2 items-center">
        <span className={clsx('text-[10px] font-bold uppercase px-1.5 py-0.5 border', KIND_BADGE[item.kind] ?? 'bg-stone-100 text-stone-500 border-stone-200')}>
          {item.kind}
        </span>
        <span className={clsx('text-[10px] font-bold px-1.5 py-0.5',
          item.status === 'queued'   ? 'bg-amber-100 text-amber-700' :
          item.status === 'approved' ? 'bg-emerald-100 text-emerald-700' :
          'bg-stone-100 text-stone-500'
        )}>
          {item.status}
        </span>
        {item.surface && <span className="text-[10px] text-stone-500 font-mono">{item.surface}</span>}
      </div>

      {/* Meta */}
      <dl>
        <DetailField label="Generator" value={item.produced_by} />
        <DetailField label="Produced"  value={fmtDate(item.produced_at)} />
        {item.action_required && (
          <>
            <dt className="text-[10px] font-bold uppercase tracking-wide text-stone-400">Action required</dt>
            <dd className="text-xs text-stone-700 mb-3 italic">{item.action_required}</dd>
          </>
        )}
        {item.deep_link && (
          <>
            <dt className="text-[10px] font-bold uppercase tracking-wide text-stone-400">Link</dt>
            <dd className="text-xs mb-3">
              <a href={item.deep_link} className="text-amber-700 hover:underline break-all">{item.deep_link}</a>
            </dd>
          </>
        )}
      </dl>

      {/* Actions */}
      {item.status === 'queued' && (
        <div className="flex gap-2">
          <button onClick={() => act('approve')} disabled={busy}
            className="text-xs px-3 py-1.5 font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50">
            Approve
          </button>
          <button onClick={() => act('dismiss')} disabled={busy}
            className="text-xs px-3 py-1.5 font-medium text-stone-600 border border-stone-300 hover:bg-stone-100 disabled:opacity-50">
            Dismiss
          </button>
        </div>
      )}

      {/* Artifact */}
      <div className="border-t border-stone-200 pt-4">
        <div className="text-[10px] font-bold uppercase tracking-wide text-stone-400 mb-3">Artifact</div>
        {loadingContent && <div className="text-xs text-stone-400 animate-pulse">Loading…</div>}
        {!loadingContent && content === null && (
          <div className="text-xs text-stone-400 italic">No artifact attached.</div>
        )}
        {!loadingContent && content && <MarkdownContent content={content} />}
      </div>
    </div>
  )
}

function RiskDetailContent({ item }: { item: RiskItem }) {
  return (
    <div className="flex flex-col gap-4">
      {/* Score + ID */}
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-mono font-bold text-stone-400">{item.id}</span>
        {item.score !== undefined && (
          <div className="text-right">
            <div className="text-4xl font-black tabular-nums" style={{ color: scoreColor(item.score) }}>
              {item.score}
            </div>
            <div className="text-[10px] text-stone-400">risk score</div>
          </div>
        )}
      </div>

      {/* Status + L/I */}
      <div className="flex flex-wrap gap-2">
        {item.status && (
          <span className={clsx('text-[10px] font-bold px-1.5 py-0.5',
            item.status === 'open'       ? 'bg-red-100 text-red-700' :
            item.status === 'monitoring' ? 'bg-amber-100 text-amber-700' :
            item.status === 'mitigated'  ? 'bg-emerald-100 text-emerald-700' :
            'bg-stone-100 text-stone-500'
          )}>
            {item.status}
          </span>
        )}
        {item.likelihood !== undefined && item.impact !== undefined && (
          <span className="text-[10px] text-stone-500 px-1.5 py-0.5 bg-stone-100">
            L{item.likelihood} × I{item.impact}
          </span>
        )}
      </div>

      <dl>
        <DetailField label="Owner"            value={item.owner} />
        <DetailField label="Date identified"  value={fmtDate(item.date_identified)} />
        <DetailField label="Next review"      value={fmtDate(item.review_date)} />
      </dl>

      {item.description && (
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wide text-stone-400 mb-1.5">Description</div>
          <p className="text-xs text-stone-700 leading-5">{item.description}</p>
        </div>
      )}

      {item.mitigation && (
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wide text-stone-400 mb-1.5">Mitigation</div>
          <p className="text-xs text-stone-700 leading-5">{item.mitigation}</p>
        </div>
      )}

      {item.notes && (
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wide text-stone-400 mb-1.5">Notes</div>
          <p className="text-xs text-stone-700 leading-5">{item.notes}</p>
        </div>
      )}
    </div>
  )
}

function DecisionDetailContent({ item }: { item: DecisionItem }) {
  return (
    <div className="flex flex-col gap-4">
      {/* Date + material */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-stone-500">{fmtDate(item.date)}</span>
        {item.material && (
          <span className="text-[10px] font-bold px-1.5 py-0.5 bg-purple-100 text-purple-700 border border-purple-200">
            material
          </span>
        )}
      </div>

      <dl>
        <DetailField label="Made by" value={item.made_by} />
      </dl>

      {item.decision && (
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wide text-stone-400 mb-1.5">Decision</div>
          <p className="text-sm text-stone-800 leading-6 font-medium">{item.decision}</p>
        </div>
      )}

      {item.context && (
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wide text-stone-400 mb-1.5">Context</div>
          <p className="text-xs text-stone-700 leading-5">{item.context}</p>
        </div>
      )}

      {item.rationale && (
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wide text-stone-400 mb-1.5">Rationale</div>
          <p className="text-xs text-stone-700 leading-5">{item.rationale}</p>
        </div>
      )}

      {item.alternatives && (
        <div>
          <div className="text-[10px] font-bold uppercase tracking-wide text-stone-400 mb-1.5">Alternatives considered</div>
          <p className="text-xs text-stone-700 leading-5">{item.alternatives}</p>
        </div>
      )}
    </div>
  )
}

function ScheduleDetailContent({ item, onGenerate }: { item: ScheduleEntry; onGenerate: () => void }) {
  const [busy, setBusy] = useState(false)

  async function generate() {
    setBusy(true)
    await fetch('/api/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ matrix_entry_id: item.id }),
    })
    setBusy(false)
    onGenerate()
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Status chips */}
      <div className="flex flex-wrap gap-2">
        <span className={clsx('text-[10px] font-bold px-1.5 py-0.5',
          item.enabled ? 'bg-emerald-100 text-emerald-700' : 'bg-stone-100 text-stone-500'
        )}>
          {item.enabled ? 'enabled' : 'disabled'}
        </span>
        {item.event_driven && (
          <span className="text-[10px] font-bold px-1.5 py-0.5 bg-stone-100 text-stone-500">event-driven</span>
        )}
      </div>

      <dl>
        <DetailField label="Cadence"           value={item.cadence_label} />
        <DetailField label="Generator"         value={item.generator} />
        <DetailField label="Stakeholder group" value={item.stakeholder_group} />
        <DetailField label="Profile"           value={item.profile} />
        <DetailField label="Surface"           value={item.surface} />
        <DetailField label="Format"            value={item.format} />
        <DetailField label="Last run"          value={fmtDate(item.last_run)} />
        <DetailField label="Next due"          value={item.event_driven ? 'Event-driven' : fmtDate(item.next_due)} />
      </dl>

      {item.runnable && (
        <div className="border-t border-stone-200 pt-4">
          <button
            onClick={generate}
            disabled={busy}
            className="text-xs px-3 py-1.5 font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50"
          >
            {busy ? 'Queuing…' : 'Generate now ▸'}
          </button>
          <p className="text-[10px] text-stone-400 mt-1.5">Runs immediately — draft lands in Queue for review.</p>
        </div>
      )}
    </div>
  )
}

function DetailPanel({
  detail, onClose, onQueueAction, onScheduleGenerate,
}: {
  detail: DetailItem
  onClose: () => void
  onQueueAction: () => void
  onScheduleGenerate: () => void
}) {
  const title =
    detail.type === 'queue'    ? detail.item.title :
    detail.type === 'risk'     ? detail.item.title :
    detail.type === 'decision' ? detail.item.title :
    detail.type === 'report'   ? detail.item.name.replace(/\.(md|docx|xlsx|pdf)$/, '') :
    detail.item.report

  const badge =
    detail.type === 'queue'    ? detail.item.kind.toUpperCase() :
    detail.type === 'risk'     ? detail.item.id :
    detail.type === 'decision' ? 'Decision' :
    detail.type === 'report'   ? detail.item.ext.replace('.', '').toUpperCase() :
    'Schedule'

  return (
    <>
      {/* Scrim */}
      <div
        className="fixed inset-0 bg-stone-900/30 z-40"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="fixed right-0 top-0 h-full w-[500px] bg-white shadow-2xl z-50 flex flex-col overflow-hidden">
        {/* Header */}
        <div
          className="flex items-start justify-between px-5 py-4 border-b border-stone-200 shrink-0 gap-3"
          style={{ background: '#ede8df' }}
        >
          <div className="flex items-start gap-2 min-w-0">
            <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 shrink-0 mt-0.5">
              {badge}
            </span>
            <span className="text-sm font-bold text-stone-800 leading-tight">{title}</span>
          </div>
          <button
            onClick={onClose}
            className="text-xs px-2 py-1 text-stone-500 hover:text-stone-800 hover:bg-stone-200 transition-colors font-medium shrink-0"
          >
            ✕ Close
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-5 py-5">
          {detail.type === 'queue' && (
            <QueueDetailContent
              item={detail.item}
              onAction={() => { onQueueAction(); onClose() }}
            />
          )}
          {detail.type === 'risk' && (
            <RiskDetailContent item={detail.item} />
          )}
          {detail.type === 'decision' && (
            <DecisionDetailContent item={detail.item} />
          )}
          {detail.type === 'schedule' && (
            <ScheduleDetailContent
              item={detail.item}
              onGenerate={() => { onScheduleGenerate(); onClose() }}
            />
          )}
          {detail.type === 'report' && (
            <ReportDetailContent item={detail.item} />
          )}
        </div>
      </div>
    </>
  )
}

// ─── Milestone card ───────────────────────────────────────────────────────────

function MilestoneCard({ milestone, dragging }: { milestone: Milestone; dragging?: boolean }) {
  const daysLeft    = daysUntil(milestone.planned_end)
  const deliverables = milestone.deliverables || []
  const done        = deliverables.filter(d => d.status === 'complete').length
  const activity    = milestone._activity
  const chips       = activity?.chip_counts ?? {}
  const harvest     = milestone._harvest
  const surfaces    = harvest?.surface_counts ?? {}

  return (
    <div className={clsx(
      'bg-white border border-stone-200 shadow-sm select-none',
      dragging && 'opacity-50 rotate-1 scale-105',
    )}>
      {/* ID + days left */}
      <div className="flex items-center justify-between px-3 pt-3 pb-1">
        <span className="text-[11px] font-mono font-bold text-stone-400">{milestone.id}</span>
        {daysLeft !== null && milestone.status !== 'complete' && (
          <span className={clsx(
            'text-[10px] font-bold px-1.5 py-0.5',
            daysLeft < 0  ? 'bg-red-50 text-red-600' :
            daysLeft < 14 ? 'bg-amber-50 text-amber-700' :
            'bg-stone-50 text-stone-400'
          )}>
            {daysLeft < 0 ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d`}
          </span>
        )}
      </div>

      {/* Title + % */}
      <div className="flex items-start justify-between px-3 pb-2 gap-2">
        <div className="text-sm font-semibold text-stone-800 leading-snug flex-1">
          {milestone.title}
        </div>
        <div className="text-right shrink-0">
          <div className="text-2xl font-black tabular-nums leading-none" style={{ color: statusColor(milestone.status) }}>
            {milestone.percent_complete || 0}%
          </div>
          <div className="text-[9px] text-stone-400 mt-0.5">complete</div>
        </div>
      </div>

      {/* Progress bar */}
      <div className="px-3 pb-2">
        <div className="h-1 bg-stone-100 overflow-hidden">
          <div className="h-full transition-all" style={{
            width: `${milestone.percent_complete || 0}%`,
            backgroundColor: statusColor(milestone.status),
          }} />
        </div>
      </div>

      {/* Deliverables */}
      {deliverables.length > 0 && (
        <div className="px-3 pb-2 flex items-center flex-wrap gap-1">
          {deliverables.map(d => (
            <span key={d.id} title={d.title} className={clsx(
              'text-[9px] font-bold px-1 py-0.5 border',
              d.status === 'complete'    ? 'bg-emerald-50 text-emerald-600 border-emerald-200' :
              d.status === 'in_progress' ? 'bg-amber-50 text-amber-600 border-amber-200' :
              'bg-stone-50 text-stone-400 border-stone-200'
            )}>
              {d.id}
            </span>
          ))}
          <span className="text-[9px] text-stone-400 ml-auto">{done}/{deliverables.length} done</span>
        </div>
      )}

      {/* Activity chips */}
      {Object.keys(chips).length > 0 && (
        <div className="px-3 pb-1 flex items-center flex-wrap gap-1">
          {Object.entries(chips).sort((a, b) => b[1] - a[1]).map(([k, v]) => (
            <EventChip key={k} label={k} count={v} />
          ))}
        </div>
      )}

      {/* Harvest chips */}
      {Object.keys(surfaces).length > 0 ? (
        <div className="px-3 pb-2 flex items-center flex-wrap gap-1">
          {Object.entries(surfaces).sort((a, b) => b[1] - a[1]).map(([k, v]) => (
            <SurfaceChip key={k} label={k} count={v} />
          ))}
        </div>
      ) : harvest && (
        <div className="px-3 pb-2">
          <span className="text-[9px] text-stone-300 italic">no harvest signals</span>
        </div>
      )}

      {/* Footer */}
      <div
        className="flex items-center justify-between px-3 py-2 mt-1 border-t border-stone-100"
        style={{ background: '#faf9f7' }}
      >
        <div className="text-[10px] text-stone-400 truncate max-w-[120px]">
          {activity?.last_ts
            ? <span>{timeAgo(activity.last_ts)}</span>
            : <span>{milestone.owner_person || milestone.owner_org || '—'}</span>
          }
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {milestone.planned_end && (
            <span className="text-[10px] text-stone-400">{fmtDateShort(milestone.planned_end)}</span>
          )}
          <Link
            href={`/milestone/${milestone.id}`}
            className="text-[10px] font-semibold px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 transition-colors"
            onClick={e => e.stopPropagation()}
          >
            Detail →
          </Link>
        </div>
      </div>
    </div>
  )
}

// ─── Draggable wrapper ────────────────────────────────────────────────────────

function DraggableMilestone({ milestone }: { milestone: Milestone }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: milestone.id,
    data: { milestone },
  })
  return (
    <div
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      style={transform ? { transform: `translate(${transform.x}px, ${transform.y}px)` } : undefined}
      className="cursor-grab active:cursor-grabbing"
    >
      <MilestoneCard milestone={milestone} dragging={isDragging} />
    </div>
  )
}

// ─── Milestone column (droppable) ─────────────────────────────────────────────

function Column({ col, milestones }: { col: typeof COLUMNS[0]; milestones: Milestone[] }) {
  const { isOver, setNodeRef } = useDroppable({ id: col.id })

  const totalPct = milestones.length > 0
    ? Math.round(milestones.reduce((s, m) => s + (m.percent_complete || 0), 0) / milestones.length)
    : 0

  return (
    <div className="flex flex-col min-w-[300px] w-[300px] shrink-0">
      <div className="px-3 py-2.5 mb-2 border-t-2" style={{ borderTopColor: col.color, background: col.accent }}>
        <div className="flex items-center justify-between">
          <span className="text-xs font-black uppercase tracking-widest" style={{ color: col.color }}>{col.label}</span>
          <span className="text-xs font-mono font-bold px-1.5 py-0.5 border"
            style={{ color: col.color, borderColor: col.color + '40', background: 'white' }}>
            {milestones.length}
          </span>
        </div>
        {milestones.length > 0 && (
          <div className="text-[10px] text-stone-400 mt-0.5">avg {totalPct}% · drag to update</div>
        )}
      </div>
      <div
        ref={setNodeRef}
        className={clsx(
          'flex-1 flex flex-col gap-2.5 min-h-[120px] p-2 transition-colors',
          isOver ? 'bg-amber-50 border border-dashed border-amber-300' : 'bg-stone-100/40',
        )}
      >
        {milestones.map(m => <DraggableMilestone key={m.id} milestone={m} />)}
        {milestones.length === 0 && (
          <div className="flex-1 flex items-center justify-center text-xs text-stone-300 italic min-h-[80px]">Drop here</div>
        )}
      </div>
    </div>
  )
}

// ─── Queue card ───────────────────────────────────────────────────────────────

function QueueCard({ item, onAction, onDetail }: { item: QueueItem; onAction: () => void; onDetail: () => void }) {
  const [busy, setBusy] = useState(false)

  async function act(action: string) {
    setBusy(true)
    await fetch(`/api/outbox/${item.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action }),
    })
    setBusy(false)
    onAction()
  }

  return (
    <div className="bg-white border border-stone-200 shadow-sm">
      <div className="px-3 pt-3 pb-1 flex items-center gap-2 flex-wrap">
        <span className={clsx('text-[10px] font-bold uppercase px-1.5 py-0.5 border shrink-0',
          KIND_BADGE[item.kind] ?? 'bg-stone-100 text-stone-500 border-stone-200')}>
          {item.kind}
        </span>
        {item.surface && <span className="text-[10px] text-stone-400 font-mono">{item.surface}</span>}
        {item.produced_at && <span className="text-[10px] text-stone-400 ml-auto shrink-0">{timeAgo(item.produced_at)}</span>}
      </div>

      <div className="px-3 pb-2">
        <div className="text-xs font-semibold text-stone-800 leading-snug">{item.title}</div>
        {item.action_required && (
          <div className="text-[10px] text-stone-500 mt-0.5 italic">{item.action_required}</div>
        )}
      </div>

      <div
        className="flex items-center justify-between px-3 py-2 border-t border-stone-100"
        style={{ background: '#faf9f7' }}
      >
        <div className="flex items-center gap-1.5">
          {item.status === 'queued' && (
            <>
              <button onClick={() => act('approve')} disabled={busy}
                className="text-[11px] px-2 py-0.5 font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50">
                Approve
              </button>
              <button onClick={() => act('dismiss')} disabled={busy}
                className="text-[11px] px-2 py-0.5 font-medium text-stone-600 border border-stone-300 hover:bg-stone-100 disabled:opacity-50">
                Dismiss
              </button>
            </>
          )}
        </div>
        <DetailChip onClick={onDetail} />
      </div>
    </div>
  )
}

// ─── Queue board ──────────────────────────────────────────────────────────────

const QUEUE_COLS = [
  { id: 'queued',    label: 'Queued',    color: '#d97706', accent: '#fffbeb' },
  { id: 'approved',  label: 'Approved',  color: '#22c55e', accent: '#f0fdf4' },
  { id: 'sent',      label: 'Done',      color: '#3b82f6', accent: '#eff6ff' },
  { id: 'dismissed', label: 'Dismissed', color: '#94a3b8', accent: '#f8fafc' },
]

function QueueBoard({ data, onRefresh, onDetail }: {
  data: Record<string, QueueItem[]>
  onRefresh: () => void
  onDetail: (item: QueueItem) => void
}) {
  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {QUEUE_COLS.map(col => {
        const items = data[col.id] ?? []
        return (
          <CardCol key={col.id} label={col.label} color={col.color} accent={col.accent} count={items.length}>
            {items.map(item => (
              <QueueCard key={item.id} item={item} onAction={onRefresh} onDetail={() => onDetail(item)} />
            ))}
          </CardCol>
        )
      })}
    </div>
  )
}

// ─── Risk card ────────────────────────────────────────────────────────────────

function RiskCard({ item, onDetail }: { item: RiskItem; onDetail: () => void }) {
  return (
    <div className="bg-white border border-stone-200 shadow-sm">
      <div className="px-3 pt-3 pb-1 flex items-center justify-between">
        <span className="text-[11px] font-mono font-bold text-stone-400">{item.id}</span>
        {item.score !== undefined && (
          <span className="text-xl font-black tabular-nums leading-none" style={{ color: scoreColor(item.score) }}>
            {item.score}
          </span>
        )}
      </div>
      <div className="px-3 pb-2">
        <div className="text-xs font-semibold text-stone-800 leading-snug">{item.title}</div>
        {item.likelihood !== undefined && item.impact !== undefined && (
          <div className="text-[10px] text-stone-500 mt-0.5">L{item.likelihood} × I{item.impact}</div>
        )}
        {item.description && (
          <div className="text-[10px] text-stone-400 mt-1 line-clamp-2">{item.description}</div>
        )}
      </div>
      <div className="flex items-center justify-between px-3 py-2 border-t border-stone-100" style={{ background: '#faf9f7' }}>
        <span className="text-[10px] text-stone-400">{item.mitigation ? 'mitigation noted' : ''}</span>
        <DetailChip onClick={onDetail} />
      </div>
    </div>
  )
}

// ─── Risks board ──────────────────────────────────────────────────────────────

const RISK_COLS = [
  { id: 'open',       label: 'Open',       color: '#ef4444', accent: '#fef2f2' },
  { id: 'monitoring', label: 'Monitoring', color: '#d97706', accent: '#fffbeb' },
  { id: 'mitigated',  label: 'Mitigated',  color: '#22c55e', accent: '#f0fdf4' },
  { id: 'closed',     label: 'Closed',     color: '#94a3b8', accent: '#f8fafc' },
]

function RisksBoard({ risks, onDetail }: { risks: RiskItem[]; onDetail: (item: RiskItem) => void }) {
  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {RISK_COLS.map(col => {
        const items = risks
          .filter(r => (r.status || 'open') === col.id)
          .sort((a, b) => (b.score ?? 0) - (a.score ?? 0))
        return (
          <CardCol key={col.id} label={col.label} color={col.color} accent={col.accent} count={items.length}>
            {items.map(item => <RiskCard key={item.id} item={item} onDetail={() => onDetail(item)} />)}
          </CardCol>
        )
      })}
    </div>
  )
}

// ─── Decision card ────────────────────────────────────────────────────────────

function DecisionCard({ item, onDetail }: { item: DecisionItem; onDetail: () => void }) {
  return (
    <div className="bg-white border border-stone-200 shadow-sm">
      <div className="px-3 pt-3 pb-1 flex items-center gap-2">
        <span className="text-[10px] text-stone-400">{fmtDate(item.date)}</span>
        {item.material && (
          <span className="text-[10px] font-bold px-1.5 py-0.5 bg-purple-100 text-purple-700 border border-purple-200 shrink-0">
            material
          </span>
        )}
      </div>
      <div className="px-3 pb-2">
        <div className="text-xs font-semibold text-stone-800 leading-snug">{item.title}</div>
        {item.decision && (
          <div className="text-[10px] text-stone-600 mt-1 line-clamp-3">{item.decision}</div>
        )}
      </div>
      <div className="flex items-center justify-end px-3 py-2 border-t border-stone-100" style={{ background: '#faf9f7' }}>
        <DetailChip onClick={onDetail} />
      </div>
    </div>
  )
}

// ─── Decisions board ──────────────────────────────────────────────────────────

function decisionBucket(date?: string): 'recent' | 'quarter' | 'older' {
  if (!date) return 'older'
  const daysOld = Math.floor((Date.now() - new Date(date).getTime()) / 86_400_000)
  if (daysOld <= 30) return 'recent'
  if (daysOld <= 90) return 'quarter'
  return 'older'
}

const DECISION_COLS = [
  { id: 'recent',  label: 'This Month',   color: '#7c3aed', accent: '#f5f3ff' },
  { id: 'quarter', label: 'Last 90 Days', color: '#6366f1', accent: '#eef2ff' },
  { id: 'older',   label: 'Older',        color: '#94a3b8', accent: '#f8fafc' },
]

function DecisionsBoard({ decisions, onDetail }: { decisions: DecisionItem[]; onDetail: (item: DecisionItem) => void }) {
  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {DECISION_COLS.map(col => {
        const items = decisions.filter(d => decisionBucket(d.date) === col.id)
        return (
          <CardCol key={col.id} label={col.label} color={col.color} accent={col.accent} count={items.length}>
            {items.map((item, i) => (
              <DecisionCard key={item.id ?? i} item={item} onDetail={() => onDetail(item)} />
            ))}
          </CardCol>
        )
      })}
    </div>
  )
}

// ─── Schedule card ────────────────────────────────────────────────────────────

function DuePill({ next_due, event_driven }: { next_due: string | null; event_driven: boolean }) {
  if (event_driven) return <span className="text-[10px] font-bold px-1.5 py-0.5 bg-stone-100 text-stone-500">event</span>
  const d = daysUntil(next_due)
  if (d === null) return <span className="text-[10px] text-stone-400">—</span>
  const tone = d <= 0 ? 'bg-red-100 text-red-700' : d <= 3 ? 'bg-amber-100 text-amber-700' : 'bg-emerald-50 text-emerald-700'
  return <span className={clsx('text-[10px] font-bold px-1.5 py-0.5', tone)}>{d <= 0 ? 'due today' : `in ${d}d`}</span>
}

function ScheduleCard({ item, onGenerate, onDetail }: {
  item: ScheduleEntry
  onGenerate?: () => void
  onDetail: () => void
}) {
  const [busy, setBusy] = useState(false)

  async function generate() {
    if (!item.runnable) return
    setBusy(true)
    await fetch('/api/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ matrix_entry_id: item.id }),
    })
    setBusy(false)
    onGenerate?.()
  }

  return (
    <div className={clsx('bg-white border border-stone-200 shadow-sm', !item.enabled && 'opacity-60')}>
      <div className="px-3 pt-3 pb-1 flex items-center gap-2">
        <DuePill next_due={item.next_due} event_driven={item.event_driven} />
        {!item.enabled && <span className="text-[10px] text-stone-400 italic">disabled</span>}
      </div>
      <div className="px-3 pb-2">
        <div className="text-xs font-semibold text-stone-800 leading-snug">{item.report}</div>
        <div className="text-[10px] text-stone-500 mt-0.5">{item.cadence_label}</div>
        {item.generator && (
          <div className="text-[10px] font-mono text-stone-400 mt-0.5 truncate">{item.generator}</div>
        )}
      </div>
      <div
        className="flex items-center justify-between px-3 py-2 border-t border-stone-100"
        style={{ background: '#faf9f7' }}
      >
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-stone-400">Last: {fmtDate(item.last_run)}</span>
          {item.runnable && (
            <button onClick={generate} disabled={busy}
              className="text-[11px] px-2 py-0.5 font-medium text-amber-700 border border-amber-300 hover:bg-amber-50 disabled:opacity-50">
              {busy ? '…' : 'Generate ▸'}
            </button>
          )}
        </div>
        <DetailChip onClick={onDetail} />
      </div>
    </div>
  )
}

// ─── Schedule board ───────────────────────────────────────────────────────────

function scheduleBucket(e: ScheduleEntry): 'overdue' | 'soon' | 'upcoming' | 'event' {
  if (e.event_driven) return 'event'
  const d = daysUntil(e.next_due)
  if (d === null) return 'upcoming'
  if (d <= 0)    return 'overdue'
  if (d <= 3)    return 'soon'
  return 'upcoming'
}

const SCHEDULE_COLS = [
  { id: 'overdue',  label: 'Overdue',      color: '#ef4444', accent: '#fef2f2' },
  { id: 'soon',     label: 'Due Soon',     color: '#d97706', accent: '#fffbeb' },
  { id: 'upcoming', label: 'Upcoming',     color: '#22c55e', accent: '#f0fdf4' },
  { id: 'event',    label: 'Event-driven', color: '#94a3b8', accent: '#f8fafc' },
]

function ScheduleBoard({ entries, onRefresh, onDetail }: {
  entries: ScheduleEntry[]
  onRefresh: () => void
  onDetail: (item: ScheduleEntry) => void
}) {
  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {SCHEDULE_COLS.map(col => {
        const items = entries.filter(e => scheduleBucket(e) === col.id)
        return (
          <CardCol key={col.id} label={col.label} color={col.color} accent={col.accent} count={items.length}>
            {items.map(item => (
              <ScheduleCard key={item.id} item={item} onGenerate={onRefresh} onDetail={() => onDetail(item)} />
            ))}
          </CardCol>
        )
      })}
    </div>
  )
}

// ─── Report card + board ──────────────────────────────────────────────────────

function fmtSize(bytes: number) {
  if (bytes < 1024)        return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

const EXT_COLOR: Record<string, string> = {
  '.docx': 'bg-blue-50 text-blue-700 border-blue-200',
  '.xlsx': 'bg-emerald-50 text-emerald-700 border-emerald-200',
  '.pdf':  'bg-red-50 text-red-700 border-red-200',
  '.md':   'bg-amber-50 text-amber-700 border-amber-200',
}

function ExtBadge({ ext }: { ext: string }) {
  return (
    <span className={clsx(
      'text-[10px] font-bold uppercase px-1.5 py-0.5 border shrink-0',
      EXT_COLOR[ext] ?? 'bg-stone-100 text-stone-500 border-stone-200'
    )}>
      {ext.replace('.', '')}
    </span>
  )
}

function ReportCard({ item, onDetail }: { item: ReportItem; onDetail: () => void }) {
  return (
    <div className="bg-white border border-stone-200 shadow-sm">
      <div className="px-3 pt-3 pb-1 flex items-center gap-2">
        <ExtBadge ext={item.ext} />
        {item.bundleName && (
          <span className="text-[10px] text-stone-400 truncate">{item.bundleName}</span>
        )}
        <span className="text-[10px] text-stone-400 ml-auto shrink-0">{fmtSize(item.size)}</span>
      </div>
      <div className="px-3 pb-2">
        <div className="text-xs font-semibold text-stone-800 leading-snug break-words">
          {item.name.replace(/\.(md|docx|xlsx|pdf)$/, '')}
        </div>
        <div className="text-[10px] text-stone-400 mt-0.5">{fmtDate(item.mtime)}</div>
      </div>
      <div
        className="flex items-center justify-between px-3 py-2 border-t border-stone-100"
        style={{ background: '#faf9f7' }}
      >
        <a
          href={`/api/reports/download/${item.downloadPath}`}
          download
          className="text-[10px] font-medium text-stone-500 hover:text-stone-700 transition-colors"
        >
          ↓ Download
        </a>
        <DetailChip onClick={onDetail} />
      </div>
    </div>
  )
}

const REPORT_COLS = [
  { id: 'bundle', label: 'Bundles', color: '#7c3aed', accent: '#f5f3ff' },
  { id: 'weekly', label: 'Weekly',  color: '#0891b2', accent: '#ecfeff' },
  { id: 'adhoc',  label: 'Ad-hoc', color: '#d97706', accent: '#fffbeb' },
]

function ReportsBoard({ items, onDetail }: { items: ReportItem[]; onDetail: (item: ReportItem) => void }) {
  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {REPORT_COLS.map(col => {
        const colItems = items
          .filter(r => r.category === col.id)
          .sort((a, b) => new Date(b.mtime).getTime() - new Date(a.mtime).getTime())
        return (
          <CardCol key={col.id} label={col.label} color={col.color} accent={col.accent} count={colItems.length}>
            {colItems.map((item, i) => (
              <ReportCard key={`${item.category}-${item.name}-${i}`} item={item} onDetail={() => onDetail(item)} />
            ))}
          </CardCol>
        )
      })}
    </div>
  )
}

function ReportDetailContent({ item }: { item: ReportItem }) {
  const [content, setContent] = useState<string | null>(null)
  const [loading, setLoading] = useState(item.ext === '.md')

  useEffect(() => {
    if (item.ext !== '.md') return
    setLoading(true)
    fetch(`/api/reports/download/${item.downloadPath}`)
      .then(r => r.text())
      .then(t => { setContent(t); setLoading(false) })
      .catch(() => { setContent(null); setLoading(false) })
  }, [item.downloadPath, item.ext])

  return (
    <div className="flex flex-col gap-4">
      {/* Meta */}
      <div className="flex flex-wrap gap-2 items-center">
        <ExtBadge ext={item.ext} />
        {item.bundleName && (
          <span className="text-[10px] text-stone-500 font-medium">{item.bundleName}</span>
        )}
        <span className={clsx('text-[10px] font-bold px-1.5 py-0.5',
          item.category === 'bundle' ? 'bg-purple-100 text-purple-700' :
          item.category === 'weekly' ? 'bg-cyan-100 text-cyan-700' :
          'bg-amber-100 text-amber-700'
        )}>
          {item.category}
        </span>
      </div>

      <dl>
        <DetailField label="Date"   value={fmtDate(item.mtime)} />
        <DetailField label="Size"   value={fmtSize(item.size)} />
        <DetailField label="Format" value={item.ext.replace('.', '').toUpperCase()} />
      </dl>

      <a
        href={`/api/reports/download/${item.downloadPath}`}
        download
        className="inline-flex items-center gap-1.5 text-xs px-3 py-1.5 font-medium text-white bg-amber-700 hover:bg-amber-800 transition-colors self-start"
      >
        ↓ Download {item.ext.replace('.', '').toUpperCase()}
      </a>

      {item.ext === '.md' && (
        <div className="border-t border-stone-200 pt-4">
          <div className="text-[10px] font-bold uppercase tracking-wide text-stone-400 mb-3">Content</div>
          {loading && <div className="text-xs text-stone-400 animate-pulse">Loading…</div>}
          {!loading && content === null && <div className="text-xs text-stone-400 italic">Could not load content.</div>}
          {!loading && content && <MarkdownContent content={content} />}
        </div>
      )}

      {item.ext !== '.md' && (
        <div className="text-xs text-stone-400 italic">
          Open in Microsoft Office or a compatible application to view this file.
        </div>
      )}
    </div>
  )
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

interface HarvestSummary {
  total_docs: number
  by_surface: Record<string, number>
  cursors: Record<string, string>
  has_harvested: boolean
}

function Sidebar({
  milestones, projectName, filterStatus, onFilterStatus, harvestSummary,
}: {
  milestones: Milestone[]
  projectName?: string
  filterStatus: string | null
  onFilterStatus: (s: string | null) => void
  harvestSummary?: HarvestSummary
}) {
  const counts = {
    planned:     milestones.filter(m => !m.status || m.status === 'planned').length,
    in_progress: milestones.filter(m => m.status === 'in_progress').length,
    at_risk:     milestones.filter(m => m.status === 'at_risk').length,
    complete:    milestones.filter(m => m.status === 'complete').length,
  }

  const owners = [...new Set(milestones.map(m => m.owner_org || m.owner_person).filter(Boolean))]

  const statusItems = [
    { id: 'planned',     label: 'Planned',     color: '#94a3b8', count: counts.planned },
    { id: 'in_progress', label: 'In Progress', color: '#d97706', count: counts.in_progress },
    { id: 'at_risk',     label: 'At Risk',     color: '#ef4444', count: counts.at_risk },
    { id: 'complete',    label: 'Complete',    color: '#22c55e', count: counts.complete },
  ]

  const overallPct = milestones.length > 0
    ? Math.round(milestones.reduce((s, m) => s + (m.percent_complete || 0), 0) / milestones.length)
    : 0

  return (
    <aside
      className="w-44 shrink-0 border-r border-stone-300 flex flex-col py-4 gap-5 text-xs sticky top-10 h-[calc(100vh-2.5rem)] overflow-y-auto"
      style={{ background: '#e8e2d9' }}
    >
      <div className="px-4">
        <div className="text-[10px] font-bold uppercase tracking-widest text-stone-500 mb-1">Project</div>
        <div className="font-bold text-stone-700 text-sm leading-tight">{projectName || 'project-state'}</div>
        <div className="text-stone-400 text-[10px] mt-1">{milestones.length} milestones</div>
      </div>

      <div className="px-4">
        <div className="text-[10px] font-bold uppercase tracking-widest text-stone-500 mb-1.5">Overall</div>
        <div className="text-2xl font-black text-amber-700">{overallPct}%</div>
        <div className="text-[10px] text-stone-400">avg complete</div>
        <div className="h-1 bg-stone-300 mt-2 overflow-hidden">
          <div className="h-full bg-amber-600" style={{ width: `${overallPct}%` }} />
        </div>
      </div>

      <div className="px-4">
        <div className="text-[10px] font-bold uppercase tracking-widest text-stone-500 mb-2">Status</div>
        <div className="flex flex-col gap-1">
          <button
            onClick={() => onFilterStatus(null)}
            className={clsx('flex items-center justify-between px-2 py-1 text-[11px] font-medium text-left transition-colors',
              filterStatus === null ? 'bg-amber-700 text-white' : 'text-stone-600 hover:bg-stone-300/60')}
          >
            <span>All</span><span className="font-mono">{milestones.length}</span>
          </button>
          {statusItems.map(s => (
            <button key={s.id}
              onClick={() => onFilterStatus(filterStatus === s.id ? null : s.id)}
              className={clsx('flex items-center justify-between px-2 py-1 text-[11px] font-medium text-left transition-colors',
                filterStatus === s.id ? 'bg-amber-700 text-white' : 'text-stone-600 hover:bg-stone-300/60')}
            >
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: s.color }} />
                {s.label}
              </span>
              <span className="font-mono">{s.count}</span>
            </button>
          ))}
        </div>
      </div>

      {owners.length > 0 && (
        <div className="px-4">
          <div className="text-[10px] font-bold uppercase tracking-widest text-stone-500 mb-2">Owner</div>
          {owners.map(o => <div key={o} className="text-[11px] text-stone-600 py-0.5">{o}</div>)}
        </div>
      )}

      <div className="px-4">
        <div className="text-[10px] font-bold uppercase tracking-widest text-stone-500 mb-2">Harvest</div>
        {harvestSummary?.has_harvested ? (
          <>
            <div className="text-[11px] text-stone-600 mb-1.5">{harvestSummary.total_docs} inbox docs</div>
            <div className="flex flex-col gap-1">
              {Object.entries(harvestSummary.by_surface).map(([chip, count]) => (
                <div key={chip} className="flex items-center justify-between">
                  <span className={clsx('text-[10px] font-black px-1 border',
                    SURFACE_CHIP_STYLE[chip] ?? 'bg-stone-100 text-stone-500 border-stone-200')}>■ {chip}</span>
                  <span className="text-[10px] font-mono text-stone-500">{count}</span>
                </div>
              ))}
            </div>
            {Object.keys(harvestSummary.cursors ?? {}).length > 0 && (
              <div className="mt-2 text-[9px] text-stone-400">
                Last: {Object.values(harvestSummary.cursors).filter(Boolean).sort().reverse()[0]
                  ? new Date(Object.values(harvestSummary.cursors).filter(Boolean).sort().reverse()[0])
                      .toLocaleDateString('en-CA', { month: 'short', day: 'numeric' })
                  : '—'}
              </div>
            )}
          </>
        ) : (
          <div className="text-[10px] text-stone-400 leading-relaxed">
            No harvests yet. <span className="font-mono text-stone-500">/project-harvester</span> to pull signals.
          </div>
        )}
      </div>

      <div className="px-4 mt-auto">
        <div className="text-[10px] font-bold uppercase tracking-widest text-stone-500 mb-2">Views</div>
        {[
          { href: '/dashboard', label: 'Dashboard' },
          { href: '/inventory', label: 'Inventory' },
          { href: '/reports',   label: 'Reports' },
        ].map(({ href, label }) => (
          <Link key={href} href={href} className="block text-[11px] text-stone-500 hover:text-amber-700 py-0.5 transition-colors">
            {label} →
          </Link>
        ))}
      </div>
    </aside>
  )
}

// ─── Mode header copy ─────────────────────────────────────────────────────────

const MODE_COPY: Record<KanbanMode, { title: string; body: string }> = {
  milestones: {
    title: 'Milestones — by status',
    body: 'Live board of all milestones in status columns. Drag a card to update its status · click Detail → to open the full milestone page · harvest chips show external signals.',
  },
  queue: {
    title: 'Queue — outbox drafts',
    body: 'All outbox cards grouped by state. Approve or Dismiss queued drafts directly from the cards · click Detail → to read the full artifact before acting.',
  },
  risks: {
    title: 'Risks — by status',
    body: 'Risk register grouped by status (open → monitoring → mitigated → closed). Scores shown prominently · click Detail → for full description, mitigation plan, and owner.',
  },
  decisions: {
    title: 'Decisions — by recency',
    body: 'Decision log in time bands. Material decisions are highlighted · click Detail → for full context, rationale, and alternatives considered.',
  },
  schedule: {
    title: 'Schedule — by due date',
    body: 'Reporting schedule by urgency. Hit Generate ▸ to queue a draft · click Detail → for full entry metadata and a generate shortcut.',
  },
  reports: {
    title: 'Reports — generated outputs',
    body: 'All generated reports grouped by type: baseline bundles, weekly reports, and ad-hoc pieces. Click Detail → to read markdown reports inline or download Word/Excel files.',
  },
}

// ─── Main app ─────────────────────────────────────────────────────────────────

export function KanbanApp() {
  const [mode,           setMode]           = useState<KanbanMode>('milestones')
  const [viewing,        setViewing]        = useState<DetailItem | null>(null)

  // Milestones
  const [milestones,     setMilestones]     = useState<Milestone[]>([])
  const [loading,        setLoading]        = useState(true)
  const [error,          setError]          = useState<string | null>(null)
  const [active,         setActive]         = useState<Milestone | null>(null)
  const [projectName,    setProjectName]    = useState<string>()
  const [filterStatus,   setFilterStatus]   = useState<string | null>(null)
  const [harvestSummary, setHarvestSummary] = useState<HarvestSummary>()

  // Mode data
  const [queueData,       setQueueData]       = useState<Record<string, QueueItem[]> | null>(null)
  const [risks,           setRisks]           = useState<RiskItem[] | null>(null)
  const [decisions,       setDecisions]       = useState<DecisionItem[] | null>(null)
  const [scheduleEntries, setScheduleEntries] = useState<ScheduleEntry[] | null>(null)
  const [reportItems,     setReportItems]     = useState<ReportItem[] | null>(null)
  const [modeLoading,     setModeLoading]     = useState(false)

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 8 } }))

  useEffect(() => {
    Promise.all([
      fetch('/api/milestones').then(r => r.json()),
      fetch('/api/dashboard').then(r => r.json()),
    ]).then(([mData, dData]) => {
      setMilestones(mData.milestones || [])
      setHarvestSummary(mData.harvest_summary)
      setProjectName(dData.project?.name)
      setLoading(false)
    }).catch(e => { setError(String(e)); setLoading(false) })
  }, [])

  const loadQueue = useCallback(() => {
    setModeLoading(true)
    fetch('/api/outbox').then(r => r.json()).then(d => {
      setQueueData({ queued: d.queued ?? [], approved: d.approved ?? [], sent: d.sent ?? [], dismissed: d.dismissed ?? [] })
      setModeLoading(false)
    }).catch(() => setModeLoading(false))
  }, [])

  const loadInventory = useCallback(() => {
    setModeLoading(true)
    fetch('/api/inventory').then(r => r.json()).then(d => {
      setRisks(d.risks ?? [])
      setDecisions(d.decisions ?? [])
      setModeLoading(false)
    }).catch(() => setModeLoading(false))
  }, [])

  const loadScheduleData = useCallback(() => {
    setModeLoading(true)
    fetch('/api/schedule').then(r => r.json()).then(d => {
      setScheduleEntries(d.entries ?? [])
      setModeLoading(false)
    }).catch(() => setModeLoading(false))
  }, [])

  const loadReports = useCallback(() => {
    setModeLoading(true)
    fetch('/api/reports').then(r => r.json()).then(d => {
      const flat: ReportItem[] = []
      for (const bundle of d.bundles ?? []) {
        for (const f of bundle.files ?? []) {
          flat.push({ ...f, category: 'bundle', bundleName: bundle.name })
        }
      }
      for (const f of d.weeklies ?? []) flat.push({ ...f, category: 'weekly' })
      for (const f of d.adhocs   ?? []) flat.push({ ...f, category: 'adhoc' })
      setReportItems(flat)
      setModeLoading(false)
    }).catch(() => setModeLoading(false))
  }, [])

  useEffect(() => {
    if (mode === 'queue')                              loadQueue()
    else if (mode === 'risks' || mode === 'decisions') loadInventory()
    else if (mode === 'schedule')                      loadScheduleData()
    else if (mode === 'reports')                       loadReports()
  }, [mode, loadQueue, loadInventory, loadScheduleData, loadReports])

  // DnD
  const normalize = (m: Milestone) => ({ ...m, status: m.status || 'planned' })

  function handleDragStart(e: DragStartEvent) {
    const m = milestones.find(m => m.id === e.active.id)
    if (m) setActive(m)
  }

  function handleDragEnd(e: DragEndEvent) {
    setActive(null)
    const { over, active } = e
    if (!over || !active) return
    const newStatus = String(over.id)
    const id        = String(active.id)
    const milestone = milestones.find(m => m.id === id)
    if (!milestone || milestone.status === newStatus) return
    setMilestones(prev => prev.map(m => m.id === id ? { ...m, status: newStatus } : m))
    fetch(`/api/milestones/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus }),
    }).catch(console.error)
  }

  const byStatus = (status: string) => {
    const all = milestones.map(normalize).filter(m => m.status === status)
    if (!filterStatus) return all
    return filterStatus === status ? all : []
  }

  const copy = MODE_COPY[mode]

  return (
    <div className="flex flex-col min-h-screen" style={{ background: '#f5f0e8' }}>
      <Nav projectName={projectName} />

      {/* Detail panel (all modes except milestones) */}
      {viewing && (
        <DetailPanel
          detail={viewing}
          onClose={() => setViewing(null)}
          onQueueAction={loadQueue}
          onScheduleGenerate={loadScheduleData}
        />
      )}

      <div className="flex flex-1 min-h-0">
        {/* Sidebar — milestones only */}
        {mode === 'milestones' && !loading && !error && (
          <Sidebar
            milestones={milestones}
            projectName={projectName}
            filterStatus={filterStatus}
            onFilterStatus={setFilterStatus}
            harvestSummary={harvestSummary}
          />
        )}

        <main className="flex-1 p-5 overflow-auto">

          {/* Mode tabs */}
          <div className="flex items-end gap-0 mb-4 border-b border-stone-300" style={{ background: '#ede8df' }}>
            {MODES.map(m => (
              <button key={m.id} onClick={() => setMode(m.id)}
                className={clsx(
                  'px-4 py-2 text-xs font-semibold transition-colors border-b-2 -mb-px',
                  mode === m.id
                    ? 'border-amber-600 text-amber-800 bg-white'
                    : 'border-transparent text-stone-500 hover:text-stone-700'
                )}
              >
                {m.label}
              </button>
            ))}
          </div>

          {/* Header */}
          <div className="mb-4 flex items-start justify-between">
            <div>
              <h1 className="text-lg font-bold text-stone-800">{copy.title}</h1>
              <p className="text-[11px] text-stone-500 mt-0.5 max-w-2xl">{copy.body}</p>
            </div>
            {mode === 'milestones' && filterStatus && (
              <button onClick={() => setFilterStatus(null)}
                className="text-xs px-2 py-1 bg-amber-100 text-amber-700 hover:bg-amber-200 transition-colors shrink-0 ml-4">
                ✕ Clear filter
              </button>
            )}
          </div>

          {/* ── Milestones ──────────────────────────────────────────────── */}
          {mode === 'milestones' && (
            <>
              {loading && <div className="flex items-center justify-center h-64"><span className="text-sm text-stone-400 animate-pulse">Loading milestones…</span></div>}
              {error && <div className="bg-red-50 border border-red-200 p-4 text-sm text-red-700">{error}</div>}
              {!loading && !error && (
                <DndContext sensors={sensors} collisionDetection={closestCorners} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
                  <div className="flex gap-4 overflow-x-auto pb-4">
                    {COLUMNS.map(col => <Column key={col.id} col={col} milestones={byStatus(col.id)} />)}
                  </div>
                  <DragOverlay>{active && <MilestoneCard milestone={active} />}</DragOverlay>
                </DndContext>
              )}
            </>
          )}

          {/* ── Queue ───────────────────────────────────────────────────── */}
          {mode === 'queue' && (
            modeLoading && !queueData
              ? <div className="flex items-center justify-center h-64"><span className="text-sm text-stone-400 animate-pulse">Loading queue…</span></div>
              : queueData && <QueueBoard data={queueData} onRefresh={loadQueue} onDetail={item => setViewing({ type: 'queue', item })} />
          )}

          {/* ── Risks ───────────────────────────────────────────────────── */}
          {mode === 'risks' && (
            modeLoading && !risks
              ? <div className="flex items-center justify-center h-64"><span className="text-sm text-stone-400 animate-pulse">Loading risks…</span></div>
              : risks && <RisksBoard risks={risks} onDetail={item => setViewing({ type: 'risk', item })} />
          )}

          {/* ── Decisions ───────────────────────────────────────────────── */}
          {mode === 'decisions' && (
            modeLoading && !decisions
              ? <div className="flex items-center justify-center h-64"><span className="text-sm text-stone-400 animate-pulse">Loading decisions…</span></div>
              : decisions && <DecisionsBoard decisions={decisions} onDetail={item => setViewing({ type: 'decision', item })} />
          )}

          {/* ── Schedule ────────────────────────────────────────────────── */}
          {mode === 'schedule' && (
            modeLoading && !scheduleEntries
              ? <div className="flex items-center justify-center h-64"><span className="text-sm text-stone-400 animate-pulse">Loading schedule…</span></div>
              : scheduleEntries && <ScheduleBoard entries={scheduleEntries} onRefresh={loadScheduleData} onDetail={item => setViewing({ type: 'schedule', item })} />
          )}

          {/* ── Reports ─────────────────────────────────────────────────── */}
          {mode === 'reports' && (
            modeLoading && !reportItems
              ? <div className="flex items-center justify-center h-64"><span className="text-sm text-stone-400 animate-pulse">Loading reports…</span></div>
              : reportItems && <ReportsBoard items={reportItems} onDetail={item => setViewing({ type: 'report', item })} />
          )}

        </main>
      </div>
    </div>
  )
}
