'use client'

import { useEffect, useState } from 'react'
import { clsx } from 'clsx'
import { Nav } from '@/components/nav'
import { MarkdownViewerOverlay } from '@/components/markdown-viewer'
import { fmtDate, statusColor, riskScoreColor } from '@/lib/utils'

// ─── Types ────────────────────────────────────────────────────────────────────

type Tab    = 'milestones' | 'risks' | 'decisions' | 'documents'
type View   = 'card' | 'list'
type SortBy = 'default' | 'name' | 'status' | 'score' | 'date'

interface Milestone {
  id: string; title: string; status: string; percent_complete: number
  planned_start?: string; planned_end?: string; actual_start?: string; actual_end?: string
  owner_person?: string; owner_org?: string; description?: string
  technical_progress?: string; deliverables?: any[]; dependencies?: string[]
  created?: string; last_modified?: string
}
interface Risk {
  id: string; title: string; score: number; likelihood: string; impact: string
  owner: string; status: string; mitigation?: string; contingency?: string
  last_reviewed?: string; description?: string; created?: string
}
interface Decision {
  id?: string; date: string; title: string; decision: string; rationale?: string
  context?: string; options_considered?: any[]; material_change: boolean
  approvers?: string[]; record?: string; made_by?: string
}
interface Document {
  id: string; slug?: string; title?: string; path?: string; source_path?: string
  kind?: string; status?: string; triage_state?: string; use_designation?: string
  relevance_score?: number; description?: string; extraction_summary?: string
  source?: string; harvested_at?: string; milestone_refs?: string[]
  post_title?: string; subject?: string; doc_title?: string; author?: string
  visibility?: string; tags?: string[]
}

interface InventoryData {
  milestones: Milestone[]
  risks:      Risk[]
  decisions:  Decision[]
  documents:  Document[]
}

// ─── Entity → Markdown generators ────────────────────────────────────────────

function milestoneToMarkdown(m: Milestone): string {
  const status = (m.status || 'planned').replace(/_/g, ' ')
  const del = m.deliverables || []
  const done = del.filter(d => d.status === 'complete').length

  return `# ${m.id} — ${m.title}

**Status:** ${status} · **Progress:** ${m.percent_complete || 0}% · **Owner:** ${m.owner_org || m.owner_person || '—'}

| | |
|---|---|
| Planned | ${m.planned_start ? fmtDate(m.planned_start) : '—'} → ${m.planned_end ? fmtDate(m.planned_end) : '—'} |
| Actual start | ${m.actual_start ? fmtDate(m.actual_start) : 'Not started'} |
| Actual end | ${m.actual_end ? fmtDate(m.actual_end) : '—'} |
| Created | ${m.created ? fmtDate(m.created) : '—'} |
| Last modified | ${m.last_modified ? fmtDate(m.last_modified) : '—'} |
${m.dependencies?.length ? `| Dependencies | ${m.dependencies.join(', ')} |` : ''}

## Description

${m.description?.trim() || '_No description provided._'}

${del.length > 0 ? `## Deliverables (${done}/${del.length} complete)

| ID | Title | Status |
|---|---|---|
${del.map(d => `| **${d.id}** | ${d.title} | ${(d.status || 'planned').replace(/_/g, ' ')} |`).join('\n')}

${del.filter(d => d.description).map(d => `### ${d.id} — ${d.title}\n\n${d.description.trim()}`).join('\n\n')}
` : ''}
${m.technical_progress ? `## Technical Progress

${m.technical_progress.trim()}
` : ''}`
}

function riskToMarkdown(r: Risk): string {
  const scoreLabel = (r.score || 0) >= 9 ? 'High' : (r.score || 0) >= 6 ? 'Medium' : 'Low'

  return `# ${r.id} — ${r.title}

**Score:** ${r.score || '—'} (${scoreLabel}) · **Status:** ${r.status || 'open'} · **Owner:** ${r.owner || '—'}

| | |
|---|---|
| Likelihood | ${r.likelihood || '—'} |
| Impact | ${r.impact || '—'} |
| Last reviewed | ${r.last_reviewed ? fmtDate(r.last_reviewed) : '—'} |
| Created | ${r.created ? fmtDate(r.created) : '—'} |

${r.description ? `## Description\n\n${r.description.trim()}\n` : ''}

## Mitigation

${r.mitigation?.trim() || '_No mitigation plan recorded._'}

${r.contingency ? `## Contingency\n\n${r.contingency.trim()}` : ''}`
}

function decisionToMarkdown(d: Decision): string {
  const opts = d.options_considered || []

  return `# ${d.title}

**Date:** ${d.date ? fmtDate(d.date) : '—'} · **Material change:** ${d.material_change ? 'Yes' : 'No'}${d.made_by ? ` · **Made by:** ${d.made_by}` : ''}${d.approvers?.length ? ` · **Approvers:** ${d.approvers.join(', ')}` : ''}

${d.context ? `## Context\n\n${d.context.trim()}\n` : ''}

${opts.length > 0 ? `## Options Considered

| Option | Outcome |
|---|---|
${opts.map((o: any) => `| ${o.label || o.title || 'Option'} | ${o.adopted ? '✓ Adopted' : o.rejected_because ? 'Rejected' : '—'} |`).join('\n')}

${opts.filter((o: any) => o.rejected_because).map((o: any) => `### ${o.label || o.title}\n\n**Rejected because:** ${o.rejected_because.trim()}`).join('\n\n')}
` : ''}

## Decision

${d.decision?.trim() || '_No decision text recorded._'}

${d.rationale ? `## Rationale\n\n${d.rationale.trim()}` : ''}
${d.record ? `## Record\n\n${d.record.trim()}` : ''}`
}

function documentToMarkdown(d: Document): string {
  const title = d.title || d.post_title || d.doc_title || d.subject || d.path || d.id

  return `# ${title}

**Source:** ${d.source || 'internal'} · **Status:** ${d.status || d.triage_state || '—'}${d.use_designation ? ` · **Designation:** ${d.use_designation}` : ''}${d.visibility ? ` · **Visibility:** ${d.visibility}` : ''}

| | |
|---|---|
| Kind | ${d.kind || '—'} |
| Path | ${d.source_path || d.path || '—'} |
${d.author ? `| Author | ${d.author} |` : ''}
${d.harvested_at ? `| Harvested | ${fmtDate(d.harvested_at)} |` : ''}
${d.relevance_score != null ? `| Relevance score | ${d.relevance_score}/100 |` : ''}
${d.milestone_refs?.length ? `| Milestone refs | ${d.milestone_refs.join(', ')} |` : ''}
${d.tags?.length ? `| Tags | ${d.tags.join(', ')} |` : ''}

${d.description ? `## Description\n\n${d.description.trim()}\n` : ''}
${d.extraction_summary ? `## Summary\n\n${d.extraction_summary.trim()}` : ''}`
}

// ─── Viewer button ────────────────────────────────────────────────────────────

function ViewBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="text-[10px] font-semibold px-2 py-0.5 border border-amber-300 text-amber-700 hover:bg-amber-50 transition-colors shrink-0"
    >
      View
    </button>
  )
}

// ─── Toolbar (search only — columns sort) ─────────────────────────────────────

function Toolbar({ search, onSearch, count }: { search: string; onSearch: (v: string) => void; count: number }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 border border-stone-200 flex-wrap" style={{ background: '#ede8df' }}>
      <input
        type="search"
        placeholder="Search…"
        value={search}
        onChange={e => onSearch(e.target.value)}
        className="px-2.5 py-1 text-xs border border-stone-300 bg-white focus:outline-none focus:border-amber-400 w-56"
      />
      <div className="flex-1" />
      <span className="text-xs text-stone-400">{count} item{count === 1 ? '' : 's'}</span>
    </div>
  )
}

// ─── Action buttons ───────────────────────────────────────────────────────────

function DownloadLink({ href }: { href: string }) {
  return (
    <a href={href}
      className="text-[10px] font-semibold px-2 py-0.5 border border-stone-300 text-stone-600 hover:bg-stone-100 transition-colors">
      Download
    </a>
  )
}

// ─── Shared sortable table ────────────────────────────────────────────────────

type Align = 'left' | 'center' | 'right'
interface Column<T> {
  id: string
  label: string
  width?: string
  align?: Align
  sortVal?: (row: T) => string | number
  render: (row: T) => React.ReactNode
}

function SortableTable<T>({ columns, rows, getKey, initialSort, empty }: {
  columns: Column<T>[]
  rows: T[]
  getKey: (row: T, i: number) => string
  initialSort?: { id: string; dir: 'asc' | 'desc' }
  empty: string
}) {
  const [sortId, setSortId] = useState(initialSort?.id ?? columns[0].id)
  const [dir, setDir] = useState<'asc' | 'desc'>(initialSort?.dir ?? 'asc')

  const col = columns.find(c => c.id === sortId) ?? columns[0]
  const sorted = [...rows]
  if (col.sortVal) {
    sorted.sort((a, b) => {
      const av = col.sortVal!(a), bv = col.sortVal!(b)
      const cmp = typeof av === 'number' && typeof bv === 'number' ? av - bv : String(av).localeCompare(String(bv))
      return dir === 'asc' ? cmp : -cmp
    })
  }

  function clickHeader(c: Column<T>) {
    if (!c.sortVal) return
    if (c.id === sortId) setDir(d => (d === 'asc' ? 'desc' : 'asc'))
    else { setSortId(c.id); setDir('asc') }
  }

  const alignCls = (a?: Align) => (a === 'right' ? 'text-right' : a === 'center' ? 'text-center' : 'text-left')

  return (
    <div className="bg-white border border-stone-200 shadow-sm overflow-x-auto">
      <table className="w-full text-xs border-collapse">
        <thead>
          <tr className="bg-stone-50 border-b border-stone-200">
            {columns.map(c => {
              const active = c.id === sortId
              return (
                <th key={c.id} onClick={() => clickHeader(c)}
                  className={clsx('px-3 py-2 text-[10px] font-bold uppercase tracking-wide text-stone-500 select-none',
                    alignCls(c.align), c.width, c.sortVal && 'cursor-pointer hover:text-stone-800')}>
                  <span className="inline-flex items-center gap-1">
                    {c.label}
                    {c.sortVal && <span className={clsx('text-[9px]', active ? 'text-amber-600' : 'text-stone-300')}>{active ? (dir === 'asc' ? '▲' : '▼') : '⇅'}</span>}
                  </span>
                </th>
              )
            })}
          </tr>
        </thead>
        <tbody>
          {sorted.map((row, i) => (
            <tr key={getKey(row, i)} className="border-b border-stone-50 hover:bg-stone-50/80">
              {columns.map(c => (
                <td key={c.id} className={clsx('px-3 py-2 align-middle', alignCls(c.align), c.width)}>{c.render(row)}</td>
              ))}
            </tr>
          ))}
          {sorted.length === 0 && (
            <tr><td colSpan={columns.length} className="text-center text-stone-300 italic py-10">{empty}</td></tr>
          )}
        </tbody>
      </table>
    </div>
  )
}

// ─── Document styling ─────────────────────────────────────────────────────────

const DESIGNATION_STYLE: Record<string, string> = {
  imprint:  'bg-orange-50 text-orange-700 border border-orange-200',
  'for-use':'bg-sky-50 text-sky-700 border border-sky-200',
  example:  'bg-emerald-50 text-emerald-700 border border-emerald-200',
  output:   'bg-stone-100 text-stone-500',
  unknown:  'bg-stone-50 text-stone-400',
}

function Pill({ children, className }: { children: React.ReactNode; className?: string }) {
  return <span className={clsx('text-[10px] px-1.5 py-0.5 font-semibold whitespace-nowrap', className)}>{children}</span>
}

// ─── Main ─────────────────────────────────────────────────────────────────────

const SECTION_COPY: Record<Tab, { title: string; lead: string; how: string }> = {
  milestones: {
    title: 'Milestones — the deliverables being tracked',
    lead: 'Every milestone in the project, with status, percent complete, and owner. This is the source of truth that reports and the claim draw from.',
    how: 'Search and sort below · click a card to read its full spec and technical-progress narrative · edit milestones from the Kanban board.',
  },
  risks: {
    title: 'Risks — what could derail the project',
    lead: 'The risk register: each risk with its likelihood × impact score, status, mitigation, and contingency.',
    how: 'Sort by score to see the most serious first · click a risk to read its full mitigation and contingency plan.',
  },
  decisions: {
    title: 'Decisions — the record of what was decided and why',
    lead: 'The decision log. Each entry captures the decision, its rationale, and whether it was material.',
    how: 'Search by topic · sort by date · click an entry to read the full decision and rationale.',
  },
  documents: {
    title: 'Documents — the project’s files',
    lead: 'Published reference docs plus any files you have ingested from the Inbox. This is where ingested files land.',
    how: 'Click a document to view it · add new files via the Inbox, then Ingest them to register them here.',
  },
}

const TEXT_EXT = /\.(md|mdx|txt|json|ya?ml|csv|log)$/i

function statusPill(status: string) {
  return <span className="text-[10px] px-1.5 py-0.5 font-semibold text-white whitespace-nowrap" style={{ backgroundColor: statusColor(status || 'planned') }}>{(status || 'planned').replace('_', ' ')}</span>
}
function ProgressBar({ pct }: { pct: number }) {
  const color = pct >= 100 ? '#22c55e' : '#0ea5e9'
  return (
    <div className="flex items-center gap-1.5">
      <div className="flex-1 h-1.5 bg-stone-100 min-w-[40px]"><div className="h-full" style={{ width: `${pct}%`, backgroundColor: color }} /></div>
      <span className="text-[10px] font-mono text-stone-400 w-8 text-right">{pct}%</span>
    </div>
  )
}

export function InventoryApp({ section }: { section?: Tab } = {}) {
  const [data,    setData]    = useState<InventoryData | null>(null)
  const [loading, setLoading] = useState(true)
  const [tab,     setTab]     = useState<Tab>(section ?? 'milestones')
  const [search,  setSearch]  = useState('')
  const [viewing, setViewing] = useState<{ title: string; badge: string; content: string | null } | null>(null)

  useEffect(() => {
    fetch('/api/inventory').then(r => r.json())
      .then(d => { setData(d); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const q = search.toLowerCase()
  const openView = (title: string, badge: string, content: string) => setViewing({ title, badge, content })
  async function openFile(title: string, relPath: string) {
    setViewing({ title, badge: 'DOC', content: null })
    try {
      const txt = await fetch(`/api/documents/file?path=${encodeURIComponent(relPath)}`).then(r => r.text())
      setViewing({ title, badge: 'DOC', content: txt })
    } catch { setViewing({ title, badge: 'DOC', content: 'Failed to load file.' }) }
  }

  const milestones = (data?.milestones || []).filter(m => !q || m.title.toLowerCase().includes(q) || m.id.toLowerCase().includes(q))
  const risks      = (data?.risks || []).filter(r => !q || r.title.toLowerCase().includes(q) || (r.id || '').toLowerCase().includes(q))
  const decisions  = (data?.decisions || []).filter(d => !q || d.title.toLowerCase().includes(q) || (d.decision || '').toLowerCase().includes(q))
  const documents  = (data?.documents || []).filter(d => !q || (d.path || '').toLowerCase().includes(q) || (d.kind || '').toLowerCase().includes(q) || (d.title || '').toLowerCase().includes(q))

  const tabs: Array<{ id: Tab; label: string; count: number }> = [
    { id: 'milestones', label: 'Milestones', count: data?.milestones.length ?? 0 },
    { id: 'risks',      label: 'Risks',      count: data?.risks.length ?? 0 },
    { id: 'decisions',  label: 'Decisions',  count: data?.decisions.length ?? 0 },
    { id: 'documents',  label: 'Documents',  count: data?.documents.length ?? 0 },
  ]

  const milestoneCols: Column<Milestone>[] = [
    { id: 'id', label: 'ID', width: 'w-16', sortVal: m => m.id, render: m => <span className="font-mono font-bold text-stone-400">{m.id}</span> },
    { id: 'title', label: 'Title', sortVal: m => m.title, render: m => <span className="font-medium text-stone-700">{m.title}</span> },
    { id: 'status', label: 'Status', sortVal: m => m.status || '', render: m => statusPill(m.status) },
    { id: 'pct', label: 'Progress', width: 'w-32', sortVal: m => m.percent_complete || 0, render: m => <ProgressBar pct={m.percent_complete || 0} /> },
    { id: 'owner', label: 'Owner', sortVal: m => m.owner_person || '', render: m => <span className="text-stone-500">{m.owner_person || '—'}</span> },
    { id: 'due', label: 'Due', align: 'right', sortVal: m => m.planned_end || '', render: m => <span className="text-stone-400">{fmtDate(m.planned_end)}</span> },
    { id: 'act', label: '', align: 'right', width: 'w-16', render: m => <ViewBtn onClick={() => openView(m.id, 'M', milestoneToMarkdown(m))} /> },
  ]
  const riskCols: Column<Risk>[] = [
    { id: 'id', label: 'ID', width: 'w-16', sortVal: r => r.id || '', render: r => <span className="font-mono font-bold text-stone-400">{r.id}</span> },
    { id: 'title', label: 'Title', sortVal: r => r.title, render: r => <span className="font-medium text-stone-700">{r.title}</span> },
    { id: 'score', label: 'Score', align: 'center', width: 'w-16', sortVal: r => r.score || 0, render: r => <span className="font-bold font-mono px-2 py-0.5" style={{ color: riskScoreColor(r.score || 0), background: riskScoreColor(r.score || 0) + '15' }}>{r.score || '—'}</span> },
    { id: 'likelihood', label: 'Likelihood', width: 'w-24', sortVal: r => r.likelihood || '', render: r => <span className="capitalize text-stone-500">{r.likelihood || '—'}</span> },
    { id: 'impact', label: 'Impact', width: 'w-20', sortVal: r => r.impact || '', render: r => <span className="capitalize text-stone-500">{r.impact || '—'}</span> },
    { id: 'status', label: 'Status', width: 'w-20', sortVal: r => r.status || '', render: r => <Pill className={r.status === 'closed' ? 'bg-stone-100 text-stone-400' : 'bg-amber-50 text-amber-700'}>{r.status || 'open'}</Pill> },
    { id: 'act', label: '', align: 'right', width: 'w-16', render: r => <ViewBtn onClick={() => openView(r.id, 'R', riskToMarkdown(r))} /> },
  ]
  const decisionCols: Column<Decision>[] = [
    { id: 'date', label: 'Date', width: 'w-24', sortVal: d => d.date || '', render: d => <span className="text-stone-400">{fmtDate(d.date)}</span> },
    { id: 'title', label: 'Title', sortVal: d => d.title, render: d => <span className="font-medium text-stone-700">{d.title}</span> },
    { id: 'decision', label: 'Decision', render: d => <span className="text-stone-500 line-clamp-1">{d.decision}</span> },
    { id: 'material', label: 'Material', align: 'center', width: 'w-20', sortVal: d => (d.material_change ? 1 : 0), render: d => d.material_change ? <Pill className="bg-amber-50 text-amber-700 border border-amber-200">material</Pill> : <span className="text-stone-300">—</span> },
    { id: 'act', label: '', align: 'right', width: 'w-16', render: d => <ViewBtn onClick={() => openView(d.title, 'D', decisionToMarkdown(d))} /> },
  ]
  const documentCols: Column<Document>[] = [
    { id: 'title', label: 'Title', sortVal: d => (d.title || d.path || d.id || ''), render: d => <span className="font-medium text-stone-700">{d.title || d.post_title || d.path || d.id}</span> },
    { id: 'type', label: 'Type', width: 'w-28', sortVal: d => (d.kind || d.source || ''), render: d => <Pill className={DESIGNATION_STYLE[d.use_designation || ''] || 'bg-stone-100 text-stone-500'}>{d.kind || d.source || 'doc'}</Pill> },
    { id: 'date', label: 'Date', align: 'right', width: 'w-28', sortVal: d => (d.harvested_at || ''), render: d => <span className="text-stone-400">{d.harvested_at ? fmtDate(d.harvested_at) : '—'}</span> },
    { id: 'act', label: '', align: 'right', width: 'w-32', render: d => {
      const p = d.path || d.source_path
      return (
        <div className="flex items-center gap-1.5 justify-end">
          {p && TEXT_EXT.test(p) && <ViewBtn onClick={() => openFile(d.title || d.path || d.id, p)} />}
          {p && <DownloadLink href={`/api/documents/file?path=${encodeURIComponent(p)}&download=1`} />}
        </div>
      )
    } },
  ]

  return (
    <div className="flex flex-col min-h-screen" style={{ background: '#f5f0e8' }}>
      <Nav />

      {viewing && (
        <MarkdownViewerOverlay
          title={viewing.title}
          badge={viewing.badge}
          content={viewing.content}
          loading={viewing.content === null}
          onClose={() => setViewing(null)}
        />
      )}

      <main className="flex-1 p-5 max-w-[1400px] mx-auto w-full space-y-3">
        {/* Section header (context + instruction) */}
        <div className="mb-1">
          <h1 className="text-xl font-bold text-stone-800">{SECTION_COPY[tab].title}</h1>
          <p className="text-sm text-stone-500 mt-1 max-w-2xl">{SECTION_COPY[tab].lead}</p>
          <p className="text-xs text-stone-400 mt-1.5 max-w-2xl">{SECTION_COPY[tab].how}</p>
        </div>

        {/* Tabs — only on the combined /inventory view */}
        {!section && (
          <div className="flex gap-0 border-b border-stone-200">
            {tabs.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={clsx('px-4 py-2 text-xs font-semibold border-b-2 transition-colors -mb-px',
                  tab === t.id ? 'border-amber-600 text-amber-800 bg-white' : 'border-transparent text-stone-500 hover:text-stone-800 hover:bg-stone-50')}>
                {t.label}
                <span className="ml-2 bg-stone-100 text-stone-500 px-1.5 py-0.5 text-xs">{t.count}</span>
              </button>
            ))}
          </div>
        )}

        <Toolbar search={search} onSearch={setSearch}
          count={tab === 'milestones' ? milestones.length : tab === 'risks' ? risks.length : tab === 'decisions' ? decisions.length : documents.length} />

        {loading && (
          <div className="flex items-center justify-center h-48">
            <span className="text-sm text-stone-400 animate-pulse">Loading…</span>
          </div>
        )}

        {!loading && data && (
          <>
            {tab === 'milestones' && <SortableTable columns={milestoneCols} rows={milestones} getKey={m => m.id} initialSort={{ id: 'id', dir: 'asc' }} empty="No milestones found." />}
            {tab === 'risks' && <SortableTable columns={riskCols} rows={risks} getKey={r => r.id} initialSort={{ id: 'score', dir: 'desc' }} empty="No risks found." />}
            {tab === 'decisions' && <SortableTable columns={decisionCols} rows={decisions} getKey={(d, i) => d.id || String(i)} initialSort={{ id: 'date', dir: 'desc' }} empty="No decisions found." />}
            {tab === 'documents' && <SortableTable columns={documentCols} rows={documents} getKey={(d, i) => d.path || d.id || String(i)} initialSort={{ id: 'title', dir: 'asc' }} empty="No documents indexed." />}
          </>
        )}
      </main>
    </div>
  )
}
