'use client'

import { useEffect, useState, useCallback } from 'react'
import { clsx } from 'clsx'
import { Nav } from '@/components/nav'
import { MarkdownViewerOverlay } from '@/components/markdown-viewer'

// ─── Types ──────────────────────────────────────────────────────────────────

type Status = 'queued' | 'approved' | 'dismissed' | 'sent'

interface Card {
  id: string
  kind: string
  title: string
  produced_by?: string
  produced_at?: string
  status: Status
  surface?: string
  action_required?: string
  deep_link?: string
  artifact?: string
  related_milestones?: string[]
  expires?: string
  dismiss_reason?: string
}

type Outbox = Record<Status, Card[]>

// ─── Helpers ──────────────────────────────────────────────────────────────────

const KIND_COLOR: Record<string, string> = {
  report:        'bg-amber-50 text-amber-700 border-amber-200',
  gmail_draft:   'bg-blue-50 text-blue-700 border-blue-200',
  calendar_hold: 'bg-violet-50 text-violet-700 border-violet-200',
  doc:           'bg-stone-100 text-stone-600 border-stone-200',
  blog_post:     'bg-emerald-50 text-emerald-700 border-emerald-200',
  slack_post:    'bg-rose-50 text-rose-700 border-rose-200',
}

function fmtDate(iso?: string) {
  if (!iso) return ''
  return new Date(iso).toLocaleDateString('en-CA', { year: 'numeric', month: 'short', day: 'numeric' })
}

function daysUntil(iso?: string): number | null {
  if (!iso) return null
  const ms = new Date(iso).getTime() - Date.now()
  return Math.ceil(ms / 86_400_000)
}

function KindBadge({ kind }: { kind: string }) {
  return (
    <span className={clsx(
      'text-[10px] font-bold uppercase px-1.5 py-0.5 border shrink-0',
      KIND_COLOR[kind] ?? 'bg-stone-100 text-stone-500 border-stone-200'
    )}>
      {kind.replace('_', ' ')}
    </span>
  )
}

function ExpiryBadge({ expires }: { expires?: string }) {
  const d = daysUntil(expires)
  if (d === null) return null
  const tone = d <= 3 ? 'bg-red-100 text-red-700' : d <= 7 ? 'bg-amber-100 text-amber-700' : 'bg-stone-100 text-stone-500'
  const label = d < 0 ? `overdue ${-d}d` : d === 0 ? 'due today' : `${d}d left`
  return <span className={clsx('text-[10px] font-bold px-1.5 py-0.5 shrink-0', tone)}>{label}</span>
}

// ─── Card ─────────────────────────────────────────────────────────────────────

function CardRow({
  card, onView, onAction, busy,
}: {
  card: Card
  onView: (c: Card) => void
  onAction: (id: string, action: string, reason?: string) => void
  busy: boolean
}) {
  const isQueued   = card.status === 'queued'
  const isApproved = card.status === 'approved'

  return (
    <div className="bg-white border border-stone-200 shadow-sm">
      <div className="px-4 py-3 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <KindBadge kind={card.kind} />
            <ExpiryBadge expires={card.expires} />
            <span className="text-sm font-bold text-stone-800">{card.title}</span>
          </div>
          <div className="text-[11px] text-stone-400 mt-1">
            {card.produced_by && <>by {card.produced_by} · </>}
            {fmtDate(card.produced_at)}
            {card.related_milestones?.length ? <> · {card.related_milestones.join(', ')}</> : null}
          </div>
          {card.action_required && (
            <div className="text-xs text-stone-600 mt-1.5 italic">↳ {card.action_required}</div>
          )}
          {card.dismiss_reason && (
            <div className="text-xs text-red-600 mt-1.5">dismissed: {card.dismiss_reason}</div>
          )}
        </div>
      </div>

      <div className="border-t border-stone-100 px-4 py-2 flex items-center gap-2 flex-wrap bg-stone-50/60">
        {card.artifact && (
          <button
            onClick={() => onView(card)}
            className="text-xs px-2 py-1 border border-amber-300 text-amber-700 hover:bg-amber-50 font-medium"
          >
            Review
          </button>
        )}

        {isQueued && (
          <>
            <button
              disabled={busy}
              onClick={() => onAction(card.id, 'approve')}
              className="text-xs px-2 py-1 font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50"
            >
              Approve
            </button>
            <button
              disabled={busy}
              onClick={() => {
                const reason = prompt('Dismiss reason (optional):') ?? undefined
                onAction(card.id, 'dismiss', reason)
              }}
              className="text-xs px-2 py-1 font-medium text-stone-600 border border-stone-300 hover:bg-stone-100 disabled:opacity-50"
            >
              Dismiss
            </button>
          </>
        )}

        {isApproved && (
          <>
            {card.deep_link && (
              <a
                href={card.deep_link}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs px-2 py-1 font-medium text-white bg-blue-700 hover:bg-blue-800"
              >
                Open in {card.surface ?? 'tool'} ↗
              </a>
            )}
            <button
              disabled={busy}
              onClick={() => onAction(card.id, 'mark-done')}
              className="text-xs px-2 py-1 font-medium text-white bg-stone-700 hover:bg-stone-800 disabled:opacity-50"
            >
              I’ve done it ✓
            </button>
            <button
              disabled={busy}
              onClick={() => onAction(card.id, 'requeue')}
              className="text-xs px-2 py-1 font-medium text-stone-500 border border-stone-300 hover:bg-stone-100 disabled:opacity-50"
            >
              Re-queue
            </button>
          </>
        )}
      </div>
    </div>
  )
}

// ─── Artifact viewer (with edit) ───────────────────────────────────────────────

function ArtifactViewer({
  card, onClose, onSaved,
}: {
  card: Card
  onClose: () => void
  onSaved: () => void
}) {
  const [content, setContent] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetch(`/api/outbox/${card.id}`)
      .then(r => r.json())
      .then(d => { setContent(d.content ?? 'Failed to load.'); setDraft(d.content ?? ''); setLoading(false) })
      .catch(() => { setContent('Failed to load.'); setLoading(false) })
  }, [card.id])

  async function save() {
    setSaving(true)
    await fetch(`/api/outbox/${card.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'edit', content: draft }),
    })
    setContent(draft)
    setSaving(false)
    setEditing(false)
    onSaved()
  }

  if (editing) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col" style={{ background: 'rgba(15,10,5,0.6)' }}>
        <div className="m-5 flex-1 bg-white flex flex-col overflow-hidden shadow-2xl max-h-[calc(100vh-2.5rem)]">
          <div className="flex items-center justify-between px-6 py-3.5 border-b border-stone-200 shrink-0" style={{ background: '#ede8df' }}>
            <span className="text-sm font-bold text-stone-800 truncate">Editing — {card.title}</span>
            <div className="flex items-center gap-2">
              <button onClick={save} disabled={saving} className="text-xs px-3 py-1 font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50">
                {saving ? 'Saving…' : 'Save'}
              </button>
              <button onClick={() => setEditing(false)} className="text-xs px-3 py-1 font-medium text-stone-600 border border-stone-300 hover:bg-stone-100">Cancel</button>
            </div>
          </div>
          <textarea
            value={draft}
            onChange={e => setDraft(e.target.value)}
            className="flex-1 p-6 font-mono text-xs text-stone-800 resize-none focus:outline-none"
            spellCheck={false}
          />
        </div>
      </div>
    )
  }

  return (
    <MarkdownViewerOverlay
      title={card.title}
      subtitle={card.action_required}
      badge={card.kind.replace('_', ' ').toUpperCase()}
      content={content}
      loading={loading}
      headerActions={
        card.artifact ? (
          <button
            onClick={() => setEditing(true)}
            className="text-xs px-2.5 py-1 border border-stone-400 text-stone-600 hover:bg-stone-200 font-medium"
          >
            ✎ Edit
          </button>
        ) : null
      }
      onClose={onClose}
    />
  )
}

// ─── Section ────────────────────────────────────────────────────────────────

function Section({ title, cards, ...rest }: {
  title: string
  cards: Card[]
  onView: (c: Card) => void
  onAction: (id: string, action: string, reason?: string) => void
  busyId: string | null
}) {
  if (cards.length === 0) return null
  return (
    <div className="mb-6">
      <div className="text-xs font-bold uppercase tracking-wide text-stone-500 mb-2">
        {title} <span className="text-stone-400">({cards.length})</span>
      </div>
      <div className="flex flex-col gap-2">
        {cards.map(c => (
          <CardRow key={c.id} card={c} onView={rest.onView} onAction={rest.onAction} busy={rest.busyId === c.id} />
        ))}
      </div>
    </div>
  )
}

// ─── Main ─────────────────────────────────────────────────────────────────────

export function QueueApp({ embedded }: { embedded?: boolean } = {}) {
  const [data, setData] = useState<Outbox | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [viewing, setViewing] = useState<Card | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [projectName, setProjectName] = useState<string>()

  const load = useCallback(() => {
    Promise.all([
      fetch('/api/outbox').then(r => r.json()),
      fetch('/api/dashboard').then(r => r.json()).catch(() => ({})),
    ]).then(([o, d]) => {
      setData(o)
      setProjectName(d?.project?.name)
    }).catch(e => setError(String(e)))
  }, [])

  useEffect(() => { load() }, [load])

  async function onAction(id: string, action: string, reason?: string) {
    setBusyId(id)
    await fetch(`/api/outbox/${id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, reason }),
    })
    setBusyId(null)
    load()
  }

  // Sort queued by expiry (soonest first), then produced_at.
  const queued = (data?.queued ?? []).slice().sort((a, b) => {
    const da = daysUntil(a.expires); const db = daysUntil(b.expires)
    if (da !== null && db !== null) return da - db
    if (da !== null) return -1
    if (db !== null) return 1
    return (a.produced_at ?? '').localeCompare(b.produced_at ?? '')
  })

  return (
    <div className={embedded ? '' : 'flex flex-col min-h-screen'} style={embedded ? undefined : { background: '#f5f0e8' }}>
      {!embedded && <Nav projectName={projectName} />}

      {viewing && (
        <ArtifactViewer
          card={viewing}
          onClose={() => setViewing(null)}
          onSaved={load}
        />
      )}

      <main className="flex-1 p-5 max-w-4xl mx-auto w-full">
        <div className="mb-5">
          <h1 className="text-xl font-bold text-stone-800">Queue — drafts waiting for you</h1>
          <p className="text-sm text-stone-500 mt-1 max-w-2xl">
            Every report, email, and post the project drafts lands here first. Nothing is ever sent,
            published, or committed automatically — this app has no way to do that.
          </p>
          <p className="text-xs text-stone-400 mt-1.5 max-w-2xl">
            <b>Review</b> a card to read or edit it · <b>Approve</b> when it&rsquo;s ready (this only
            reveals the link to the real draft) · open it in Gmail/Calendar and <b>send it yourself</b> ·
            then mark <b>I&rsquo;ve done it</b>. <b>Dismiss</b> anything you don&rsquo;t want.
          </p>
        </div>

        {error && <div className="bg-red-50 border border-red-200 p-4 text-sm text-red-700">{error}</div>}

        {!data && !error && (
          <div className="flex items-center justify-center h-48">
            <span className="text-sm text-stone-400 animate-pulse">Loading queue…</span>
          </div>
        )}

        {data && (
          <>
            {queued.length === 0 && data.approved.length === 0 && (
              <p className="text-sm text-stone-400 italic">Queue is empty. Scheduled generators will drop drafts here.</p>
            )}
            <Section title="Awaiting review" cards={queued} onView={setViewing} onAction={onAction} busyId={busyId} />
            <Section title="Approved — ready for you to action" cards={data.approved} onView={setViewing} onAction={onAction} busyId={busyId} />
            <Section title="Done" cards={data.sent} onView={setViewing} onAction={onAction} busyId={busyId} />
            <Section title="Dismissed" cards={data.dismissed} onView={setViewing} onAction={onAction} busyId={busyId} />
          </>
        )}
      </main>
    </div>
  )
}
