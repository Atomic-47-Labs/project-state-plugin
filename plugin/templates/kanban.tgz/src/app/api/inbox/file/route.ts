import { NextRequest, NextResponse } from 'next/server'
import fs from 'fs'
import { inboxFilePath, safeName } from '@/lib/inbox'

const TEXT_EXT = new Set(['.md', '.txt', '.json', '.yaml', '.yml', '.csv', '.log'])

export async function GET(req: NextRequest) {
  try {
    const name = req.nextUrl.searchParams.get('name')
    if (!name) return NextResponse.json({ error: 'name required' }, { status: 400 })
    const safe = safeName(name)
    const p = inboxFilePath(safe)
    if (!fs.existsSync(p)) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const download = req.nextUrl.searchParams.get('download') === '1'
    const ext = safe.slice(safe.lastIndexOf('.')).toLowerCase()
    const buf = fs.readFileSync(p)
    const headers: Record<string, string> = {}
    if (download) headers['Content-Disposition'] = `attachment; filename="${safe}"`
    if (TEXT_EXT.has(ext) && !download) headers['Content-Type'] = 'text/plain; charset=utf-8'
    return new NextResponse(buf, { headers })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 400 })
  }
}
