import { NextRequest, NextResponse } from 'next/server'
import { listInbox, saveUpload } from '@/lib/inbox'

export async function GET() {
  try {
    return NextResponse.json({ files: listInbox() })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

// Upload one or more files (drag-and-drop) into the inbox.
export async function POST(req: NextRequest) {
  try {
    const form = await req.formData()
    const files = form.getAll('files').filter((f): f is File => f instanceof File)
    if (files.length === 0) return NextResponse.json({ error: 'No files' }, { status: 400 })
    for (const file of files) {
      const buf = Buffer.from(await file.arrayBuffer())
      saveUpload(file.name, buf)
    }
    return NextResponse.json({ ok: true, count: files.length })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 400 })
  }
}
