import { NextRequest, NextResponse } from 'next/server'
import { ingestFiles, deleteFiles } from '@/lib/inbox'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as { action?: string; files?: string[] }
    const files = (body.files ?? []).filter(f => typeof f === 'string')
    if (files.length === 0) return NextResponse.json({ error: 'No files selected' }, { status: 400 })

    if (body.action === 'ingest') return NextResponse.json({ ok: true, count: ingestFiles(files) })
    if (body.action === 'delete') return NextResponse.json({ ok: true, count: deleteFiles(files) })
    return NextResponse.json({ error: `Unknown action: ${body.action}` }, { status: 400 })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 400 })
  }
}
