import { NextRequest, NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import { getStateDir } from '@/lib/state'

const MIME: Record<string, string> = {
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.pdf':  'application/pdf',
  '.md':   'text/markdown; charset=utf-8',
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  try {
    const { path: segments } = await params
    // Prevent path traversal
    const joined   = segments.join('/')
    const safe     = joined.replace(/\.\./g, '')
    const filePath = path.join(getStateDir(), 'reports', safe)

    if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }

    const ext      = path.extname(filePath).toLowerCase()
    const mime     = MIME[ext] ?? 'application/octet-stream'
    const filename = path.basename(filePath)
    const buffer   = fs.readFileSync(filePath)

    return new NextResponse(buffer, {
      headers: {
        'Content-Type':        mime,
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length':      String(buffer.length),
      },
    })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
