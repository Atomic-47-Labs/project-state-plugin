import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import { getStateDir } from '@/lib/state'

function fileMeta(filePath: string) {
  const stat = fs.statSync(filePath)
  const ext  = path.extname(filePath).toLowerCase()
  return {
    name: path.basename(filePath),
    size: stat.size,
    mtime: stat.mtime.toISOString(),
    ext,
  }
}

export async function GET() {
  try {
    const STATE       = getStateDir()
    const reportsDir  = path.join(STATE, 'reports')

    // ── Baseline bundles ─────────────────────────────────────────────────────
    const bundles: any[] = []
    const baselineDir = path.join(reportsDir, 'baseline')
    if (fs.existsSync(baselineDir)) {
      for (const bundleName of fs.readdirSync(baselineDir).sort().reverse()) {
        const bundlePath = path.join(baselineDir, bundleName)
        if (!fs.statSync(bundlePath).isDirectory()) continue
        const files = fs.readdirSync(bundlePath)
          .filter(f => !f.startsWith('.'))
          .sort()
          .map(f => ({
            ...fileMeta(path.join(bundlePath, f)),
            downloadPath: `baseline/${bundleName}/${f}`,
          }))
        bundles.push({ name: bundleName, date: bundleName.replace('Baseline-Reports-', ''), files })
      }
    }

    // ── Weekly reports ───────────────────────────────────────────────────────
    const weeklies: any[] = []
    const weeklyDir = path.join(reportsDir, 'weekly')
    if (fs.existsSync(weeklyDir)) {
      for (const f of fs.readdirSync(weeklyDir).filter(f => f.endsWith('.md')).sort().reverse()) {
        weeklies.push({
          ...fileMeta(path.join(weeklyDir, f)),
          downloadPath: `weekly/${f}`,
        })
      }
    }

    // ── Adhoc reports ────────────────────────────────────────────────────────
    const adhocs: any[] = []
    const adhocDir = path.join(reportsDir, 'adhoc')
    if (fs.existsSync(adhocDir)) {
      for (const f of fs.readdirSync(adhocDir).filter(f => f.endsWith('.md')).sort().reverse()) {
        adhocs.push({
          ...fileMeta(path.join(adhocDir, f)),
          downloadPath: `adhoc/${f}`,
        })
      }
    }

    return NextResponse.json({ bundles, weeklies, adhocs })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
