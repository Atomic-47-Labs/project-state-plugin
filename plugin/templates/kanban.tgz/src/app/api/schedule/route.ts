import { NextRequest, NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import yaml from 'js-yaml'
import { getStateDir } from '@/lib/state'
import { listOutbox } from '@/lib/outbox'
import { ALLOWED_GENERATOR_SKILLS } from '@/lib/jobs'

interface MatrixEntry {
  id: string
  report?: string
  stakeholder_group?: string
  cadence?: { kind?: string; day?: string; lead_time_hours?: number; trigger?: string; timing?: string }
  format?: string
  surface?: string
  generator?: string
  profile?: string
  enabled?: boolean
}

function matrixPath() { return path.join(getStateDir(), 'reporting-matrix.yaml') }

const DOW = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']

// Next occurrence of a weekday (today counts if it matches).
function nextWeekday(day: string): string | null {
  const target = DOW.indexOf(day.toLowerCase())
  if (target < 0) return null
  const now = new Date()
  const delta = (target - now.getDay() + 7) % 7
  const d = new Date(now)
  d.setDate(now.getDate() + delta)
  d.setHours(0, 0, 0, 0)
  return d.toISOString().slice(0, 10)
}

function cadenceLabel(c?: MatrixEntry['cadence']): string {
  if (!c?.kind) return 'unspecified'
  if (c.kind === 'weekly') return `weekly · ${c.day ?? '?'}`
  if (c.timing) return `${c.kind} · ${c.timing}`
  if (c.trigger) return `${c.kind} · ${c.trigger}`
  return c.kind
}

// Compute next-due date for time-based cadences; null for event-driven.
function nextDue(c?: MatrixEntry['cadence']): string | null {
  if (!c?.kind) return null
  if (c.kind === 'weekly' && c.day) return nextWeekday(c.day)
  return null // monthly/quarterly/sprint/event-driven not date-resolved here
}

export async function GET() {
  try {
    const STATE = getStateDir()
    if (!fs.existsSync(matrixPath())) {
      return NextResponse.json({ entries: [] })
    }
    const matrix = yaml.load(fs.readFileSync(matrixPath(), 'utf-8')) as { entries?: MatrixEntry[] }
    const entries = matrix.entries ?? []

    // Last-run signal per generator: most recent outbox card produced_at by that generator.
    const outbox = listOutbox()
    const allCards = [...outbox.queued, ...outbox.approved, ...outbox.dismissed, ...outbox.sent]
    const lastByGenerator: Record<string, string> = {}
    for (const card of allCards) {
      if (!card.produced_by || !card.produced_at) continue
      if (!lastByGenerator[card.produced_by] || card.produced_at > lastByGenerator[card.produced_by]) {
        lastByGenerator[card.produced_by] = card.produced_at
      }
    }

    // Also fold in orchestrator.tick events from the activity log (best-effort).
    let lastTick: string | null = null
    try {
      const lines = fs.readFileSync(path.join(STATE, 'logs', 'activity.ndjson'), 'utf-8').trim().split('\n')
      for (const line of lines) {
        try {
          const e = JSON.parse(line)
          if (e.event === 'orchestrator.tick' && e.ts) lastTick = e.ts
        } catch { /* skip */ }
      }
    } catch { /* no log */ }

    const out = entries.map(e => ({
      id: e.id,
      report: e.report ?? e.id,
      stakeholder_group: e.stakeholder_group,
      generator: e.generator,
      profile: e.profile,
      surface: e.surface,
      format: e.format,
      cadence_label: cadenceLabel(e.cadence),
      event_driven: !nextDue(e.cadence),
      next_due: nextDue(e.cadence),
      last_run: e.generator ? lastByGenerator[e.generator] ?? null : null,
      enabled: e.enabled !== false,
      runnable: !!e.generator && ALLOWED_GENERATOR_SKILLS.has(e.generator),
    }))

    return NextResponse.json({ entries: out, last_tick: lastTick })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

// Surgically set an entry's `enabled:` line, preserving the file's comments/formatting.
// (A yaml load+dump round-trip would strip the matrix's section comments.)
function setEnabledInText(text: string, id: string, enabled: boolean): string | null {
  const lines = text.split('\n')
  const idRe = new RegExp(`^(\\s*)-\\s+id:\\s*["']?${id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}["']?\\s*$`)
  const start = lines.findIndex(l => idRe.test(l))
  if (start < 0) return null

  const dashIndent = lines[start].match(/^(\s*)-/)![1].length
  const childIndent = ' '.repeat(dashIndent + 2)

  // Block runs until the next list item or shallower line.
  let end = lines.length
  for (let i = start + 1; i < lines.length; i++) {
    const l = lines[i]
    if (l.trim() === '') continue
    const indent = l.match(/^(\s*)/)![1].length
    if (indent <= dashIndent) { end = i; break }
  }

  const enabledIdx = lines.slice(start + 1, end).findIndex(l => /^\s*enabled:\s*/.test(l))
  if (enabledIdx >= 0) {
    const abs = start + 1 + enabledIdx
    lines[abs] = lines[abs].replace(/(^\s*enabled:\s*).*/, `$1${enabled}`)
  } else {
    lines.splice(start + 1, 0, `${childIndent}enabled: ${enabled}`)
  }
  return lines.join('\n')
}

// Toggle an entry's `enabled` flag in reporting-matrix.yaml (the tick skips disabled).
export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as { id?: string; enabled?: boolean }
    if (!body.id || typeof body.enabled !== 'boolean') {
      return NextResponse.json({ error: 'id and enabled (boolean) required' }, { status: 400 })
    }
    const text = fs.readFileSync(matrixPath(), 'utf-8')
    const updated = setEnabledInText(text, body.id, body.enabled)
    if (updated === null) return NextResponse.json({ error: 'Entry not found' }, { status: 404 })
    fs.writeFileSync(matrixPath(), updated)

    try {
      fs.appendFileSync(
        path.join(getStateDir(), 'logs', 'activity.ndjson'),
        JSON.stringify({ ts: new Date().toISOString(), actor: 'project-kanban', event: 'schedule.entry.toggled', id: body.id, detail: `enabled → ${body.enabled}` }) + '\n',
      )
    } catch { /* best-effort */ }

    return NextResponse.json({ ok: true, id: body.id, enabled: body.enabled })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
