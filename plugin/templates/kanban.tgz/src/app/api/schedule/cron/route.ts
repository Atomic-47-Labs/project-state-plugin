import { NextRequest, NextResponse } from 'next/server'
import { status, register, pause, resume, remove } from '@/lib/cron'

export async function GET() {
  try {
    return NextResponse.json(status())
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as { action: string; schedule?: string }
    switch (body.action) {
      case 'register': return NextResponse.json(register(body.schedule ?? '0 7 * * 1-5'))
      case 'pause':    return NextResponse.json(pause())
      case 'resume':   return NextResponse.json(resume())
      case 'remove':   return NextResponse.json(remove())
      default:         return NextResponse.json({ error: `Unknown action: ${body.action}` }, { status: 400 })
    }
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
