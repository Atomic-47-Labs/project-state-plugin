import { NextRequest, NextResponse } from 'next/server'
import { startJob, startMatrixJob, startAdhocJob, listJobs, GENERATORS } from '@/lib/jobs'

export async function GET() {
  return NextResponse.json({
    jobs: listJobs(),
    generators: Object.values(GENERATORS).map(g => ({ id: g.id, label: g.label, generator: g.generator })),
  })
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as { generator_id?: string; matrix_entry_id?: string; prompt?: string }

    if (typeof body.prompt === 'string' && body.prompt.trim()) {
      const job = startAdhocJob(body.prompt)
      return NextResponse.json({ ok: true, job })
    }
    if (body.matrix_entry_id) {
      const job = startMatrixJob(body.matrix_entry_id)
      return NextResponse.json({ ok: true, job })
    }
    if (body.generator_id) {
      if (!GENERATORS[body.generator_id]) {
        return NextResponse.json({ error: 'Unknown generator_id' }, { status: 400 })
      }
      const job = startJob(body.generator_id)
      return NextResponse.json({ ok: true, job })
    }
    return NextResponse.json({ error: 'prompt, generator_id, or matrix_entry_id required' }, { status: 400 })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 400 })
  }
}
