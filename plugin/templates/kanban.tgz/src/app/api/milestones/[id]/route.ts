import { NextRequest, NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import yaml from 'js-yaml'
import { getStateDir } from '@/lib/state'

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const STATE = getStateDir()
    const dir = path.join(STATE, 'milestones')

    const files = fs.readdirSync(dir).filter(f => f.endsWith('.yaml'))
    let milestone: any = null
    for (const f of files) {
      try {
        const m = yaml.load(fs.readFileSync(path.join(dir, f), 'utf-8')) as any
        if (m?.id === id) { milestone = m; break }
      } catch {}
    }
    if (!milestone) return NextResponse.json({ error: 'Milestone not found' }, { status: 404 })

    // Read relevant activity log entries
    const logPath = path.join(STATE, 'logs', 'activity.ndjson')
    const activity: any[] = []
    try {
      const lines = fs.readFileSync(logPath, 'utf-8').trim().split('\n').filter(Boolean)
      for (const line of lines) {
        try {
          const entry = JSON.parse(line)
          if (entry.id === id || entry.summary?.includes(id) || entry.detail?.includes(id)) {
            activity.push(entry)
          }
        } catch {}
      }
    } catch {}

    return NextResponse.json({ milestone, activity: activity.reverse() })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await req.json() as { status?: string; percent_complete?: number }
    const STATE = getStateDir()
    const dir   = path.join(STATE, 'milestones')

    const files = fs.readdirSync(dir).filter(f => f.endsWith('.yaml'))
    const file  = files.find(f => {
      try {
        const m = yaml.load(fs.readFileSync(path.join(dir, f), 'utf-8')) as any
        return m?.id === id
      } catch { return false }
    })
    if (!file) return NextResponse.json({ error: 'Milestone not found' }, { status: 404 })

    const filePath = path.join(dir, file)
    const milestone = yaml.load(fs.readFileSync(filePath, 'utf-8')) as any

    if (body.status !== undefined) milestone.status = body.status
    if (body.percent_complete !== undefined) milestone.percent_complete = body.percent_complete
    milestone.last_modified = new Date().toISOString()

    fs.writeFileSync(filePath, yaml.dump(milestone, { lineWidth: 120 }))

    // Append to activity log
    try {
      const logPath = path.join(STATE, 'logs', 'activity.ndjson')
      const entry = JSON.stringify({
        ts: new Date().toISOString(),
        actor: 'project-kanban',
        event: 'milestone.updated',
        id,
        detail: `status → ${body.status || milestone.status}`,
      })
      fs.appendFileSync(logPath, entry + '\n')
    } catch {}

    return NextResponse.json({ ok: true, milestone })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
