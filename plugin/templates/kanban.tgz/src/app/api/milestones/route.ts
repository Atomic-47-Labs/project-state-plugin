import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import yaml from 'js-yaml'
import { getStateDir } from '@/lib/state'

// ─── Activity event type → chip label ────────────────────────────────────────
const EVENT_CHIP: Record<string, string> = {
  'milestone':   'M',
  'report':      'R',
  'decision':    'D',
  'risk':        'X',
  'publication': 'P',
  'website':     'W',
  'blog':        'B',
  'health':      'H',
  'project':     'PJ',
}

function chipKey(event: string) {
  const prefix = event.split('.')[0]
  return EVENT_CHIP[prefix] ?? prefix[0].toUpperCase()
}

// ─── Harvest surface → chip label ────────────────────────────────────────────
const SURFACE_CHIP: Record<string, string> = {
  slack:   'SL',
  gmail:   'GM',
  gdocs:   'GD',
  scsiwyg: 'SC',
}

// ─── Parse YAML frontmatter from a markdown file ──────────────────────────────
function parseFrontmatter(content: string): Record<string, any> {
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---/)
  if (!match) return {}
  try { return (yaml.load(match[1]) as any) ?? {} } catch { return {} }
}

// ─── Load all inbox harvest docs, indexed by milestone ID ────────────────────
function loadHarvestDocs(STATE: string): Map<string, { surface: string; ts: string }[]> {
  const inboxDir = path.join(STATE, 'documents', 'inbox')
  const byMilestone = new Map<string, { surface: string; ts: string }[]>()

  if (!fs.existsSync(inboxDir)) return byMilestone

  for (const f of fs.readdirSync(inboxDir).filter(f => f.endsWith('.md'))) {
    try {
      const fullPath = path.join(inboxDir, f)
      const text     = fs.readFileSync(fullPath, 'utf-8')
      const fm       = parseFrontmatter(text)

      // Only process docs that came from the harvester (have a `source` surface)
      const surface = typeof fm.source === 'string' ? fm.source.toLowerCase() : null
      if (!surface || !SURFACE_CHIP[surface]) continue

      const ts = fm.harvested_at ?? fm.surface_timestamp ?? null

      // Associate with milestones: explicit refs first, then keyword search in body
      const explicitRefs: string[] = Array.isArray(fm.milestone_refs) ? fm.milestone_refs : []
      const bodyMatches: string[] = []

      if (explicitRefs.length === 0) {
        // Scan body for M##-slug references (e.g. M02-starter-pack-hardening)
        const body    = text.replace(/^---[\s\S]*?---/, '')
        const matches = body.match(/\bM\d{2,3}-[a-z0-9-]+/g) ?? []
        bodyMatches.push(...new Set(matches))
      }

      const refs = explicitRefs.length > 0 ? explicitRefs : bodyMatches

      // Also always add to a sentinel "__all__" key for global harvest summary
      const entry = { surface, ts }
      const allKey = '__all__'
      byMilestone.set(allKey, [...(byMilestone.get(allKey) ?? []), entry])

      for (const id of refs) {
        byMilestone.set(id, [...(byMilestone.get(id) ?? []), entry])
      }
    } catch {}
  }

  return byMilestone
}

export async function GET() {
  try {
    const STATE = getStateDir()
    const dir   = path.join(STATE, 'milestones')
    const milestones: any[] = []

    // ── Activity log ──────────────────────────────────────────────────────
    const logPath = path.join(STATE, 'logs', 'activity.ndjson')
    const allActivity: any[] = []
    if (fs.existsSync(logPath)) {
      for (const line of fs.readFileSync(logPath, 'utf-8').trim().split('\n').filter(Boolean)) {
        try { allActivity.push(JSON.parse(line)) } catch {}
      }
    }

    // ── Harvest inbox docs ────────────────────────────────────────────────
    const harvestByMilestone = loadHarvestDocs(STATE)

    // ── Harvest cursors from state.json ───────────────────────────────────
    let harvestCursors: Record<string, string> = {}
    const stateFile = path.join(STATE, 'state.json')
    if (fs.existsSync(stateFile)) {
      try {
        const s = JSON.parse(fs.readFileSync(stateFile, 'utf-8'))
        harvestCursors = s.harvest_cursors ?? {}
      } catch {}
    }

    if (fs.existsSync(dir)) {
      for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.yaml')).sort()) {
        try {
          const m = yaml.load(fs.readFileSync(path.join(dir, f), 'utf-8')) as any
          if (!m?.id) continue

          // ── Activity summary ──────────────────────────────────────────
          const related = allActivity.filter(e =>
            e.id === m.id ||
            e.summary?.includes(m.id) ||
            e.detail?.includes(m.id)
          )
          const lastEntry  = related.length > 0 ? related[related.length - 1] : null
          const chipCounts = related.reduce<Record<string, number>>((acc, e) => {
            const k = chipKey(e.event || '')
            acc[k] = (acc[k] || 0) + 1
            return acc
          }, {})

          // ── Harvest surface summary ───────────────────────────────────
          const harvestDocs = harvestByMilestone.get(m.id) ?? []
          const surfaceCounts = harvestDocs.reduce<Record<string, number>>((acc, d) => {
            const chip = SURFACE_CHIP[d.surface]
            if (chip) acc[chip] = (acc[chip] || 0) + 1
            return acc
          }, {})
          const lastHarvest = harvestDocs.length > 0
            ? harvestDocs.filter(d => d.ts).sort((a, b) => (b.ts ?? '').localeCompare(a.ts ?? ''))[0]?.ts ?? null
            : null

          milestones.push({
            ...m,
            _file: f,
            _activity: {
              count:       related.length,
              last_ts:     lastEntry?.ts ?? null,
              last_event:  lastEntry?.event ?? null,
              chip_counts: chipCounts,
            },
            _harvest: {
              count:          harvestDocs.length,
              surface_counts: surfaceCounts,
              last_ts:        lastHarvest,
              cursors:        harvestCursors,
            },
          })
        } catch {}
      }
    }

    // ── Global harvest summary (across all milestones) ────────────────────
    const allHarvestDocs = harvestByMilestone.get('__all__') ?? []
    const globalSurfaces = allHarvestDocs.reduce<Record<string, number>>((acc, d) => {
      const chip = SURFACE_CHIP[d.surface]
      if (chip) acc[chip] = (acc[chip] || 0) + 1
      return acc
    }, {})

    return NextResponse.json({
      milestones,
      harvest_summary: {
        total_docs:     allHarvestDocs.length,
        by_surface:     globalSurfaces,
        cursors:        harvestCursors,
        has_harvested:  allHarvestDocs.length > 0,
      },
    })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
