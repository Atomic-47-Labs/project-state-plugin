import { NextResponse } from 'next/server'
import { listOutbox } from '@/lib/outbox'

export async function GET() {
  try {
    return NextResponse.json(listOutbox())
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
