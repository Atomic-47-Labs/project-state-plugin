import { NextRequest, NextResponse } from 'next/server'
import { transition, editArtifact, readArtifact, OutboxStatus } from '@/lib/outbox'

const ACTION_TO_STATUS: Record<string, OutboxStatus> = {
  approve: 'approved',
  dismiss: 'dismissed',
  'mark-done': 'sent',
  requeue: 'queued',
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const content = readArtifact(id)
    if (content === null) return NextResponse.json({ error: 'Artifact not found' }, { status: 404 })
    return NextResponse.json({ id, content })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await req.json() as { action: string; reason?: string; content?: string }

    if (body.action === 'edit') {
      if (typeof body.content !== 'string') {
        return NextResponse.json({ error: 'edit requires content' }, { status: 400 })
      }
      editArtifact(id, body.content)
      return NextResponse.json({ ok: true })
    }

    const to = ACTION_TO_STATUS[body.action]
    if (!to) return NextResponse.json({ error: `Unknown action: ${body.action}` }, { status: 400 })

    const card = transition(id, to, { reason: body.reason })
    return NextResponse.json({ ok: true, card })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
