import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import yaml from 'js-yaml'
import { getStateDir } from '@/lib/state'

export async function GET() {
  try {
    const STATE = getStateDir()

    const manifest = yaml.load(fs.readFileSync(path.join(STATE, 'manifest.yaml'), 'utf-8')) as any
    const state    = JSON.parse(fs.readFileSync(path.join(STATE, 'state.json'), 'utf-8'))

    // Milestones
    const milestonesDir = path.join(STATE, 'milestones')
    const milestones: any[] = []
    if (fs.existsSync(milestonesDir)) {
      for (const f of fs.readdirSync(milestonesDir).filter(f => f.endsWith('.yaml'))) {
        try {
          const m = yaml.load(fs.readFileSync(path.join(milestonesDir, f), 'utf-8')) as any
          if (m?.id) milestones.push(m)
        } catch {}
      }
    }

    // Risks
    const risksDir = path.join(STATE, 'risks')
    const risks: any[] = []
    if (fs.existsSync(risksDir)) {
      for (const f of fs.readdirSync(risksDir).filter(f => f.endsWith('.yaml'))) {
        try {
          const r = yaml.load(fs.readFileSync(path.join(risksDir, f), 'utf-8')) as any
          if (r?.id) risks.push(r)
        } catch {}
      }
    }

    // Activity log — last 30 entries
    const logPath = path.join(STATE, 'logs', 'activity.ndjson')
    const activity: any[] = []
    if (fs.existsSync(logPath)) {
      const lines = fs.readFileSync(logPath, 'utf-8').trim().split('\n').filter(Boolean)
      for (const line of lines.slice(-30).reverse()) {
        try { activity.push(JSON.parse(line)) } catch {}
      }
    }

    // Decisions
    const decisionsDir = path.join(STATE, 'decisions')
    const decisions: any[] = []
    if (fs.existsSync(decisionsDir)) {
      for (const f of fs.readdirSync(decisionsDir).filter(f => f.endsWith('.yaml')).sort().reverse()) {
        try {
          const d = yaml.load(fs.readFileSync(path.join(decisionsDir, f), 'utf-8')) as any
          if (d?.title) decisions.push(d)
        } catch {}
      }
    }

    // Stats
    const total     = milestones.length
    const complete  = milestones.filter(m => m.status === 'complete').length
    const inProg    = milestones.filter(m => m.status === 'in_progress').length
    const atRisk    = milestones.filter(m => m.status === 'at_risk').length
    const planned   = milestones.filter(m => m.status === 'planned' || !m.status).length
    const overallPct = total > 0
      ? Math.round(milestones.reduce((s, m) => s + (m.percent_complete || 0), 0) / total)
      : 0

    const highRisks = risks.filter(r => (r.score || 0) >= 9 && r.status !== 'closed').length
    const medRisks  = risks.filter(r => (r.score || 0) >= 6 && (r.score || 0) < 9 && r.status !== 'closed').length
    const openRisks = risks.filter(r => r.status !== 'closed').length

    return NextResponse.json({
      project: {
        name:        manifest?.project?.short_name || manifest?.project?.name || 'Project',
        long_name:   manifest?.project?.long_name || '',
        one_liner:   manifest?.project?.one_liner || '',
        phase:       state?.current_phase || manifest?.phases?.current_phase || '—',
        start_date:  manifest?.project?.start_date || null,
        end_date:    manifest?.project?.end_date || null,
        packs_loaded: manifest?.project?.packs_loaded || [],
      },
      milestones: { total, complete, in_progress: inProg, at_risk: atRisk, planned, overall_pct: overallPct },
      risks:     { total: risks.length, open: openRisks, high: highRisks, med: medRisks },
      decisions: { total: decisions.length, material: decisions.filter(d => d.material_change).length },
      activity,
      top_risks:  risks.filter(r => r.status !== 'closed').sort((a, b) => (b.score || 0) - (a.score || 0)).slice(0, 5),
      recent_decisions: decisions.slice(0, 5),
    })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
