import { NextRequest, NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import { getStateDir } from '@/lib/state'

const TEXT_EXT = new Set(['.md', '.txt', '.json', '.yaml', '.yml', '.csv', '.log', '.mdx'])

// Serve a file from within project-state/documents/ — view (text) or download.
export async function GET(req: NextRequest) {
  try {
    const rel = req.nextUrl.searchParams.get('path')
    if (!rel) return NextResponse.json({ error: 'path required' }, { status: 400 })

    const STATE = getStateDir()
    const docsRoot = path.resolve(STATE, 'documents')
    const target = path.resolve(STATE, rel)
    // Confine to documents/ — reject traversal.
    if (target !== docsRoot && !target.startsWith(docsRoot + path.sep)) {
      return NextResponse.json({ error: 'Forbidden path' }, { status: 403 })
    }
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }

    const ext = path.extname(target).toLowerCase()
    const download = req.nextUrl.searchParams.get('download') === '1'
    const buf = fs.readFileSync(target)
    const headers: Record<string, string> = {}
    if (download) headers['Content-Disposition'] = `attachment; filename="${path.basename(target)}"`
    else if (TEXT_EXT.has(ext)) headers['Content-Type'] = 'text/plain; charset=utf-8'
    return new NextResponse(buf, { headers })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 400 })
  }
}
