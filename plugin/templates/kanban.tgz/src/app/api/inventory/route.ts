import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import yaml from 'js-yaml'
import { getStateDir } from '@/lib/state'

function readYamls(dir: string): any[] {
  if (!fs.existsSync(dir)) return []
  const results: any[] = []
  for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.yaml')).sort()) {
    try {
      const obj = yaml.load(fs.readFileSync(path.join(dir, f), 'utf-8')) as any
      if (obj) results.push(obj)
    } catch {}
  }
  return results
}

export async function GET() {
  try {
    const STATE = getStateDir()

    const milestones = readYamls(path.join(STATE, 'milestones'))
    const risks      = readYamls(path.join(STATE, 'risks'))
    const decisions  = readYamls(path.join(STATE, 'decisions')).reverse()

    // Documents from index.yaml
    // Documents = published reference docs (index.yaml `docs`) + ingested files.
    const documents: any[] = []
    try {
      const idx = yaml.load(fs.readFileSync(path.join(STATE, 'documents', 'index.yaml'), 'utf-8')) as any
      for (const d of (idx?.docs || idx?.entries || [])) {
        documents.push({ id: d.slug, title: d.title, path: d.source_path || d.path, kind: 'reference' })
      }
    } catch {}
    try {
      const ing = yaml.load(fs.readFileSync(path.join(STATE, 'documents', 'ingested.yaml'), 'utf-8')) as any
      for (const d of (ing?.documents || [])) {
        documents.push({ title: d.title, path: d.path, kind: d.kind || 'ingested', harvested_at: d.ingested_at })
      }
    } catch {}

    return NextResponse.json({ milestones, risks, decisions, documents })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}
