import { InventoryApp } from '@/components/inventory-app'
export default function InventoryPage() { return <InventoryApp /> }
