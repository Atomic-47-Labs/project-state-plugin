import { Nav } from '@/components/nav'

const SKILLS = [
  { cmd: '/project-state',           role: 'Foundation', desc: 'Shared memory layer — reads, writes, validates every entity in project-state/.' },
  { cmd: '/project-scaffolder',      role: 'Foundation', desc: 'One-shot interactive wizard that initializes project-state/ and seeds the reporting matrix from a compliance pack.' },
  { cmd: '/project-onboarding',      role: 'Foundation', desc: 'Nine-chapter guided initialization with dual-surface display. Inbox Orientation pre-fills chapters when documents are present.' },
  { cmd: '/project-inbox',           role: 'Foundation', desc: 'Smart document inbox — classifies dropped files, extracts meaning, builds orientation context for onboarding.' },
  { cmd: '/project-phase-gate',      role: 'Core',       desc: 'Manage lifecycle phase transitions. Profile-driven gates enforce what must be true before advancing.' },
  { cmd: '/project-document-curator',role: 'Core',       desc: 'Classify, index, and promote documents into the chain-of-custody record.' },
  { cmd: '/project-milestone-manager',role: 'Core',      desc: 'CRUD milestones, update percent_complete, record technical progress narratives.' },
  { cmd: '/project-status-reporter', role: 'Core',       desc: 'Generate status reports — weekly, SC pack, claim draft, dashboard snapshot.' },
  { cmd: '/project-orchestrator',    role: 'Automation', desc: 'Calendar-aware conductor: reads reporting matrix, dispatches generators, surfaces what needs to happen.' },
  { cmd: '/project-notifier',        role: 'Automation', desc: 'Route artifacts to Slack (auto-post), Gmail (always draft), or Google Calendar (proposed holds).' },
  { cmd: '/project-review-meeting',  role: 'Automation', desc: 'Generic recurring review-meeting lifecycle — agenda, minutes, action items, next hold.' },
  { cmd: '/project-funder-reporting',role: 'Automation', desc: 'Stakeholder-bound recurring reports: claims, invoices, board packs. Profile-driven.' },
  { cmd: '/project-change-register', role: 'Automation', desc: 'Classify and route project changes: material vs. non-material, change orders, stakeholder notification.' },
  { cmd: '/project-blog-publisher',  role: 'Surface',    desc: 'Bridge project state to the scsiwyg blog with publication-review respect.' },
  { cmd: '/project-website-publisher',role: 'Surface',   desc: 'Build and serve the static project website (Next.js). Stable URLs for reference documents.' },
  { cmd: '/project-doc-suite',       role: 'Surface',    desc: 'Unified document suite: baseline reports, milestone snapshots, risk register — .docx + .xlsx.' },
  { cmd: '/project-onboarder',       role: 'Polish',     desc: 'Personalized onboarding briefs for new teammates based on project state and their role.' },
  { cmd: '/project-ip-tracker',      role: 'Polish',     desc: 'Track IP disclosures with configurable recipient via pack profile.' },
  { cmd: '/project-external-comms',  role: 'Polish',     desc: 'External communication review pipeline before anything goes to funders or press.' },
  { cmd: '/project-lessons',         role: 'Polish',     desc: 'Continuous lessons-learned capture and closeout summary.' },
  { cmd: '/project-archive',         role: 'Polish',     desc: 'Project closeout and archival. Profile-driven gate enforcement.' },
  { cmd: '/project-git',             role: 'Polish',     desc: 'Git-aware checkpointing — commit, push, branch from within a project-state session.' },
  { cmd: '/project-harvester',       role: 'Intel',      desc: 'Harvest Slack, Gmail, GDocs, and scsiwyg signals into documents/inbox/ with per-surface cursors.' },
  { cmd: '/grant-state',             role: 'Grant',      desc: 'Memory layer for grant facilities — reads/writes .grant-state/ alongside project-state/.' },
  { cmd: '/grant-scaffolder',        role: 'Grant',      desc: 'Five-step interactive wizard for any Canadian grant program. 19 playbooks, 12 compliance gates.' },
  { cmd: '/grant-ingestor',          role: 'Grant',      desc: 'Ingest RFP documents, extract eligibility rules and deadlines, seed grant-state.' },
]

const PACKS = [
  { name: 'agile-default',         maturity: 'starter',    desc: 'Engineering teams, Scrum/Kanban, no external funder' },
  { name: 'board-investor',        maturity: 'starter',    desc: 'Startups with board reporting obligations' },
  { name: 'client-services',       maturity: 'starter',    desc: 'Client-facing engagements, QBR cadence' },
  { name: 'open-source-community', maturity: 'starter',    desc: 'Community-governed open-source projects' },
  { name: 'sred-canada',           maturity: 'starter',    desc: 'Canadian projects claiming SR&ED tax credits' },
  { name: 'grant-canada',          maturity: 'starter',    desc: 'Canadian grant submissions — NSERC, IRAP, SIF, PIC, CFI, Mitacs + 13 more' },
  { name: 'pic-pcais',             maturity: 'production', desc: 'Protein Industries Canada PCAIS consortium (execution phase)' },
]

const ROLE_COLOR: Record<string, string> = {
  Foundation: '#b45309', Core: '#6366f1', Automation: '#f59e0b',
  Surface: '#22c55e', Polish: '#94a3b8', Grant: '#e11d48', Intel: '#8b5cf6',
}

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen" style={{ background: '#f5f0e8' }}>
      <Nav />

      <main className="flex-1 max-w-[1100px] mx-auto w-full px-5 py-8 space-y-14">

        {/* Hero */}
        <div className="space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-semibold px-3 py-1 border"
            style={{ color: '#92400e', background: '#fffbeb', borderColor: '#fde68a' }}>
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: '#d97706' }} />
            v3.3 · local-first
          </div>
          <h1 className="text-4xl font-bold text-stone-900 leading-tight">
            Routine reporting as a<br />
            <span style={{ color: '#b45309' }}>byproduct of normal work.</span>
          </h1>
          <p className="text-lg text-stone-500 max-w-2xl leading-relaxed">
            <strong>project-state</strong> is an operational substrate for multi-stakeholder projects.
            31 skills and 7 compliance packs turn any project — grant-funded, client-facing, board-reported,
            or open-source — into a system where status reports, meeting packs, and funder claims
            write themselves from the state you already maintain.
          </p>
          <p className="text-sm text-stone-400 max-w-xl">
            The substrate is plain files on a shared drive. No database, no API, no vendor lock-in.
            If you stop using the skills, your data stays readable forever.
          </p>
        </div>

        {/* Problem */}
        <div className="bg-white border border-stone-200 shadow-sm p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="text-xs font-semibold text-stone-400 uppercase tracking-wider mb-3">The gap</div>
              <h2 className="text-2xl font-bold text-stone-800 mb-3">State exists. Reports don&apos;t write themselves.</h2>
              <p className="text-stone-500 text-sm leading-relaxed mb-4">
                Every multi-stakeholder project has the same overhead: weekly status emails, quarterly claims,
                steering committee packs, board updates, funder reports. The Project Lead writes them by hand,
                pulling from scattered spreadsheets and email threads. It takes hours per week and the
                reports are always slightly stale.
              </p>
              <p className="text-stone-500 text-sm leading-relaxed">
                project-state eliminates this by making the substrate the source of truth.
                Update a milestone, log a decision, flag a risk — the reports generate themselves
                from what you already captured.
              </p>
            </div>
            <div className="space-y-3">
              {[
                'What&apos;s the current phase and what gates are open?',
                'Generate this week&apos;s status report for the SC pack.',
                'Draft the quarterly claim from milestone progress.',
                'What changed since the last steering committee?',
                'Onboard the new CDI partner with project context.',
                'Which risks need escalation this sprint?',
              ].map(q => (
                <div key={q} className="flex items-start gap-2.5">
                  <span className="mt-0.5 shrink-0 text-sm" style={{ color: '#22c55e' }}>✓</span>
                  <span className="text-sm text-stone-600" dangerouslySetInnerHTML={{ __html: q }} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Architecture */}
        <div>
          <div className="text-xs font-semibold text-stone-400 uppercase tracking-wider mb-4">Architecture</div>
          <h2 className="text-xl font-bold text-stone-800 mb-6">Three layers. Skills are stateless verbs.</h2>
          <div className="space-y-2">
            {[
              { label: 'Surfaces',  sub: 'Slack · Gmail (drafts) · Calendar · Blog · Website · Local Dashboard', color: '#b45309', icon: '◈', note: 'human review before send' },
              { label: 'Skills',    sub: '28 project-* skills · stateless verbs that read/write the substrate', color: '#6366f1', icon: '◇', note: 'routes through project-state' },
              { label: 'Packs',     sub: '7 compliance packs · YAML profiles configure skill behaviour', color: '#f59e0b', icon: '○', note: 'seeds reporting matrix' },
              { label: 'Substrate', sub: 'project-state/ · YAML · JSON · NDJSON · Markdown · plain files', color: '#78716c', icon: '●', note: 'source of truth' },
            ].map((layer, i, arr) => (
              <div key={layer.label}
                className="border p-4 flex items-center gap-4"
                style={{ borderColor: layer.color + '40', background: layer.color + '08' }}>
                <div className="w-8 shrink-0 text-center text-lg" style={{ color: layer.color }}>{layer.icon}</div>
                <div className="flex-1">
                  <div className="font-bold text-stone-700">{layer.label}</div>
                  <div className="text-xs text-stone-400 font-mono mt-0.5">{layer.sub}</div>
                </div>
                <div className="text-xs font-semibold shrink-0" style={{ color: layer.color }}>
                  {i < arr.length - 1 ? layer.note : 'source of truth'}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Skills */}
        <div>
          <div className="text-xs font-semibold text-stone-400 uppercase tracking-wider mb-4">31 skills</div>
          <h2 className="text-xl font-bold text-stone-800 mb-6">One skill = one coherent job.</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {SKILLS.map(skill => (
              <div key={skill.cmd} className="bg-white border border-stone-200 p-3">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <code className="text-xs font-mono font-bold text-stone-700">{skill.cmd}</code>
                  <span className="text-xs px-1.5 py-0.5 font-semibold shrink-0"
                    style={{ color: ROLE_COLOR[skill.role], background: ROLE_COLOR[skill.role] + '15' }}>
                    {skill.role}
                  </span>
                </div>
                <p className="text-xs text-stone-500 leading-relaxed">{skill.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Packs */}
        <div>
          <div className="text-xs font-semibold text-stone-400 uppercase tracking-wider mb-4">7 compliance packs</div>
          <h2 className="text-xl font-bold text-stone-800 mb-6">Packs configure. They don&apos;t code.</h2>
          <div className="space-y-2">
            {PACKS.map(p => (
              <div key={p.name} className="bg-white border border-stone-200 p-4 flex items-center gap-4 shadow-sm">
                <code className="text-sm font-mono font-bold text-stone-700 w-48 shrink-0">{p.name}</code>
                <span className={`text-xs px-2 py-0.5 font-semibold shrink-0 ${
                  p.maturity === 'production' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-stone-100 text-stone-500'
                }`}>{p.maturity}</span>
                <span className="text-sm text-stone-500">{p.desc}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Install */}
        <div className="bg-stone-900 text-stone-300 p-8">
          <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-4">Install</div>
          <h2 className="text-xl font-bold text-stone-100 mb-6">Two commands to install. One to scaffold.</h2>
          <div className="space-y-4 font-mono text-sm">
            {[
              { cmd: 'claude plugin marketplace add github:atomic47/project-state', comment: '# add the marketplace' },
              { cmd: 'claude plugin install project-state@project-state',          comment: '# install the plugin (31 skills)' },
              { cmd: '/project-scaffolder',                                         comment: '# interactive wizard — creates project-state/ in ~5 min' },
              { cmd: '/project-kanban',                                             comment: '# open this dashboard at localhost:3355' },
            ].map(({ cmd, comment }, i) => (
              <div key={i} className="flex items-start gap-4">
                <span className="text-stone-600 shrink-0 mt-0.5">{i + 1}.</span>
                <div>
                  <div style={{ color: '#fbbf24' }}>{cmd}</div>
                  <div className="text-stone-600 text-xs mt-0.5">{comment}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 pt-5 border-t border-stone-800 text-xs text-stone-500">
            Prerequisites: Claude Code · Node.js + npm for this dashboard · Optional: Gmail / Slack / Google Drive MCPs for notification surfaces
          </div>
        </div>

        {/* Footer */}
        <div className="text-xs text-stone-400 text-center pb-4">
          project-state v3.3 · <span className="font-mono">project-state/</span> · built by Atomic 47 Labs
        </div>

      </main>
    </div>
  )
}
