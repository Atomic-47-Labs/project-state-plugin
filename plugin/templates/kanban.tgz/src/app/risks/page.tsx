import { InventoryApp } from '@/components/inventory-app'

export default function RisksPage() {
  return <InventoryApp section="risks" />
}
