import { InventoryApp } from '@/components/inventory-app'

export default function DocumentsPage() {
  return <InventoryApp section="documents" />
}
