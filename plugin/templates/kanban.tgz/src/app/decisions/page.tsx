import { InventoryApp } from '@/components/inventory-app'

export default function DecisionsPage() {
  return <InventoryApp section="decisions" />
}
