import { ScheduleApp } from '@/components/schedule-app'

export default function SchedulePage() {
  return <ScheduleApp />
}
