import { QueueApp } from '@/components/queue-app'

export default function QueuePage() {
  return <QueueApp />
}
