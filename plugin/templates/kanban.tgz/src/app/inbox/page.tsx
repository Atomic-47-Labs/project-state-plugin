import { InboxApp } from '@/components/inbox-app'

export default function InboxPage() {
  return <InboxApp />
}
