import { MilestoneDetailApp } from '@/components/milestone-detail-app'
export default function MilestonePage() { return <MilestoneDetailApp /> }
