import { InventoryApp } from '@/components/inventory-app'

export default function MilestonesPage() {
  return <InventoryApp section="milestones" />
}
