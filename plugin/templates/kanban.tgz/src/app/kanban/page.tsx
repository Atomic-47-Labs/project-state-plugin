import { KanbanApp } from '@/components/kanban-app'
export default function KanbanPage() { return <KanbanApp /> }
