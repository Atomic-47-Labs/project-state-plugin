import { ReportsApp } from '@/components/reports-app'

export default function ReportsPage() {
  return <ReportsApp />
}
