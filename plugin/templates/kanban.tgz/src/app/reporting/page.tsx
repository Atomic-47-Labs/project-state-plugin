import { ReportingApp } from '@/components/reporting-app'

export default function ReportingPage() {
  return <ReportingApp />
}
