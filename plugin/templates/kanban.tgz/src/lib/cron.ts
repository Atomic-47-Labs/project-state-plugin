import { execSync, spawnSync } from 'child_process'
import path from 'path'
import { getStateDir } from './state'
import { repoRoot } from './jobs'

const BEGIN = '# >>> project-state-kanban tick (managed) >>>'
const END = '# <<< project-state-kanban tick (managed) <<<'

const TICK_PROMPT =
  'Run the project-orchestrator tick routine: read reporting-matrix.yaml, dispatch the ' +
  'generators that are due (each self-queues its draft into outbox/queue/). Send nothing.'

export interface CronStatus {
  registered: boolean
  paused: boolean
  schedule: string | null   // cron expression, if registered
}

function claudeBin(): string {
  try { return execSync('command -v claude', { encoding: 'utf-8' }).trim() || '/usr/local/bin/claude' }
  catch { return '/usr/local/bin/claude' }
}

function readCrontab(): string {
  const r = spawnSync('crontab', ['-l'], { encoding: 'utf-8' })
  // exit 1 with "no crontab" is normal — treat as empty
  return r.status === 0 ? r.stdout : ''
}

function writeCrontab(content: string) {
  const r = spawnSync('crontab', ['-'], { input: content.endsWith('\n') ? content : content + '\n', encoding: 'utf-8' })
  if (r.status !== 0) throw new Error(`crontab write failed: ${r.stderr || r.status}`)
}

// Strip our managed block, return the rest of the crontab.
function stripManaged(content: string): string {
  const lines = content.split('\n')
  const out: string[] = []
  let inBlock = false
  for (const line of lines) {
    if (line.trim() === BEGIN) { inBlock = true; continue }
    if (line.trim() === END) { inBlock = false; continue }
    if (!inBlock) out.push(line)
  }
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim()
}

function buildBlock(schedule: string, paused: boolean): string {
  const repo = repoRoot()
  const log = path.join(getStateDir(), 'logs', 'cron-tick.log')
  const cmd = `${schedule} cd ${repo} && ${claudeBin()} -p "${TICK_PROMPT}" --permission-mode bypassPermissions --max-budget-usd 2 >> ${log} 2>&1`
  return [BEGIN, paused ? `# (paused) ${cmd}` : cmd, END].join('\n')
}

const CRON_RE = /^(\S+\s+){4}\S+$/

export function status(): CronStatus {
  const content = readCrontab()
  const lines = content.split('\n')
  let inBlock = false
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim() === BEGIN) { inBlock = true; continue }
    if (lines[i].trim() === END) break
    if (inBlock) {
      const raw = lines[i].trim()
      const paused = raw.startsWith('# (paused) ')
      const active = paused ? raw.replace('# (paused) ', '') : raw
      const schedule = active.split(/\s+/).slice(0, 5).join(' ')
      return { registered: true, paused, schedule }
    }
  }
  return { registered: false, paused: false, schedule: null }
}

export function register(schedule: string): CronStatus {
  if (!CRON_RE.test(schedule.trim())) throw new Error(`Invalid cron expression: "${schedule}" (expected 5 fields)`)
  const base = stripManaged(readCrontab())
  const next = [base, buildBlock(schedule.trim(), false)].filter(Boolean).join('\n\n')
  writeCrontab(next)
  return status()
}

export function pause(): CronStatus {
  const cur = status()
  if (!cur.registered || !cur.schedule) return cur
  const base = stripManaged(readCrontab())
  writeCrontab([base, buildBlock(cur.schedule, true)].filter(Boolean).join('\n\n'))
  return status()
}

export function resume(): CronStatus {
  const cur = status()
  if (!cur.registered || !cur.schedule) return cur
  return register(cur.schedule)
}

export function remove(): CronStatus {
  const base = stripManaged(readCrontab())
  writeCrontab(base)
  return status()
}
