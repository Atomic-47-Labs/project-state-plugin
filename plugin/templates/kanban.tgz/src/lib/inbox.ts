import fs from 'fs'
import path from 'path'
import yaml from 'js-yaml'
import { getStateDir } from './state'

export function inboxDir(): string {
  const d = path.join(getStateDir(), 'documents', 'inbox')
  fs.mkdirSync(d, { recursive: true })
  return d
}
function workingDir(): string {
  const d = path.join(getStateDir(), 'documents', 'working')
  fs.mkdirSync(d, { recursive: true })
  return d
}
// Ingested files are recorded here — a list this UI owns, so we never reformat the
// skill-managed documents/index.yaml.
function ingestedPath(): string {
  return path.join(getStateDir(), 'documents', 'ingested.yaml')
}

export interface IngestedDoc { title: string; path: string; kind: string; ingested_at: string }

export function listIngested(): IngestedDoc[] {
  try {
    const d = yaml.load(fs.readFileSync(ingestedPath(), 'utf-8')) as { documents?: IngestedDoc[] }
    return Array.isArray(d?.documents) ? d.documents : []
  } catch { return [] }
}

// Reject anything that isn't a plain filename in the inbox dir.
export function safeName(name: string): string {
  const base = path.basename(name)
  if (base !== name || base.includes('/') || base.includes('\\') || base.startsWith('.')) {
    throw new Error(`Unsafe filename: ${name}`)
  }
  return base
}

export interface InboxFile {
  name: string
  size: number
  mtime: string
  ext: string
}

export function listInbox(): InboxFile[] {
  const dir = inboxDir()
  return fs.readdirSync(dir)
    .filter(f => !f.startsWith('.'))
    .map(f => {
      const st = fs.statSync(path.join(dir, f))
      return { name: f, size: st.size, mtime: st.mtime.toISOString(), ext: path.extname(f).toLowerCase() }
    })
    .filter(f => fs.statSync(path.join(dir, f.name)).isFile())
    .sort((a, b) => b.mtime.localeCompare(a.mtime))
}

export function readInboxFile(name: string): string {
  const p = path.join(inboxDir(), safeName(name))
  return fs.readFileSync(p, 'utf-8')
}

export function inboxFilePath(name: string): string {
  return path.join(inboxDir(), safeName(name))
}

function appendLog(event: string, detail: string) {
  try {
    fs.appendFileSync(
      path.join(getStateDir(), 'logs', 'activity.ndjson'),
      JSON.stringify({ ts: new Date().toISOString(), actor: 'project-kanban', event, detail }) + '\n',
    )
  } catch { /* best-effort */ }
}

export function saveUpload(name: string, data: Buffer): void {
  fs.writeFileSync(path.join(inboxDir(), safeName(name)), data)
  appendLog('inbox.uploaded', name)
}

export function deleteFiles(names: string[]): number {
  let n = 0
  for (const name of names) {
    const p = path.join(inboxDir(), safeName(name))
    if (fs.existsSync(p)) { fs.rmSync(p); n++ }
  }
  if (n) appendLog('inbox.deleted', names.join(', '))
  return n
}

// Ingest = move out of inbox into documents/working/ and register in documents/ingested.yaml.
export function ingestFiles(names: string[]): number {
  const docs = listIngested()
  let n = 0
  for (const raw of names) {
    const name = safeName(raw)
    const src = path.join(inboxDir(), name)
    if (!fs.existsSync(src)) continue
    const dest = path.join(workingDir(), name)
    fs.renameSync(src, dest)
    docs.push({
      title: name.replace(/\.[^.]+$/, ''),
      path: `documents/working/${name}`,
      kind: 'ingested',
      ingested_at: new Date().toISOString(),
    })
    n++
  }
  if (n) {
    fs.writeFileSync(ingestedPath(), yaml.dump({ documents: docs }, { lineWidth: 120 }))
    appendLog('inbox.ingested', names.join(', '))
  }
  return n
}
