import fs from 'fs'
import path from 'path'
import yaml from 'js-yaml'
import { spawn } from 'child_process'
import { getStateDir } from './state'

// ── Repo root = parent of project-state/ (cwd for the spawned generator) ──────
export function repoRoot(): string {
  return path.dirname(getStateDir())
}

function jobsDir(): string {
  const d = path.join(getStateDir(), 'outbox', 'jobs')
  fs.mkdirSync(d, { recursive: true })
  return d
}

// ── Generator whitelist ───────────────────────────────────────────────────────
// The ONLY thing the UI can run. Keys are opaque ids; prompts are fixed
// server-side strings. No user-supplied text ever reaches the command line.
export interface GeneratorDef {
  id: string
  label: string
  generator: string        // skill name (for display / job record)
  prompt: string           // exact headless prompt
}

export const GENERATORS: Record<string, GeneratorDef> = {
  'weekly-status': {
    id: 'weekly-status',
    label: 'Weekly status report',
    generator: 'project-status-reporter',
    prompt:
      'Use the project-status-reporter skill to generate the weekly status report ' +
      'from the current project-state, and emit the outbox card per its "Outbox emission" ' +
      'section into outbox/queue/. Do not send, post, or publish anything — draft only.',
  },
  'dashboard-snapshot': {
    id: 'dashboard-snapshot',
    label: 'Dashboard snapshot (one-pager)',
    generator: 'project-status-reporter',
    prompt:
      'Use the project-status-reporter skill to generate the one-page dashboard snapshot ' +
      'from current project-state and emit the outbox card into outbox/queue/. Draft only — send nothing.',
  },
  'sc-pack': {
    id: 'sc-pack',
    label: 'Steering Committee pre-read pack',
    generator: 'project-review-meeting',
    prompt:
      'Use the project-review-meeting skill to assemble the next SC pre-read pack and emit ' +
      'its outbox card(s) into outbox/queue/. Draft only — do not send invites or distribute.',
  },
  'quarterly-claim': {
    id: 'quarterly-claim',
    label: 'Quarterly funder claim draft',
    generator: 'project-funder-reporting',
    prompt:
      'Use the project-funder-reporting skill to draft the current quarterly claim and emit ' +
      'the gmail_draft outbox card into outbox/queue/. Draft only — never submit or send.',
  },
}

// ── Allowed generator skills ──────────────────────────────────────────────────
// Any reporting-matrix entry whose `generator` is in this set can be triggered
// per-row. The matrix is trusted server-side config, but we still gate on skill
// name so a tampered/typo'd generator can't run an arbitrary command.
export const ALLOWED_GENERATOR_SKILLS = new Set([
  'project-status-reporter',
  'project-review-meeting',
  'project-funder-reporting',
  'project-blog-publisher',
  'project-doc-suite-generator',
  // project-website-publisher intentionally excluded — deploys are manual only.
])

interface MatrixEntry { id: string; report?: string; generator?: string; profile?: string }

function loadMatrixEntry(id: string): MatrixEntry | null {
  const p = path.join(getStateDir(), 'reporting-matrix.yaml')
  if (!fs.existsSync(p)) return null
  const m = yaml.load(fs.readFileSync(p, 'utf-8')) as { entries?: MatrixEntry[] }
  return m.entries?.find(e => e.id === id) ?? null
}

// ── Job records ─────────────────────────────────────────────────────────────
export type JobStatus = 'running' | 'done' | 'failed'
export interface JobRecord {
  id: string
  generator_id: string
  generator: string
  label: string
  status: JobStatus
  started_at: string
  finished_at?: string
  exit_code?: number
  error?: string
}

const BUDGET_USD = 2
const TIMEOUT_MS = 5 * 60 * 1000

function jobPath(id: string) { return path.join(jobsDir(), `${id}.json`) }

function writeJob(job: JobRecord) {
  fs.writeFileSync(jobPath(job.id), JSON.stringify(job, null, 2))
}

export function getJob(id: string): JobRecord | null {
  try { return JSON.parse(fs.readFileSync(jobPath(id), 'utf-8')) } catch { return null }
}

export function listJobs(limit = 25): JobRecord[] {
  return fs.readdirSync(jobsDir())
    .filter(f => f.endsWith('.json'))
    .map(f => { try { return JSON.parse(fs.readFileSync(path.join(jobsDir(), f), 'utf-8')) } catch { return null } })
    .filter((j): j is JobRecord => !!j)
    .sort((a, b) => b.started_at.localeCompare(a.started_at))
    .slice(0, limit)
}

function appendLog(event: string, id: string, detail: string) {
  try {
    fs.appendFileSync(
      path.join(getStateDir(), 'logs', 'activity.ndjson'),
      JSON.stringify({ ts: new Date().toISOString(), actor: 'project-kanban', event, id, detail }) + '\n',
    )
  } catch { /* best-effort */ }
}

/** Run a generator job from a fixed-whitelist report kind. */
export function startJob(generatorId: string): JobRecord {
  const def = GENERATORS[generatorId]
  if (!def) throw new Error(`Unknown generator: ${generatorId}`)
  return run({ slug: generatorId, generator: def.generator, label: def.label, prompt: def.prompt })
}

/** Run a generator job from a reporting-matrix entry (per-row trigger). */
export function startMatrixJob(entryId: string): JobRecord {
  const entry = loadMatrixEntry(entryId)
  if (!entry) throw new Error(`Matrix entry not found: ${entryId}`)
  if (!entry.generator || !ALLOWED_GENERATOR_SKILLS.has(entry.generator)) {
    throw new Error(`Generator not allowed for entry "${entryId}": ${entry.generator ?? '(none)'}`)
  }
  // Prompt is built from trusted matrix config — `report` is server-side, not request input.
  const report = (entry.report ?? entryId).replace(/["\n]/g, ' ')
  const prompt =
    `Use the ${entry.generator} skill to produce "${report}" (reporting-matrix entry ` +
    `"${entryId}") from the current project-state, and emit the corresponding outbox card(s) ` +
    `into outbox/queue/ per that skill's "Outbox emission" section. Draft only — do not send, ` +
    `post, publish, or commit anything.`
  return run({ slug: entryId, generator: entry.generator, label: report, prompt })
}

const ADHOC_MAX_CHARS = 2000
// Tools a report-generation run legitimately needs. Bash, WebFetch, etc. are NOT
// here, so a custom prompt cannot shell out or hit the network.
const ADHOC_ALLOWED_TOOLS = 'Read Glob Grep Skill Write Edit TodoWrite'

/**
 * Run an ad-hoc report from a free-text user request. The user's text never becomes
 * the agent instruction directly — it is wrapped in a fixed server-side envelope that
 * pins scope (draft-only, read project-state, emit a card). Runs with a constrained
 * tool allowlist instead of bypassPermissions, since the request is untrusted input.
 */
export function startAdhocJob(userText: string): JobRecord {
  const text = (userText ?? '').trim()
  if (!text) throw new Error('Empty prompt')
  if (text.length > ADHOC_MAX_CHARS) throw new Error(`Prompt too long (max ${ADHOC_MAX_CHARS} chars)`)

  const prompt =
    `You are generating an ad-hoc project report. Use the project-state skills and read ` +
    `only from project-state/. Produce the report as a DRAFT and emit an outbox card into ` +
    `outbox/queue/ (kind: report, status: queued, surface: none) with a short markdown ` +
    `artifact. Do NOT send, post, publish, commit, or modify project state beyond writing ` +
    `the draft and its card. The user's request:\n\n"""${text}"""`

  const label = text.length > 60 ? text.slice(0, 57) + '…' : text
  return run({ slug: 'adhoc', generator: 'ad-hoc', label, prompt, restricted: true })
}

function run({ slug, generator, label, prompt, restricted }: { slug: string; generator: string; label: string; prompt: string; restricted?: boolean }): JobRecord {
  const id = `${new Date().toISOString().replace(/[:.]/g, '-')}-${slug}`
  const job: JobRecord = {
    id,
    generator_id: slug,
    generator,
    label,
    status: 'running',
    started_at: new Date().toISOString(),
  }
  writeJob(job)
  appendLog('job.started', id, label)

  // Strip Claude Code session markers so the headless child isn't treated as a
  // nested session (claude refuses to launch inside another claude session).
  const childEnv = { ...process.env }
  delete childEnv.CLAUDECODE
  delete childEnv.CLAUDE_CODE_ENTRYPOINT

  // Trusted (preset/matrix) runs use bypassPermissions; ad-hoc free-text runs are
  // tool-constrained (no Bash/network) since the request is untrusted input.
  const permArgs = restricted
    ? ['--permission-mode', 'acceptEdits', '--allowedTools', ADHOC_ALLOWED_TOOLS]
    : ['--permission-mode', 'bypassPermissions']

  // spawn arg-array (no shell) — prompt is a single argv element (no shell-injection).
  const child = spawn('claude', [
    '-p', prompt,
    '--output-format', 'json',
    ...permArgs,
    '--max-budget-usd', String(BUDGET_USD),
  ], {
    cwd: repoRoot(),
    detached: true,
    stdio: 'ignore',
    env: childEnv,
  })

  const killer = setTimeout(() => { try { process.kill(-child.pid!, 'SIGKILL') } catch {} }, TIMEOUT_MS)

  child.on('exit', (code) => {
    clearTimeout(killer)
    const fin = getJob(id) ?? job
    fin.status = code === 0 ? 'done' : 'failed'
    fin.exit_code = code ?? -1
    fin.finished_at = new Date().toISOString()
    if (code !== 0) fin.error = `generator exited with code ${code}`
    writeJob(fin)
    appendLog(code === 0 ? 'job.done' : 'job.failed', id, `${label} (exit ${code})`)
  })
  child.on('error', (err) => {
    clearTimeout(killer)
    const fin = getJob(id) ?? job
    fin.status = 'failed'
    fin.error = String(err)
    fin.finished_at = new Date().toISOString()
    writeJob(fin)
    appendLog('job.failed', id, `${label}: ${err}`)
  })
  child.unref()

  return job
}
