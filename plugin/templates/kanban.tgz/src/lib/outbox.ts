import fs from 'fs'
import path from 'path'
import yaml from 'js-yaml'
import { getStateDir } from './state'

export type OutboxStatus = 'queued' | 'approved' | 'dismissed' | 'sent'

export const STATUS_DIR: Record<OutboxStatus, string> = {
  queued: 'queue',
  approved: 'approved',
  dismissed: 'dismissed',
  sent: 'sent',
}

export interface OutboxCard {
  id: string
  kind: string
  title: string
  produced_by?: string
  produced_at?: string
  status: OutboxStatus
  surface?: string
  action_required?: string
  deep_link?: string
  artifact?: string
  related_milestones?: string[]
  expires?: string
  dismiss_reason?: string
  // resolved at read time
  _dir: string          // absolute folder the card currently lives in
  _metaFile: string     // meta filename (e.g. <id>.meta.yaml)
}

export function outboxRoot(): string {
  return path.join(getStateDir(), 'outbox')
}

function readDir(status: OutboxStatus): OutboxCard[] {
  const dir = path.join(outboxRoot(), STATUS_DIR[status])
  if (!fs.existsSync(dir)) return []
  const cards: OutboxCard[] = []
  for (const f of fs.readdirSync(dir)) {
    if (!f.endsWith('.meta.yaml')) continue
    try {
      const meta = yaml.load(fs.readFileSync(path.join(dir, f), 'utf-8')) as Record<string, unknown>
      if (!meta || typeof meta !== 'object') continue
      cards.push({
        ...(meta as object),
        status: (meta.status as OutboxStatus) ?? status,
        id: (meta.id as string) ?? f.replace('.meta.yaml', ''),
        _dir: dir,
        _metaFile: f,
      } as OutboxCard)
    } catch { /* skip malformed */ }
  }
  return cards
}

export function listOutbox(): Record<OutboxStatus, OutboxCard[]> {
  return {
    queued: readDir('queued'),
    approved: readDir('approved'),
    dismissed: readDir('dismissed'),
    sent: readDir('sent'),
  }
}

function findCard(id: string): OutboxCard | null {
  for (const status of Object.keys(STATUS_DIR) as OutboxStatus[]) {
    const card = readDir(status).find(c => c.id === id)
    if (card) return card
  }
  return null
}

export function readArtifact(id: string): string | null {
  const card = findCard(id)
  if (!card?.artifact) return null
  const p = path.join(card._dir, card.artifact)
  return fs.existsSync(p) ? fs.readFileSync(p, 'utf-8') : null
}

function appendLog(event: string, id: string, detail: string) {
  try {
    const logPath = path.join(getStateDir(), 'logs', 'activity.ndjson')
    const entry = JSON.stringify({
      ts: new Date().toISOString(),
      actor: 'project-kanban',
      event,
      id,
      detail,
    })
    fs.appendFileSync(logPath, entry + '\n')
  } catch { /* logging is best-effort */ }
}

/** Move a card's .md + .meta.yaml to a new status folder and rewrite its status. */
export function transition(id: string, to: OutboxStatus, opts?: { reason?: string }): OutboxCard {
  const card = findCard(id)
  if (!card) throw new Error(`Outbox card not found: ${id}`)

  const destDir = path.join(outboxRoot(), STATUS_DIR[to])
  fs.mkdirSync(destDir, { recursive: true })

  // Rewrite meta with new status, then move both files.
  const meta = yaml.load(fs.readFileSync(path.join(card._dir, card._metaFile), 'utf-8')) as Record<string, unknown>
  meta.status = to
  if (opts?.reason) meta.dismiss_reason = opts.reason

  const destMeta = path.join(destDir, card._metaFile)
  fs.writeFileSync(destMeta, yaml.dump(meta, { lineWidth: 120 }))
  if (card._dir !== destDir) fs.rmSync(path.join(card._dir, card._metaFile))

  if (card.artifact) {
    const srcArt = path.join(card._dir, card.artifact)
    const destArt = path.join(destDir, card.artifact)
    if (fs.existsSync(srcArt) && srcArt !== destArt) fs.renameSync(srcArt, destArt)
  }

  appendLog('outbox.transition', id, `${card.status} → ${to}${opts?.reason ? ` (${opts.reason})` : ''}`)
  return { ...card, ...(meta as object), status: to, _dir: destDir } as OutboxCard
}

/** Overwrite the artifact body in place. Card stays in its current folder. */
export function editArtifact(id: string, content: string): void {
  const card = findCard(id)
  if (!card?.artifact) throw new Error(`No editable artifact for card: ${id}`)
  fs.writeFileSync(path.join(card._dir, card.artifact), content)
  appendLog('outbox.edited', id, `artifact rewritten (${content.length} chars)`)
}
