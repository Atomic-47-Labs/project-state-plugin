import fs from 'fs'
import path from 'path'

// Resolve project-state/ directory.
// Priority: PROJECT_STATE_DIR env → walk up from cwd → fallback two levels up.
// Checks both project-state/ (v3.2+) and .project-state/ (legacy) at each level.
export function getStateDir(): string {
  if (process.env.PROJECT_STATE_DIR) return process.env.PROJECT_STATE_DIR

  let dir = process.cwd()
  for (let i = 0; i < 8; i++) {
    for (const name of ['project-state', '.project-state']) {
      const candidate = path.join(dir, name)
      if (fs.existsSync(candidate) && fs.statSync(candidate).isDirectory()) {
        return candidate
      }
    }
    const parent = path.dirname(dir)
    if (parent === dir) break
    dir = parent
  }

  // Fallback: two levels up from this file (kanban/ → repo root)
  return path.resolve(__dirname, '..', '..', '..', '..', 'project-state')
}

export function stateDirExists(): boolean {
  try {
    const d = getStateDir()
    return fs.existsSync(d) && fs.existsSync(path.join(d, 'manifest.yaml'))
  } catch {
    return false
  }
}
