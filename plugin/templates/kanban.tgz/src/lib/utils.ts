export function fmtDate(iso: string | null | undefined): string {
  if (!iso) return '—'
  try {
    return new Date(iso + (iso.includes('T') ? '' : 'T12:00:00Z')).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric',
    })
  } catch {
    return iso
  }
}

export function fmtDateShort(iso: string | null | undefined): string {
  if (!iso) return '—'
  try {
    return new Date(iso + (iso.includes('T') ? '' : 'T12:00:00Z')).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric',
    })
  } catch {
    return iso
  }
}

export function daysUntil(iso: string | null | undefined): number | null {
  if (!iso) return null
  try {
    const target = new Date(iso + 'T12:00:00Z')
    const now = new Date()
    return Math.ceil((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
  } catch {
    return null
  }
}

export function statusColor(status: string): string {
  switch (status) {
    case 'complete':    return '#22c55e'
    case 'in_progress': return '#0ea5e9'
    case 'at_risk':    return '#f59e0b'
    case 'planned':    return '#94a3b8'
    default:           return '#94a3b8'
  }
}

export function riskScoreColor(score: number): string {
  if (score >= 9) return '#ef4444'
  if (score >= 6) return '#f59e0b'
  return '#22c55e'
}
