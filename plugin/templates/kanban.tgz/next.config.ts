import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  serverExternalPackages: ['js-yaml'],
  devIndicators: false,
}

export default nextConfig
